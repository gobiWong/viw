<template>
	<view>
		<!-- #ifdef MP-WEIXIN -->
		<!-- <view v-if="isCanUse">
            <view>
                <view class='header'>
                    <image src='../../static/img/wx_login.png'></image>
                </view>
                <view class='content'>
                    <view>申请获取以下权限</view>
                    <text>获得你的公开信息(昵称，头像、地区等)</text>
                </view>

                <button class='bottom' type='primary' open-type="getUserInfo" withCredentials="true" lang="zh_CN" @getuserinfo="wxGetUserInfo">
                    授权登录
                </button>
            </view>
        </view> -->
		<!-- #endif -->
	</view>
</template>

<script>
import { mapMutations } from 'vuex';
export default {
	methods: {
		...mapMutations(['login'])
	},
	
	onLaunch() {
		console.log('App 2222');
		let userInfo = uni.getStorageSync('userInfo') || '';
		if (userInfo.id) {
			//更新登陆状态
			uni.getStorage({
				key: 'userInfo',
				success: res => {
					this.login(res.data);
				}
			});
		}

	},
	onShow: function() {
		console.log('App Show');
	},
	onHide: function() {
		console.log('App Hide');
	}
};
</script>

<style>
/*每个页面公共css */
@font-face {
	font-family: dxicon;
	font-weight: normal;
	font-style: normal;
	src: url('https://at.alicdn.com/t/font_1328265_3ce7xs81wvw.ttf') format('truetype');
}

.dxicon {
	font-family: 'dxicon' !important;
	font-size: 16px;
	font-style: normal;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
}

.dxiconiconfontmove:before {
	content: '\e625';
}

.dxiconweixuanzhong:before {
	content: '\e61f';
}

.dxiconxuanzhong:before {
	content: '\e656';
	color: #fff;
}
.dxiconxuanzhong1:before {
	content: '\e650';
}

.dxiconshanchu:before {
	content: '\e621';
}

.dxiconjiahao:before {
	content: '\e602';
}
.dxiconbianji:before {
	content: '\e62e';
}
.dxiconyou-:before {
	content: '\e63e';
}
</style>
