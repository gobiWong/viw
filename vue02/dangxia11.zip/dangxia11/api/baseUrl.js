import {
	web
} from "./config.js"
//首页轮播图
const homeModule = {
	carouselMap: {
		url: web.www + '/home/carouselMap', //首页轮播图
		method: 'POST'
	},
	carouselDetail: {
		url: web.www + '/home/carouselDetail', //通过点击图片查询对应类型的商品
		method: 'POST'
	},

	queryProductInfo: {
		url: web.www + '/home/queryProductInfo', //点击商品查看商品信息
		method: 'POST'
	},
	queryData: {
		url: web.www + '/announcement/queryData', //首页公告
		method: 'POST'
	},
	queryLikeProductName: {
		url: web.www + '/home/queryLikeProductName', //首页模块通过商品名称模糊检索
		method: 'POST'
	},
};
//商品分类
const classificationModule = {
	queryAllClassification: {
		url: web.www + '/classification/queryAllClassification', //查询所有商品的分类
		method: 'POST'
	},
	queryAllProduct: {
		url: web.www + '/classification/queryAllProduct', //查询一个类型下的所有商品
		method: 'POST'
	},

};
//购物车
const shoppingCartModule = {
	insertCart: {
		url: web.www + '/shoppingCart/insertCart', //添加商品到购物车
		method: 'POST'
	},
	updateCart: {
		url: web.www + '/shoppingCart/updateCart', //购物车编辑
		method: 'POST'
	},
	delCart: {
		url: web.www + '/shoppingCart/delCart', //删除购物车商品
		method: 'POST'
	},
	queryCartProduct: {
		url: web.www + '/shoppingCart/queryCartProduct', //通过用户ID查询购物车商品
		method: 'POST'
	},

};
//订单模块
const weChatModule = {
	wxPay: {
		url: web.www + '/weChat/wxPay', //微信下单支付
		method: 'POST'
	},
	queryOrder: {
		url: web.www + '/order/queryOrder', //查询订单
		method: 'POST'
	},
	queryOpenId: {
		url: web.www + '/weChat/queryOpenId', //通过code获取openid
		method: 'POST'
	},
	wxNotify: {
		url: web.www + '/weChat/wxNotify', //
		method: 'POST'
	},
	delOrderById: {
		url: web.www + '/order/delOrderById', //取消订单
		method: 'POST'
	},
	confirmReceive: {
		url: web.www + '/logistics/confirmReceive', //确认收货
		method: 'POST'
	},
	logisticsInfo: {
		url: web.www + '/logistics/logisticsInfo', //查询物流信息
		method: 'POST'
	},



};
//收获地址管理
const addressModule = {
	queryAddrByUserId: {
		url: web.www + '/addr/queryAddrByUserId', //通过用户ID查询下面的多个收货地址
		method: 'POST'
	},
	insertAddr: {
		url: web.www + '/addr/insertAddr', //收货地址新增
		method: 'POST'
	},
	updateAddr: {
		url: web.www + '/addr/updateAddr', //地址修改
		method: 'POST'
	},
	delAddrById: {
		url: web.www + '/addr/delAddrById', //地址删除
		method: 'POST'
	},
};

//用户管理
const userModule = {
	insertUserLogin: {
		url: web.www + '/login/insertUserLogin', //获取用户信息
		method: 'POST'
	},


};

const ApiSetting = {
	...homeModule,
	...classificationModule,
	...shoppingCartModule,
	...weChatModule,
	...addressModule,
	...userModule
}
export default ApiSetting
