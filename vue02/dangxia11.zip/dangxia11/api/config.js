//开发模式
module.exports={
  web:{
    www: 'http://192.168.2.130:8086',
	// www:'https://webapp.whdxcy.com',
    // webUrl:'https://api.baidu.com/'
  }
};