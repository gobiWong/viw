<template>
	<view class="container">
		<!-- 空白页 -->
		<view v-if="empty" class="empty">
			<image src="/static/emptyCart.jpg" mode="aspectFit"></image>
			<!-- <view v-if="hasLogin" class="empty-tips">
				空空如也
				<navigator class="navigator" v-if="hasLogin" url="../index/index" open-type="switchTab">随便逛逛></navigator>
			</view>
			<view v-else class="empty-tips">
				空空如也
				<view class="navigator" @click="navToLogin">去登陆></view>
			</view> -->
		</view>
		<view v-else>
			<view class="cart-list">
				<block v-for="(item, index) in CartProductList" :key="item.productParameterId">
					<view class="cart-item" :class="{ 'b-b': index !== CartProductList.length - 1 }">
						<view class="image-wrapper">
							<image
								:src="item.productImg"
								:class="[item.loaded]"
								mode="aspectFill"
								lazy-load
								@load="onImageLoad('CartProductList', index)"
								@error="onImageError('CartProductList', index)"
							></image>
							<view class="dxicon dxiconxuanzhong1 checkbox" :class="{ checked: item.state }" @click="check('item', index)"></view>
						</view>
						<view class="item-right">
							<text class="clamp title">{{ item.productName }}</text>
							<text class="attr">{{ item.productDescription }}</text>
							<text class="price">¥{{ item.discountPrice }}</text>
							
							<!-- <uni-number-box
								class="<step></step>"
								:min="1"
								:max="item.stock"
								:value="item.amount > item.stock ? item.stock : item.amount"
								:isMax="item.stock >= item.stock ? true : false"
								:isMin="item.amount === 1"
								:index="index"
								@eventChange="numberChange"
							></uni-number-box> -->
							<uni-number-box :min="1" :max="item.stock" :index="index" @change="numberChange" :value="item.amount" />

						</view>
						<text class="del-btn dxicon dxiconshanchu" @click="deleteCartItem(item.productId)"></text>
					</view>
				</block>
			</view>
			<view class="action-section">
				<view class="checkbox">
					<image :src="allChecked ? '/static/selected.png' : '/static/select.png'" mode="aspectFit" @click="check('all')"></image>
					<view class="clear-btn" :class="{ show: allChecked }" @click="clearCart">清空</view>
				</view>
				<view class="total-box">
					<text class="price">合计：¥{{ total }}</text>
				</view>
				<button type="primary" class="no-border confirm-btn" @click="createOrder">去结算</button>
			</view>
		</view>
	</view>
</template>
<script>
// import { mapState } from 'vuex';
import uniNumberBox from '@/components/uni-number-box2.vue';
export default {
	components: {
		uniNumberBox
	},

	data() {
		return {
			total: 0, //总价格
			current: 0,
			flag: true,
			allChecked: false, //全选状态  true|false
			empty: false, //空白页现实  true|false
			CartProductList: [] //购物车商品列表
			
		};
	},
	onShow: function() {
		this.initCart();
		// this.calcTotal();
	},

	watch: {
		//显示空白页
		CartProductList(e) {
			let empty = e.length === 0 ? true : false;
			if (this.empty !== empty) {
				this.empty = empty;
			}
		}
	
	},
	onLoad(options) {
		//获取local缓存数据
		uni.getStorage({
			key: 'goodsData',
			success(res) {
				console.log(res.data);
			}
		});
	},

	methods: {
		//初始数据
		initCart() {
			this.$axios(this.$baseUrl.queryCartProduct, {
				userId: uni.getStorageSync('userId')
			}).then(res => {
				// console.log(res);
				let list = res.data.result;
				let CartProductList = list.map(item => {
					item.state = true;
					// item.amount=item.amount
					return item;
				});
				this.CartProductList = CartProductList;
				console.log(this.CartProductList,'7777')
				this.calcTotal(); //计算总价
			});
		},

		//监听image加载完成
		onImageLoad(key, index) {
			this.$set(this[key][index], 'loaded', 'loaded');
		},
		//监听image加载失败
		onImageError(key, index) {
			this[key][index].image = '/static/errorImage.jpg';
		},
		//删除
		deleteCartItem(index) {
			console.log(index);
			let that = this;
			uni.showModal({
				title: '提示',
				content: '确定要将该产品从购物车中移除吗?',
				success: function(res) {
					if (res.confirm) {
						that.$axios(that.$baseUrl.delCart, {
							productId: index,
							userId: uni.getStorageSync('userId')
						}).then(res => {
							if (res.statusCode == 200) {
								that.initCart();

								that.calcTotal();
							}
							// console.log(res);
						});

						// console.log('用户点击确定');
					} else if (res.cancel) {
						// console.log('用户点击取消');
					}
				}
			});
		},
		//数字框
		numberChange(data) {
			console.log(data);
			this.CartProductList[data.index].amount = data.newVal;
			// this.CartProductList[index].amount = data;

			this.calcTotal();
		},

		//选中状态处理
		check(type, index) {
			if (type === 'item') {
				console.log(111);
				this.CartProductList[index].state = !this.CartProductList[index].state;
			} else {
				console.log(222);
				const state = !this.allChecked;
				const CartProductList = this.CartProductList;
				CartProductList.forEach(item => {
					item.state = state;
				});
				this.allChecked = state;
			}
			this.calcTotal(type);
		},
		//计算价格
		calcTotal() {
			let list = this.CartProductList;
			if (list.length === 0) {
				this.empty = true;
				return;
			}
			let total = 0;
			let checked = true;
			list.forEach(item => {
				if (item.state === true) {
					total += item.discountPrice * item.amount;
				} else if (checked === true) {
					checked = false;
				}
			});
			this.allChecked = checked;
			this.total = Number(total.toFixed(2));
		},
		//创建订单
		createOrder() {
			let price = this.total;
			if (price == 0) {
				uni.showToast({
					title: '标题',
					duration: 2000
				});
				return;
			}

			let list = this.CartProductList;
			
			uni.setStorageSync('ORDER', list)
			console.log(uni.getStorageSync('ORDER'))
			// let goodsData = [];
			// list.forEach(item => {
			// 	if (item.state) {
			// 		this.$axios(this.$baseUrl.updateCart, {
			// 			productId: item.productId,
			// 			userId: 1,
			// 			amount: item.amount
			// 		});
			// 		uni.setStorageSync('ORDER', list)
			// 		// goodsData.push({
			// 		// 	productAttribute: item.productAttribute,
			// 		// 	amount: item.amount,
			// 		// 	productImg: item.productImg,
			// 		// 	productDescription: item.productDescription,
			// 		// 	discountPrice: item.discountPrice,
			// 		// 	price: price
			// 		// });
			// 	}
			// });
			
			uni.navigateTo({
				url: `/pages/order/createOrder`
			});
			
		}
	}
};
</script>

<style lang="scss">
.container {
	padding-bottom: 134upx;
	/* 空白页 */
	.empty {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100vh;
		padding-bottom: 100upx;
		display: flex;
		justify-content: center;
		flex-direction: column;
		align-items: center;
		background: #fff;
		image {
			width: 240upx;
			height: 160upx;
			margin-bottom: 30upx;
		}
		.empty-tips {
			display: flex;
			/* font-size: $font-sm+2upx;
				color: $font-color-disabled; */
			.navigator {
				/* color: $uni-color-primary; */
				margin-left: 16upx;
			}
		}
	}
}
/* 购物车列表项 */
.cart-item {
	display: flex;
	position: relative;
	padding: 30rpx;
	margin-bottom: 14rpx;
	box-shadow: 0 0 6upx 0 rgba(0, 0, 0, 0.5);
	.image-wrapper {
		width: 160rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-shrink: 0;
		padding-left: 50rpx;
		position: relative;
		image {
			width: 160rpx;
			height: 160rpx;
			vertical-align: middle;
			border-radius: 8rpx;
			background-size: cover;
		}
	}
	.checkbox {
		position: absolute;
		left: 0;
		z-index: 8;
		font-size: 56upx;
		line-height: 1;

		/* color: $font-color-disabled; */
		background: #fff;
		border-radius: 50%;
		uni-checkbox .uni-checkbox-input {
			border-radius: 50% !important;
		}
	}
	.item-right {
		display: flex;
		flex-direction: column;
		flex: 1;
		overflow: hidden;
		position: relative;
		padding-left: 30upx;
		.uni-numbox {
			position: absolute;
			right: 0;
			bottom: 0;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			width: 200upx;
			height: 60upx;
			background: #f5f5f5;
		}
		.title,
		.price {
			font-size: 30rpx;
			height: 40rpx;
			line-height: 40rpx;
		}
		.attr {
			font-size: 28rpx;
			color: darkgray;

			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 3;
			overflow: hidden;
		}
		.price {
			height: 50upx;
			line-height: 50upx;
			color: red;
		}
	}
	.del-btn {
		padding: 4upx 10upx;
		font-size: 34upx;
		height: 50upx;
		/* color: $font-color-light; */
	}
}
/* 底部栏 */
.action-section {
	/* #ifdef H5 */
	margin-bottom: 100upx;
	/* #endif */
	position: fixed;
	left: 0;
	bottom: 0;
	z-index: 95;
	display: flex;
	align-items: center;
	width: 690upx;
	height: 100upx;
	padding: 0 30upx;
	background: rgba(255, 255, 255, 0.9);
	box-shadow: 0 0 6upx 0 rgba(0, 0, 0, 0.5);
	// border-radius: 16upx;
	.checkbox {
		height: 52upx;
		position: relative;
		image {
			width: 52upx;
			height: 100%;
			position: relative;
			z-index: 5;
		}
	}
	.clear-btn {
		position: absolute;
		left: 26upx;
		top: 0;
		z-index: 4;
		width: 0;
		height: 52upx;
		line-height: 52upx;
		padding-left: 38upx;
		/* font-size: $font-base; */
		color: #fff;
		/* background: $font-color-disabled; */
		border-radius: 0 50px 50px 0;
		opacity: 0;
		transition: 0.2s;
		&.show {
			opacity: 1;
			width: 120upx;
		}
	}
	.total-box {
		flex: 1;
		display: flex;
		flex-direction: column;
		text-align: right;
		padding-right: 40upx;
		.price {
			/* font-size: $font-lg;
				color: $font-color-dark; */
		}
		.coupon {
			/* font-size: $font-sm;
				color: $font-color-light; */
			text {
				/* color: $font-color-dark; */
			}
		}
	}
	.confirm-btn {
		padding: 0 38upx;
		margin: 0;
		border-radius: 100px;
		height: 76upx;
		line-height: 76upx;
		font-size: $font-base + 2upx;
		background: #56ba53;
		box-shadow: 1px 2px 5px rgba(0, 0, 0, 0.5);
	}
}

/* 复选框选中状态 */
.action-section .checkbox.checked,
.cart-item .checkbox.checked {
	color: #56ba53;
}
.uni-number-box {
	right: 0;
	position: absolute;
}
</style>
