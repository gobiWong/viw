<template>
	<!--主盒子-->
	<view class="container">
		<!--左侧栏-->
		<view class="nav_left">
			<view
				class="f-item b-b"
				v-for="item in classificationList"
				:key="item.classificationId"
				:class="{ active: item.classificationId === currentId }"
				@click="tabtap(item.classificationId)"
			>
				{{ item.classificationName }}
			</view>
		</view>
		
		<!--右侧栏-->
		
		<scroll-view scroll-with-animation scroll-y class="nav_right">
			<view class="s-list">
				<text class="s-item">{{ productName }}</text>
				<view class="t-list">
					<view class="t-item" @click="navToList(titem.productId)" v-for="titem in classificationDetailList" :key="titem.productId">
						<image :src="titem.productImg"></image>
						<text class="t-item-desc">{{ titem.productDescription }}</text>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>
<script>
export default {
	data() {
		return {
			sizeCalcState: false,
			tabScrollTop: 0,
			currentId: 4,
			classificationList: [], //分类全部信息
			classificationDetailList: [], //商品分类详情
			productName: '',
			flist: [], //分类的名称
			slist: [],
			tlist: []
		};
	},
	onLoad() {
		this.loadData();
	},
	methods: {
		async loadData() {
			 //分类全部信息
			let list = await this.$axios(this.$baseUrl.queryAllClassification, {});
			this.classificationList = list.data.result;
			// console.log(this.classificationList);
			
			//默认显示当前页数据
			let res = await this.$axios(this.$baseUrl.queryAllProduct, { classificationId: this.currentId });
			this.classificationDetailList = res.data.result;
			this.productName = res.data.result[0].productName;
			
			// classificationList.forEach(item=>{
			// 	this.flist.push(item.classificationName)
			// })
			// list.forEach(item=>{
			// 	if(!item.pid){
			// 		this.flist.push(item);  //pid为父级id, 没有pid或者pid=0是一级分类
			// 	}else if(!item.picture){
			// 		this.slist.push(item); //没有图的是2级分类
			// 	}else{
			// 		this.tlist.push(item); //3级分类
			// 	}
			// })
		},
		//左侧一级分类点击
		tabtap(classificationId) {
			console.log(classificationId); //获取当前一级分类ID

			this.$axios(this.$baseUrl.queryAllProduct, { classificationId }).then(res => {
			
				this.classificationDetailList = res.data.result;
				this.productName = res.data.result[0].productName;
			});
			this.currentId = classificationId;

		},
		//跳转到详情页
		navToList(productId) {
			console.log('产品ID-' + productId);
			uni.navigateTo({
				url: `/pagesB/detail/detail?productId=${productId}`
			});
		}
		//一级分类点击
		// tabtap(item){
		// 	if(!this.sizeCalcState){
		// 		this.calcSize();
		// 	}
		//
		// 	this.currentId = item.id;
		// 	let index = this.slist.findIndex(sitem=>sitem.pid === item.id);
		// 	this.tabScrollTop = this.slist[index].top;
		// },
		//右侧栏滚动
		// asideScroll(e){
		// 	if(!this.sizeCalcState){
		// 		this.calcSize();
		// 	}
		// 	let scrollTop = e.detail.scrollTop;
		// 	let tabs = this.slist.filter(item=>item.top <= scrollTop).reverse();
		// 	if(tabs.length > 0){
		// 		this.currentId = tabs[0].pid;
		// 	}
		// },
		//计算右侧栏每个tab的高度等信息
		// calcSize(){
		// 	let h = 0;
		// 	this.slist.forEach(item=>{
		// 		let view = uni.createSelectorQuery().select("#main-" + item.id);
		// 		view.fields({
		// 			size: true
		// 		}, data => {
		// 			item.top = h;
		// 			h += data.height;
		// 			item.bottom = h;
		// 		}).exec();
		// 	})
		// 	this.sizeCalcState = true;
		// },
		// navToList(sid, tid){
		// 	uni.navigateTo({
		// 		url: `/pages/product/list?fid=${this.currentId}&sid=${sid}&tid=${tid}`
		// 	})
		// }
	}
};
</script>
<style lang="scss">
page,
.container {
	height: 100%;
	background-color: #f8f8f8;
}

.container {
	display: flex;
}
.nav_left {
	flex-shrink: 0;
	width: 200rpx;
	height: 100%;
	background-color: #eee;
}
.f-item {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100rpx;
	font-size: 28rpx;

	position: relative;
	&.active {
		color: skyblue;
		background: #f8f8f8;
		&:before {
			content: '';
			position: absolute;
			left: 0;
			top: 50%;
			transform: translateY(-50%);
			height: 36rpx;
			width: 8rpx;
			background-color: skyblue;
			border-radius: 0 4rpx 4rpx 0;
			opacity: 0.8;
		}
	}
}

/*右侧样式*/
.nav_right {
	flex: 1;
	overflow: hidden;
	background-color: #f8f8f8;
	padding-left: 16rpx;
}

.s-item {
	display: flex;
	align-items: center;
	height: 70rpx;
	padding-top: 8rpx;
	font-size: 28rpx;
}
.t-list {
	display: flex;
	flex-wrap: wrap;
	width: 100%;
	background-color: #f8f8f8;
	padding-top: 12rpx;
	&:after {
		content: '';
		flex: 99;
		height: 0;
	}
}
.t-item {
	flex-shrink: 0;
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
	width: 46%;
	margin: 1%;
	border-radius:10rpx;
border:1px solid rgba(238,238,238,1);
	// box-shadow: 0 0 3rpx 0 rgba(0, 0, 0, 0.5);
	height: 280rpx;
	font-size: 26rpx;
	color: #666;
	padding-bottom: 20rpx;
	

	image {
		width: 140rpx;
		height: 140rpx;
		background-color: #f8f8f8;
		background-size: cover;
	}
	.t-item-desc{
		overflow: hidden;
		text-overflow: ellipsis;
		-webkit-line-clamp: 2; //在第几行显示...
		display: -webkit-box;
		-webkit-box-orient: vertical;
  

   
	}
}
</style>
