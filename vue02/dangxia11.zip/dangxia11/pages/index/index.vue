<template>
	<view class="content">
		<!-- 搜素框 -->
		<view class="mp-search-box">
			<input class="ser-input" type="text" placeholder="搜索商品" />
			<image class="ser-img" src="../../static/home_search_ic@2x.png" mode=""></image>
		</view>
		<!-- 轮播图 -->
		<view class="carousel-section">
			<view class="titleNview-background"></view>
			<swiper class="carousel" circular="true" indicator-active-color="blue" :indicator-dots="indicatorDots" :autoplay="autoplay" :interval="interval" :duration="duration">
				<swiper-item v-for="(item, index) in carouselList" :key="index" class="carousel-item"><image :src="item.carouselLink" /></swiper-item>
			</swiper>
		</view>
		<!-- 甜甜圈 -->
		<view class="cate-section">
			<view class="cate-item">
				<image src="/static/temp/c1.png"></image>
				<text>拼团团</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c2.png"></image>
				<text>砍砍价</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c3.png"></image>
				<text>秒杀</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c4.png"></image>
				<text>积分</text>
			</view>
			<view class="cate-item">
				<image
					src="/static/temp/c5.png"
					@click="
						toCategory
					"
				></image>
				<text>分类</text>
			</view>
		</view>
		<!-- 最新公告 -->
		<view class="new-notice"><image class="notice-img" :src="noticeList.announcementUrl" /></view>
		<!-- 礼盒专区 -->

		<!-- 分类专区 -->
		<view class="gift-box" v-for="(item, index) in classificationList" :key="index">
			<view class="gift-title">
				<text>{{ item.classificationName }}专区</text>
				<text></text>
			</view>
			<view class="gift-list">
				<view class="gift-list-item" v-for="itemList in item.productList" :key="itemList.productId" @click="navToList(itemList.productId)">
					<view class="list-item-img"><image class="item-img" :src="itemList.productImg" mode=""></image></view>
					<view class="list-item-describe">
						<text class="item-describe-content">{{ itemList.productDescription }}</text>
					</view>
					<view class="list-item-price">
						<text class="item-price-now">¥{{ itemList.discountPrice }}</text>
						<text class="item-price-old">¥{{ itemList.originalPrice }}</text>
						<view class="add-cart-img"><image src="../../static/home_add_ic@2x.png" mode=""></image></view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import { getRandomArrayElements } from '../../common/util.js';
export default {
	data() {
		return {
			titleNViewBackground: '',
			swiperCurrent: 0,
			swiperLength: 4,
			carouselList: [], //轮播图
			noticeList: '', //公告图
			goodsList: [],
			indicatorDots: true,
			autoplay: false,
			interval: 2000,
			duration: 500,
			classificationList: [] //全部分类
		};
	},
	async onLoad() {
		//请求首页轮播图
		const carouselResult = await this.$axios(this.$baseUrl.carouselMap, {});
		this.carouselList = carouselResult.data.result;
		//首页公告图片
		const queryDataResult = await this.$axios(this.$baseUrl.queryData, {});
		this.noticeList = queryDataResult.data.result[0];

		//查询所有商品的分类
		const queryAllClassification = await this.$axios(this.$baseUrl.queryAllClassification, {
			// classificationId: 1
		});

		this.classificationList = getRandomArrayElements(queryAllClassification.data.result, 2);

		console.log(this.classificationList);
	},
	methods: {
		//详情页

		navToList(productId) {
			console.log('产品ID-' + productId);
			uni.navigateTo({
				url: `/pagesB/detail/detail?productId=${productId}`
			});
		},
		toCategory(){
			uni.switchTab({
				url: '../category/category'
			})
		},
		
	}
};
</script>

<style lang="scss">
.content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 30rpx;
}
/*搜索框*/
.mp-search-box {
	position: relative;
	box-sizing: border-box;
	padding: 20rpx 30rpx;
	.ser-input {
		flex: 1;
		text-align: left;
		padding-left: 60rpx;
		font-size: 26rpx;
		width: 630rpx;
		height: 60rpx;
		color: #999999;
		background: #f9f9f9;
		border-radius: 30rpx;
		border: 1rpx solid #c0c0c0;
	}
	.ser-img {
		position: absolute;
		width: 36rpx;
		height: 36rpx;
		top: 32%;
		left: 50rpx;
	}
}
/*轮播图*/
.carousel-section {
	padding: 30rpx;
	position: relative;
	width: 100%;
	padding-top: 10rpx;

	.titleNview-background {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 426rpx;
		transition: 0.4s;
	}
	.carousel {
		width: 100%;
		height: 350rpx;

		.carousel-item {
			width: 100%;
			height: 100%;

			overflow: hidden;
		}

		image {
			width: 100%;
			height: 100%;
			border-radius: 10rpx;
		}
	}
}

/*轮播图点点*/
/*甜甜圈*/
.cate-section {
	width: 100%;
	display: flex;
	justify-content: space-around;
	align-items: center;
	padding: 30rpx 22rpx;
	background: #fff;
	.cate-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		font-size: 26rpx;
	}
	/* 原图标颜色太深,不想改图了,所以加了透明度 */
	image {
		width: 100rpx;
		height: 100rpx;
		margin-bottom: 14rpx;
		border-radius: 50%;
		// opacity: 0.7;
		// box-shadow: 4rpx 4rpx 20rpx rgba(250, 67, 106, 0.3);
	}
}
/*最新公告*/
.new-notice {
	width: 690rpx;
	height: 230rpx;
	background: rgba(249, 238, 234, 1);
	border-radius: 20rpx;
	.notice-img {
		width: 100%;
		height: 100%;
		border-radius: 20rpx;
		vertical-align: middle;
		background-size: cover;
	}
}

/*礼盒专区*/
.gift-box,
.fruits-box {
	.gift-title {
		margin: 35rpx 0 35rpx 4rpx;
	}
	.gift-list {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
		.gift-list-item {
			margin: 5rpx 0;
			width: 336rpx;
			height: 520rpx;
			// background-color: #eeeeee;
			border: 1rpx solid rgba(238, 238, 238, 1);
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-direction: column;
			.list-item-img {
				width: 330rpx;
				height: 330rpx;
				background: rgba(250, 252, 255, 1);
				border-radius: 10rpx 10rpx 0rpx 0rpx;
				.item-img {
					width: 100%;
					height: 100%;
					background-size: cover;
				}
			}
			.list-item-describe {
				width: 320rpx;

				font-size: 30rpx;
				font-family: PingFangSC-Medium;
				font-weight: 500;
				color: rgba(51, 51, 51, 1);

				.item-describe-content {
					overflow: hidden;
					text-overflow: ellipsis;
					-webkit-line-clamp: 2; //在第几行显示...
					display: -webkit-box;
					-webkit-box-orient: vertical;
				}
			}
			.list-item-price {
				width: 100%;
				display: flex;
				height: 48rpx;
				line-height: 48rpx;
				padding-bottom: 8rpx;
				align-items: center;
				.item-price-now {
					width: 105rpx;
					padding-left: 10rpx;
					font-size: 34rpx;
					font-family: PingFangSC-Medium;
					font-weight: 500;
					color: rgba(255, 0, 45, 1);
				}
				.item-price-old {
					text-decoration: line-through;
					vertical-align: baseline;
					padding-top: 8rpx;
					padding-right: 8rpx;
					font-size: 26rpx;
					font-family: PingFangSC-Regular;
					font-weight: 400;
					color: rgba(153, 153, 153, 1);

					margin-right: 80rpx;
				}
				.add-cart-img > image {
					width: 45rpx;
					height: 45rpx;
					margin: 0 13rpx;
					// background: url(/static/tab-cart-current.png) no-repeat;
					vertical-align: middle;
					background-size: cover;
				}
			}
		}
	}
}
</style>
