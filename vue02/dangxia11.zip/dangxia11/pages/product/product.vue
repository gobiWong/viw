<template>
	<view class="eva-section">
		<view class="e-header">
			<text class="tit">评价</text>
			<text>(86)</text>
			<text class="tip">好评率 100%</text>
			<text class="yticon icon-you"></text>
		</view> 
		<view class="eva-box">
			<image class="portrait" src="http://img3.imgtn.bdimg.com/it/u=1150341365,1327279810&fm=26&gp=0.jpg" mode="aspectFill"></image>
			<view class="right">
				<text class="name">Leo yo</text>
				<text class="con">商品收到了，79元两件，质量不错，试了一下有点瘦，但是加个外罩很漂亮，我很喜欢</text>
				<view class="bot">
					<text class="attr">购买类型：XL 红色</text>
					<text class="time">2019-04-01 19:21</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style>
</style>
