<template>
	<view class="content">
		<!-- 小程序头部兼容 -->

		<view class="mp-search-box"><input class="ser-input" type="text" value="输入关键字搜索" disabled /></view>

		<view class="carousel-section">
			<!-- 标题栏和状态栏占位符 -->
			<!-- <view class="titleNview-placing"></view> -->
			<!-- 背景色区域 -->
			<view class="titleNview-background"></view>
			<swiper class="carousel">
				<swiper-item><image src="/static/temp/banner1.jpg" /></swiper-item>
				<swiper-item><image src="/static/temp/banner2.jpg" /></swiper-item>
				<swiper-item><image src="/static/temp/banner3.jpg" /></swiper-item>
				<swiper-item><image src="/static/temp/banner4.jpg" /></swiper-item>
			</swiper>
			<!-- 自定义swiper指示器 -->
			<!-- 	<view class="swiper-dots">
				<text class="num">{{swiperCurrent+1}}</text>
				<text class="sign">/</text>
				<text class="num">{{swiperLength}}</text>
			</view> -->
		</view>
		

		<view class="cate-section">
			<view class="cate-item">
				<image src="/static/temp/c3.png"></image>
				<text>环球美食</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c5.png"></image>
				<text>个护美妆</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c6.png"></image>
				<text>营养保健</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c7.png"></image>
				<text>家居厨卫</text>
			</view>
			<view class="cate-item">
				<image src="/static/temp/c8.png"></image>
				<text>速食生鲜</text>
			</view>
		</view>

		<!-- 分类推荐楼层 -->
		<view class="category-floor">
			<view class="today-buy">左</view>
			<view class="limit">
				<view class="limit-buy">右上</view>
				<view class="limit-food">右下</view>
			</view>
		</view>
		<!-- 分类推荐专场Special -->
		<view class="special">
			<view class="fresh-special">生鲜</view>
			<view class="snacks-special">零食</view>
			<view class="fruits-special">水果</view>
		</view>

		<!-- 精选商品-->
		<view class="electeds-goods"><text>精选商品</text></view>
		<!-- 商品列表 -->
		<view class="goods-list">
			<view class="goods-detail">
				<view class="detail-img">图片1</view>
				<view class="detail-info">
					<view class="detail-info-title">欧舒丹甜蜜樱花沐浴啫喱/身体乳套装</view>
					<view class="detail-info-introduce">法国品牌 | 过敏包退 | 官方直售</view>
					<view class="detail-info-sale">积分兑换 月销20111件</view>
					<view class="detail-info-price">¥378</view>
				</view>
			</view>
			<view class="goods-detail">
				<view class="detail-img">图片2</view>
				<view class="detail-info">
					<view class="detail-info-title">欧舒丹甜蜜樱花沐浴啫喱/身体乳套装</view>
					<view class="detail-info-introduce">法国品牌 | 过敏包退 | 官方直售</view>
					<view class="detail-info-sale">积分兑换 月销20111件</view>
					<view class="detail-info-price">¥378</view>
				</view>
			</view>
			<view class="goods-detail">
				<view class="detail-img">图片3</view>
				<view class="detail-info">
					<view class="detail-info-title">欧舒丹甜蜜樱花沐浴啫喱/身体乳套装</view>
					<view class="detail-info-introduce">法国品牌 | 过敏包退 | 官方直售</view>
					<view class="detail-info-sale">积分兑换 月销20111件</view>
					<view class="detail-info-price">¥378</view>
				</view>
			</view>
		</view>
		<!-- 夏日清单 -->
		<view class="summer-list">
			<view class="summer-title">
				<text>
					夏日必买清单
					<text>查看更多></text>
				</text>
			</view>
			<view class="summer-list-content">
				<view class="summer-list-info">
					<view class="summer-list-img">
						A
						<image src="" mode=""></image>
					</view>
					<text class="summer-list-name">欧舒丹甜蜜樱</text>
					<view>
						<text class="summer-list-price">¥378</text>
						<text class="summer-list-sale">月销201件</text>
					</view>
				</view>
				<view class="summer-list-info">
					<view class="summer-list-img">
					B
						<image src="" mode=""></image>
					</view>
					<text class="summer-list-name">欧舒丹甜蜜樱</text>
					<view>
						<text class="summer-list-price">¥378</text>
						<text class="summer-list-sale">月销201件</text>
					</view>
				</view>
				<view class="summer-list-info">
					<view class="summer-list-img">
						C
						<image src="" mode=""></image>
					</view>
					<text class="summer-list-name">欧舒丹甜蜜樱</text>
					<view>
						<text class="summer-list-price">¥378</text>
						<text class="summer-list-sale">月销201件</text>
					</view>
				</view>
			</view>
		</view>
		<view class="goods-list">
			<view class="goods-detail">
				<view class="detail-img">图片1</view>
				<view class="detail-info">
					<view class="detail-info-title">欧舒丹甜蜜樱花沐浴啫喱/身体乳套装</view>
					<view class="detail-info-introduce">法国品牌 | 过敏包退 | 官方直售</view>
					<view class="detail-info-sale">积分兑换 月销20111件</view>
					<view class="detail-info-price">¥378</view>
				</view>
			</view>
			<view class="goods-detail">
				<view class="detail-img">图片2</view>
				<view class="detail-info">
					<view class="detail-info-title">欧舒丹甜蜜樱花沐浴啫喱/身体乳套装</view>
					<view class="detail-info-introduce">法国品牌 | 过敏包退 | 官方直售</view>
					<view class="detail-info-sale">积分兑换 月销20111件</view>
					<view class="detail-info-price">¥378</view>
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			title: 'Hello'
		};
	},
	onLoad() {},
	methods: {}
};
</script>

<style lang="scss">
	page {
		.cate-section {
			position: relative;
			z-index: 5;
			border-radius: 16upx 16upx 0 0;
			margin-top: -20upx;
		}
		.carousel-section {
			padding: 0;
			.titleNview-placing {
				padding-top: 0;
				height: 0;
			}
			.carousel {
				.carousel-item {
					padding: 0;
				}
			}
			.swiper-dots {
				left: 45upx;
				bottom: 40upx;
			}
		}
	}
.content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 30rpx;
}

.mp-search-box {
	// position: absolute;
	// left: 0;
	// top: 30rpx;
	// z-index: 9999;
	// width: 100%;
	padding: 20rpx 30rpx;
	.ser-input {
		flex: 1;
		// height: 56upx;
		// line-height: 56upx;
		text-align: center;
		font-size: 14rpx;
		// color: $font-color-base;
		width: 690rpx;
		height: 60rpx;
		background: rgba(244, 244, 244, 1);
		border-radius: 30rpx;
		border: 1rpx solid #c0c0c0;
	}
}

// /* #endif */
// .ser-input {
// 	border: 0.5rpx solid #c0c0c0;
// }
.carousel-section {
	padding: 30rpx;
	position: relative;
	width: 100%;
	padding-top: 10rpx;

	.titleNview-placing {
		height: var(--status-bar-height);
		padding-top: 44rpx;
		box-sizing: content-box;
	}

	.titleNview-background {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 426upx;
		transition: 0.4s;
	}
}
.carousel {
	width: 100%;
	height: 350upx;

	.carousel-item {
		width: 100%;
		height: 100%;
		padding: 0 28rpx;
		overflow: hidden;
	}

	image {
		width: 100%;
		height: 100%;
		border-radius: 10upx;
	}
}

.cate-section {
	width: 100%;
	display: flex;
	justify-content: space-around;
	align-items: center;
	// flex-wrap:wrap;
	padding: 30rpx 22rpx;
	background: #fff;
	.cate-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		// font-size: $font-sm + 2upx;
		font-size: 26rpx;
		// color: $font-color-dark;
	}
	/* 原图标颜色太深,不想改图了,所以加了透明度 */
	image {
		width: 100rpx;
		height: 100rpx;
		margin-bottom: 14rpx;
		border-radius: 50%;
		opacity: 0.7;
		box-shadow: 4rpx 4rpx 20rpx rgba(250, 67, 106, 0.3);
	}
}

/* 今日推荐*/
.category-floor {
	width: 100%;
	height: 464rpx;
	margin-bottom:10rpx;
	background-color: #8f8f94;
	display: flex;
	justify-content: space-between;
	align-items: center;
	.today-buy {
		width: 346rpx;
		height: 462rpx;
		margin-right: 8rpx;
		box-sizing: border-box;
		background: #c0c0c0;
	}
	.limit {
		flex: 1;
		display: flex;
		flex-direction: column;
		align-items: center;
		.limit-buy {
			width: 332rpx;
			height: 269rpx;
			margin-bottom: 10rpx;
			background-color: pink;
		}
		.limit-food {
			width: 332rpx;
			height: 182rpx;
			background-color: darkolivegreen;
		}
	}
}
/*专场推荐*/
.special {
	display: flex;
	justify-content: space-around;
	align-items: center;
	box-sizing: border-box;
	.fresh-special,
	.snacks-special,
	.fruits-special {
		width: 223rpx;
		height: 310rpx;
		background-color: antiquewhite;
	}
	.snacks-special {
		margin: 0 10rpx;
	}
}
/*精选商品*/
.electeds-goods {
	text-align: left;
	width: 179rpx;
	height: 62rpx;
	font-size: 44rpx;
	font-family: PingFangSC-Semibold;
	font-weight: 600;
	color: rgba(51, 51, 51, 1);
	line-height: 62rpx;
}
/*商品列表*/
.goods-list {
	width: 100%;
	.goods-detail:after {
		content: '';
		position: absolute;
		left: 0;
		bottom: -20rpx;
		width: 100%;
		height: 2rpx;
		background-color: #eeeeee;
	}
	.goods-detail {
		margin: 40rpx 0;
		position: relative;
		display: flex;
		justify-content: center;
		.detail-img {
			width: 200rpx;
			height: 260rpx;
			margin-right: 32rpx;
			background: rgba(241, 248, 255, 1);
			border-radius: 2rpx;
			background-color: slateblue;
		}

		.detail-info {
			flex: 1;
			display: flex;
			flex-direction: column;
			background-color: lightblue;
			width: 454rpx;
			.detail-info-title {
				height: 96rpx;
				font-size: 34rpx;
				font-family: PingFangSC-Medium;
				font-weight: 500;
				color: rgba(51, 51, 51, 1);
				line-height: 48rpx;
			}
			.detail-info-introduce {
				width: 330rpx;
				height: 33rpx;
				font-size: 24rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
				line-height: 33rpx;
			}
			.detail-info-sale {
				height: 33rpx;
				font-size: 24rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
				line-height: 33rpx;
			}
			.detail-info-price {
				width: 95rpx;
				height: 56rpx;
				font-size: 40rpx;
				font-family: PingFangSC-Medium;
				font-weight: 500;
				color: rgba(255, 59, 48, 1);
				line-height: 56rpx;
			}
		}
	}
}
/*夏日必买清单*/

.summer-list {
	width: 100%;
	.summer-title {
		height: 48rpx;
		font-size: 34rpx;
		font-family: PingFangSC-Semibold;
		font-weight: 600;
		color: rgba(51, 51, 51, 1);
		line-height: 48rpx;
	}
	.summer-list-content {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.summer-list-info {
			width: 219rpx;
			height: 397rpx;
			background-color: #c0c0c0;
			.summer-list-img {
				width: 219rpx;
				height: 219rpx;
				background: rgba(241, 248, 255, 1);
			}
			.summer-list-name {
				// width:181px;
				height: 42rpx;
				font-size: 30rpx;
				font-family: PingFangSC-Medium;
				font-weight: 500;
				color: rgba(51, 51, 51, 1);
				line-height: 42rpx;
			}
			.summer-list-price {
				// width:85px;
				height: 50rpx;
				font-size: 36rpx;
				font-family: PingFangSC-Medium;
				font-weight: 500;
				color: rgba(255, 59, 48, 1);
				line-height: 50rpx;
			}
			.summer-list-sale {
				// width:111px;
				height: 33rpx;
				font-size: 24rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
				line-height: 33rpx;
			}
		}
	}
}
.text-area {
	display: flex;
	justify-content: center;
}

.title {
	font-size: 36rpx;
	color: #8f8f94;
}
</style>
