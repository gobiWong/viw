<template>
	<view class="content">
		<!-- 用户 -->
		<view class="user-section">
			<image class="bg" src="http://47.98.134.208/dx_static/static/dx_img/user_bg.png"></image>
			<view class="user-info-box">
				<!-- <view v-if="isCanUse" class="portrait-box"><image class="portrait" src="../../static/missing-face.png"></image></view> -->
				<view class="portrait-box"><image class="portrait" :src="avatarUrl ? avatarUrl : '../../static/missing-face.png'"></image></view>
				<view v-if="!isCanUse" class="info-box">
					<text class="username">{{ nickName }}</text>
				</view>
				<button v-if="isCanUse" class="bottom" open-type="getUserInfo" withCredentials="true" lang="zh_CN" @getuserinfo="wxGetUserInfo">点击显示微信头像</button>
			</view>
		</view>
		<!-- 订单 -->
		<view class="order-section">
			<view class="order-title">
				<text class="title-my">我的订单</text>

				<view class="title-all" @click="navTo('/pages/order/order?state=0')">
					全部订单
					<image src="../../static/my_right_ic@2x.png" mode=""></image>
				</view>
			</view>
			<view class="order-items">
				<view class="order-item" @click="navTo('/pages/order/order?state=1')">
					<view class="item-logo"><image src="../../static/my_pay_ic@2x.png" mode=""></image></view>
					<text class="item-text">待付款</text>
				</view>
				<view class="order-item" @click="navTo('/pages/order/order?state=2')">
					<view class="item-logo"><image src="../../static/my_send_ic@2x.png" mode=""></image></view>
					<text class="item-text">待发货</text>
				</view>
				<view class="order-item" @click="navTo('/pages/order/order?state=3')">
					<view class="item-logo"><image src="../../static/my_deliver_ic@2x.png" mode=""></image></view>
					<text class="item-text">已发货</text>
				</view>
				<view class="order-item" @click="navTo('/pages/order/order?state=4')">
					<view class="item-logo"><image src="../../static/my_comment_ic@2x.png" mode=""></image></view>
					<text class="item-text">待评价</text>
				</view>
				<view class="order-item" @click="navTo('/pages/service/service')">
					<view class="item-logo"><image src="../../static/my_recharge_ic@2x.png" mode=""></image></view>
					<text class="item-text">退款/售后</text>
				</view>
			</view>
		</view>

		<!-- 选项 -->
		<view class="select-tabs">
			<view class="select-item">
				<view class="select-item-logo"><image src="../../static/my_yhq_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">我的优惠券</text>
			</view>
			<view class="select-item">
				<view class="select-item-logo"><image src="../../static/my_pt_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">我的拼团</text>
			</view>
			<view class="select-item">
				<view class="select-item-logo"><image src="../../static/my_jf_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">我的积分</text>
			</view>
			<view class="select-item">
				<view class="select-item-logo"><image src="../../static/my_kj_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">我的砍价</text>
			</view>
			<view class="select-item">
				<view class="select-item-logo"><image src="../../static/my_tgy_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">推广员中心</text>
			</view>
			<view class="select-item" >
				<view class="select-item-logo"><image src="../../static/my_kf_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">客服与帮助</text>
			</view>
			<view class="select-item" @click="navTo('/pagesA/address/address')">
				<view class="select-item-logo"><image src="../../static/my_shdz_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">收货地址</text>
			</view>
			<view class="select-item" @click="navTo('/pages/set/set')">
				<view class="select-item-logo"><image src="../../static/my_sz_ic@2x.png" mode=""></image></view>
				<text class="select-item-text">设置</text>
			</view>
			<!-- <view v-if="false
			" class="select-item">
				<view class="select-item-logo"></view>
				<text class="select-item-text">我的优惠券</text>
			</view> -->
		</view>
	</view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
export default {
	data() {
		return {
			text: '',
			SessionKey: '',
			OpenId: '',
			nickName: uni.getStorageSync('wxNickName') || this.nickName,
			avatarUrl: uni.getStorageSync('wxAvatarUrl') || this.avatarUrl,
			isCanUse: uni.getStorageSync('isCanUse') || true //默认为true
		};
	},
	onShow() {},
	onLoad() {
		this.login();
	},
	computed: {
		...mapState(['hasLogin'])
	},

	methods: {
		navTo(url) {
			// if(!this.hasLogin){
			// 	url = '/pages/public/login';
			// }
			uni.navigateTo({
				url
			});
		},
		login() {
			let _this = this;
			// uni.showLoading({
			// 	title: '登录中...'
			// });

			uni.login({
				provider: 'weixin',
				success: function(loginRes) {
					let code = loginRes.code;
					console.log(code);
					// uni.setStorageSync('code', code); //记录登入码
					// if (!_this.isCanUse) {
					// 	//非第一次授权获取用户信息
					// 	uni.getUserInfo({
					// 		provider: 'weixin',
					// 		success: function(infoRes) {
					// 			//获取用户信息后向调用信息更新方法
					// 			let nickName = infoRes.userInfo.nickName; //昵称
					// 			let avatarUrl = infoRes.userInfo.avatarUrl; //头像
					// 			_this.updateUserInfo(); //调用更新信息方法
					// 		}
					// 	});
					// }
					//发起网络请求;
					_this
						.$axios(_this.$baseUrl.queryOpenId, {
							code: code
						})
						.then(res => {
							console.log(res);
							uni.setStorage({
								key: 'openId',
								data: res.data.result.openId
							});
							uni.hideLoading();
						});

					//2.将用户登录code传递到后台置换用户SessionKey、OpenId等信息
					// uni.request({
					// 	url: '服务器地址',
					// 	data: {
					// 		code: code
					// 	},
					// 	method: 'GET',
					// 	header: {
					// 		'content-type': 'application/json'
					// 	},
					// 	success: res => {
					// 		//openId、或SessionKdy存储//隐藏loading
					// 		uni.hideLoading();
					// 	}
					// });
				}
			});
		},

		wxGetUserInfo() {
			// debugger;
			let _this = this;
			uni.getUserInfo({
				provider: 'weixin',
				success: function(infoRes) {
					// console.log(infoRes);
					// console.log(uni.getStorageSync('openId'))
					uni.setStorageSync({
						//缓存用户登陆状态
						key: 'wxNickName',
						data: infoRes.userInfo.nickName
					});
					uni.setStorageSync({
						//缓存用户登陆状态
						key: 'wxAvatarUrl',
						data: infoRes.userInfo.avatarUrl
					});
					_this.nickName = infoRes.userInfo.nickName; //昵称
					_this.avatarUrl = infoRes.userInfo.avatarUrl; //头像
					_this.isCanUse = !_this.isCanUse;
					//发起网络请求换取userId;
					_this
						.$axios(_this.$baseUrl.insertUserLogin, {
							userName: _this.nickName,
							wxNick: _this.nickName,
							wxOpenid: uni.getStorageSync('openId')
						})
						.then(res => {
							console.log(res.data.result);
							uni.setStorage({
								key: 'userId',
								data: res.data.result
							});

							// if()
							// uni.setStorage({
							// 	key: 'openId',
							// 	data: res.data.result.openId
							// });
							// uni.hideLoading();
						});
					// try {
						uni.setStorageSync('isCanUse', false); //记录是否第一次授权 false:表示不是第一次授权
					// 	_this.updateUserInfo();
					// } catch (e) {}
				},
				fail(res) {
					console.log('取消授权');
				}
			});
		}
	}
};
</script>

<style lang="scss">
.content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
}
/*用户信息*/
.user-section {
	width: 100%;
	height: 430rpx;
	text-align: center;
	background: no-repeat;
	position: relative;
	display: flex;
	justify-content: center;
	align-items: center;
	.bg {
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		// filter: blur(1rpx);
		opacity: 0.7;
	}
	.user-info-box {
		height: 260rpx;
		line-height: 260rpx;
		padding-left: 31rpx;
		flex: 1;
		display: flex;
		align-items: center;
		position: relative;
		z-index: 1;
		.portrait {
			width: 130rpx;
			height: 130rpx;
			border: 5rpx solid #fff;
			border-radius: 50%;
			opacity: 0.7;
		}
		.info-box {
			line-height: 360rpx;
		}
		.bottom {
			margin-right: 300rpx;
			margin-bottom: 100rpx;
			opacity: 0.5;
			border: none;
			font-size: 28rpx;
		}
	}
}
/*我的訂單*/
.order-section {
	width: 690rpx;
	height: 270rpx;
	background: rgba(255, 255, 255, 1);
	box-shadow: 0px 10rpx 25rpx 0rpx rgba(237, 237, 237, 1);
	border-radius: 20rpx;
	margin: 0 20rpx;
	margin-top: -100rpx;
	z-index: 1;

	.order-title {
		width: 100%;

		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 50rpx;
		.title-my {
			height: 48rpx;
			font-size: 34rpx;
			font-family: PingFangSC-Medium;
			font-weight: 500;
			color: rgba(51, 51, 51, 1);
			line-height: 48rpx;
			margin: 43rpx 0 0 33rpx;
		}
		.title-all {
			height: 33rpx;
			font-size: 24rpx;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			margin: 48rpx 38rpx 0 0;
			color: rgba(153, 153, 153, 1);
			line-height: 33rpx;

			image {
				width: 24rpx;
				height: 24rpx;
				background-size: cover;
				vertical-align: middle;
			}
		}
	}
	.order-items {
		margin-top: 60rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;

		.order-item {
			width: 120rpx;
			height: 124rpx;
			// background-color: cadetblue;
			text-align: center;
			.item-logo {
				width: 55rpx;
				height: 55rpx;
				margin: 0 auto;
				// background: rgba(224, 224, 224, 1);
				// border-radius: 50%;
				image {
					width: 48rpx;
					height: 48rpx;
					background-size: cover;
				}
			}
			.item-text {
				font-size: 24rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(51, 51, 51, 1);
				line-height: 32rpx;
			}
		}
	}
}

/*选项*/
.select-tabs {
	width: 690rpx;
	height: 560rpx;
	margin: 0 15rpx;
	// background: rgba(255, 255, 255, 1);
	box-shadow: 0px 6rpx 30rpx 6rpx rgba(237, 237, 237, 1);
	border-radius: 20rpx;
	margin: 50rpx 0 30rpx 0;
	display: flex;

	// justify-content: space-between;
	flex-wrap: wrap;
	align-items: center;
	align-items: flex-start;
	.select-item {
		margin: 10rpx;
		width: 30%;
		height: 30%;
		text-align: center;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		// background-color: palegreen;
		.select-item-logo {
			margin: 0 auto;
			width: 66rpx;
			height: 66rpx;
			// background: rgba(216, 216, 216, 1);
			image {
				width: 100%;
				height: 100%;
				background-size: cover;
				vertical-align: middle;
			}
		}
		.select-item-text {
			height: 32rpx;
			font-size: 26rpx;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 62rpx;
		}
	}
}
</style>
