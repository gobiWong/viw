<template>
	<view class="wuliu-content">
		<view class="kuaidi-gs">
			<text class="gs-title">物流公司：</text><text  class="gs-name">{{ item.shipperCode }}（中通快递）</text>
		</view>
		<view class="kuaidi-dh">
			<text class="dh-title">订单编号：</text><text class="dh-name">{{ item.logisticCode }}</text>
		</view>
		<view class="wuliu-info-list" v-for="(item, index) in traces" :key="index">
			<view class="">
				<text class="info-time">{{ item.acceptTime }}</text>
			</view>
			<text class="info-detail">{{ item.acceptStation }}</text>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			wuliuInfo: null, //物流信息
			traces: [] //
		};
	},
	onLoad(options) {
		console.log(options);
		this.$axios(this.$baseUrl.logisticsInfo, {
			shipperCode: options.shipperCode,
			logisticCode: options.logisticCode
		}).then(res => {
			console.log(res.data);
			this.wuliuInfo = res.data.result;
			let { traces } = res.data.result;
			this.traces = traces;
		});
	}
};
</script>

<style lang="scss">
.wuliu-content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 30rpx;
	background: rgba(248, 248, 248, 1);
}
.kuaidi-gs{
	.gs-title{
		font-size: 32rpx;
	}
	.gs-name{
				font-size: 26rpx;
	}
}
.wuliu-info-list {
	width:100%;
	.info-time {
		font-size: 32rpx;
		background-color: #eee;
	}
	.info-detail {
		font-size: 26rpx;
	}
}
</style>
