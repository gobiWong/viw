<template>
	<view class="content">
		<!-- 轮播图 -->
		<view class="carousel-section">
			<view class="titleNview-background"></view>
			<swiper class="carousel" circular="true" indicator-active-color="blue" :indicator-dots="indicatorDots" :autoplay="autoplay" :interval="interval" :duration="duration">
				<swiper-item v-for="(item, index) in detailImg" :key="index" class="carousel-item"><image class="detail-banner" :src="item" mode="aspectFill" /></swiper-item>
			</swiper>
		</view>
		<!-- 商品描述 -->
		<view class="goods-info">
			<view class="title">
				<text>{{ ProductDetailInfo.productDescription }}</text>
			</view>
			<!-- 	<view class="intro"><text>口味香甜鲜美，此处预留一行字段描述卖点</text></view> -->
			<view class="price">
				<view class="price-sale">
					<text class="price-now">
						<text class="price-sale-color">¥{{ ProductDetailInfo.discountPrice }}</text>
					</text>
					<text class="price-old">¥{{ ProductDetailInfo.originalPrice }}</text>
				</view>

				<text class="price-amount">已售{{ ProductDetailInfo.soldNumber }}</text>
			</view>
		</view>
		<!-- 商品详情 -->
		<view class="detail-desc">
			<view class="d-header"><text>商品详情</text></view>
			<view class="detail-params">
				<view class=" item-params">
					<text class="item-params-left">产地</text>
					<text class="item-params-right">{{ productParam ? productParam.brand : '暂无数据' }}</text>
				</view>
				<view class="item-params">
					<text class="item-params-left">规格</text>
					<text class="item-params-right">{{ productParam.marketPrice }}</text>
				</view>
				<view class="item-params">
					<text class="item-params-left">重量</text>
					<text class="item-params-right">{{ productParam.price }}</text>
				</view>
				<view class="item-params">
					<text class="item-params-left">包装</text>
					<text class="item-params-right">{{ productParam.specs }}</text>
				</view>
				<view class=" item-params">
					<text class="item-params-left">保质期</text>
					<text class="item-params-right">{{ productParam.volume }}</text>
				</view>
				<view class="item-params">
					<text class="item-params-left">贮存方式</text>
					<text class="item-params-right">{{ productParam.parameterId }}</text>
				</view>
			</view>
		</view>

		<!-- 图片详情 -->
		<view class="detail-desc">
			<view class="d-header"><text>图文详情</text></view>
			<!-- <rich-text :nodes="desc"></rich-text> -->
			<view class="d-img">
				<image :src="item" v-for="(item, index) in productDetailList" :key="index" mode="aspectFill"></image>
				<!-- <img style="width:100%;display:block;" /> -->
			</view>
		</view>

		<!-- 底部操作菜单 -->
		<view class="page-bottom">
			<navigator url="/pages/index/index" open-type="switchTab" class="p-b-btn">
				<text class="yticon icon-xiatubiao--copy"></text>
				<text>首页</text>
			</navigator>
			<navigator url="/pages/cart/cart" open-type="reLaunch" class="p-b-btn">
				<text class="yticon icon-gouwuche"></text>
				<text>购物车</text>
			</navigator>
			<!-- <view class="p-b-btn" :class="{ active: favorite }" @click="toFavorite">
				<text class="yticon icon-shoucang"></text>
				<text>收藏</text>
			</view> -->

			<view class="action-btn-group">
				<view class=" action-btn no-border buy-now-btn" @click="buy">立即购买</view>
				<view @click="toggleSpec" class=" action-btn no-border add-cart-btn">加入购物车</view>
			</view>
		</view>

		<!-- 加入购物车选框 -->
		<view class="popup spec" :class="specClass" @touchmove.stop.prevent="stopPrevent" @click="toggleSpec">
			<!-- 遮罩层 -->
			<view class="mask"></view>
			<view class="layer attr-content" @click.stop="stopPrevent">
				<view class="a-t">
					<image :src="ProductDetailInfo.productImg"></image>
					<view class="right">
						<text class="price">¥{{ ProductDetailInfo.discountPrice }}</text>
						<text class="stock">库存：{{ ProductDetailInfo.stock }}</text>
						<!-- <view class="selected">
							已选：
							<text class="selected-text" v-for="(sItem, sIndex) in specSelected" :key="sIndex">{{ sItem.name }}</text>
						</view> -->
					</view>
				</view>
				<view class="select-count">
					<text>选择数量</text>
					<uni-number-box class="cart-box" :value="amount" :min="1" @eventChange="numberChange"></uni-number-box>
				</view>

				<button class="btn" @click="addTocar">完成</button>
			</view>
		</view>
	</view>
</template>

<script>
import uniNumberBox from '@/components/uni-number-box.vue';
export default {
	components: {
		uniNumberBox
	},
	data() {
		return {
			titleNViewBackground: '',
			favorite: true,
			ProductDetailInfo: {}, //产品全部信息
			detailImg: [], //结构出来的详情轮播图片
			productParam: {}, //商品参数详情
			productDetailList: [], //下方图片
			amount: 1, //购物车选中数量
			indicatorDots: true,
			autoplay: false,
			interval: 2000,
			duration: 500,
			productId: '', //产品id
			classificationList: [], //全部分类
			specClass: 'none',
			specSelected: [],
			shareList: [],
			userId: '',
			goodsData:[] //一条商品详情
		};
	},
	// computed: {
	//        reversedMessage: function () {
	//            // `this` 指向 vm 实例
	//            return this.amount
	//        }
	//    },
	async onLoad(options) {
		console.log(options);
		let userId = uni.getStorageSync('userId');
		this.userId = userId;
		this.productId = options.productId;
		//请求商品详情数据
		const ProductInfoResult = await this.$axios(this.$baseUrl.queryProductInfo, {
			productId: options.productId
		});
		let ProductDetailInfo = ProductInfoResult.data.result;
		this.ProductDetailInfo = ProductDetailInfo;
		// 解构可写可不写
		let { detailImg, productParam, productDetailList } = ProductDetailInfo;
		this.detailImg = detailImg;
		this.productDetailList = productDetailList;
		this.productParam = productParam;
		let goodsData = [];
		goodsData.push({
			productAttribute: ProductDetailInfo.productAttribute,
			amount: this.amount,
			productImg: ProductDetailInfo.productImg,
			productDescription: ProductDetailInfo.productDescription,
			discountPrice: ProductDetailInfo.discountPrice,
			productId:ProductDetailInfo.productId
		});
		this.goodsData=goodsData;
	},
	methods: {
		//规格弹窗开关
		toggleSpec() {
			if (this.specClass === 'show') {
				this.specClass = 'hide';
				setTimeout(() => {
					this.specClass = 'none';
				}, 250);
			} else if (this.specClass === 'none') {
				this.specClass = 'show';
			}
		},
		numberChange(value) {
			this.amount = value.number;
		},
		//点击完成加入购物车
		addTocar() {
			console.log(this.amount);
			if (this.specClass === 'show') {
				this.specClass = 'hide';
				setTimeout(() => {
					this.specClass = 'none';
				}, 250);
			} else if (this.specClass === 'none') {
				this.specClass = 'show';
			}
			//添加到购物车保存数据
			this.$axios(this.$baseUrl.insertCart, {
				productId: this.productId,
				userId: this.userId,
				amount: this.amount
			}).then(res => {
				console.log(res);
				if (res.data.status) {
					uni.showToast({
						title: '加入购物车成功',
						duration: 1000
					});
				}
			});
		},
		//详情页
		navToDetailPage(item) {
			//测试数据没有写id，用title代替
			let id = item.title;
			console.log(id);
			uni.navigateTo({
				url: `/pages/product/product?id=${id}`
			});
		},
		buy() {
			console.log(this.goodsData);
			uni.navigateTo({
				url: `/pages/order/createOrder?type=now&data=${JSON.stringify({
					goodsData: this.goodsData
				})}`
			});
			
		},
		stopPrevent() {}
	}
};
</script>

<style lang="scss">
.content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 30rpx;
}
/*轮播图*/
.carousel-section {
	padding: 0;
	position: relative;
	width: 100%;

	.titleNview-background {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 350rpx;
		transition: 0.4s;
	}
	.carousel {
		width: 100%;
		height: 350rpx;
		.carousel-item {
			width: 100%;
			height: 100%;
			overflow: hidden;
			.detail-banner {
				background-size: cover;
				width: 100%;
			}
		}
		image {
			width: 100%;
			height: 100%;
			background-size: cover;

			border-radius: 10rpx;
		}
	}
}
/*描述信息*/
.goods-info {
	background: #fff;
	padding: 20upx 0;
	width: 100%;
	.title {
		font-size: 32upx;
		color: #303133;

		line-height: 50upx;
		font-family: PingFangSC-Medium;
		font-weight: 500;
		color: rgba(51, 51, 51, 1);
	}
	.intro {
		padding: 10upx 0;

		font-size: 26rpx;
		font-family: PingFangSC-Regular;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		line-height: 37rpx;
	}
	.price {
		display: flex;
		justify-content: space-between;
		align-items: center;
		.price-sale {
			.price-now {
				.price-sale-color {
					font-style: normal;
					width: 143rpx;
					height: 62rpx;
					font-size: 32rpx;
					font-family: PingFangSC-Medium;
					font-weight: 500;
					color: rgba(250, 55, 59, 1);
					line-height: 37rpx;
				}
				.price-sale-dai {
					font-style: normal;
					width: 122rpx;
					height: 37rpx;
					font-size: 20rpx;
					font-family: PingFangSC-Regular;
					font-weight: 400;
					color: #666666;
					line-height: 37rpx;
				}
			}
			.price-old {
				width: 70rpx;
				height: 37rpx;
				padding-left: 20rpx;
				font-size: 26rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
				line-height: 37rpx;
				text-decoration: line-through;
			}
		}
		.price-amount {
			width: 122rpx;
			height: 37rpx;
			font-size: 26rpx;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
			line-height: 37rpx;
		}
	}
}
/*图片详情*/
.detail-desc {
	background: #fff;
	margin-top: 16upx;
	.d-header {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 80upx;
		font-size: 30rpx;
		color: #303133;
		position: relative;

		text {
			padding: 0 20upx;
			background: #fff;
			position: relative;
			z-index: 1;
		}
		&:after {
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translateX(-50%);
			width: 300upx;
			height: 0;
			content: '';
			border-bottom: 1px solid #ccc;
		}
	}
	.detail-params {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		align-items: center;
		width: 690rpx;
		height: 462rpx;
		border-radius: 10rpx;
		border: 1rpx solid rgba(238, 238, 238, 1);
		.item-params {
			display: flex;
			width: 100%;
			height: 15%;
			justify-content: center;
			align-items: center;
			border-bottom: 1rpx solid #eeeeee;
			.item-params-left {
				text-align: center;
				width: 30%;
				font-size: 26rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
				line-height: 37rpx;
			}
			.item-params-right {
				width: 70%;
				font-size: 26rpx;
				font-family: PingFangSC-Regular;
				font-weight: 400;
				color: rgba(51, 51, 51, 1);
				line-height: 37rpx;
			}
		}
	}

	.d-img {
		width: 100%;
	}
}
/*底部菜单*/
.page-bottom {
	position: fixed;
	left: 0;
	width: 100%;
	bottom: 0;
	z-index: 95;
	display: flex;
	justify-content: space-around;
	align-items: center;

	height: 100upx;
	background: rgba(255, 255, 255, 0.9);
	box-shadow: 0 0 4upx 0 rgba(0, 0, 0, 0.5);
	// border-radius: 16upx;

	.p-b-btn {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		font-size: 30rpx;
		// color: #606266;
		width: 96upx;
		height: 80upx;
		.yticon {
			font-size: 40upx;
			line-height: 48upx;
			color: #ebeef5;
		}
		&.active,
		&.active .yticon {
			color: #fa436a;
		}
		.icon-fenxiang2 {
			font-size: 42upx;
			transform: translateY(-2upx);
		}
		.icon-shoucang {
			font-size: 46upx;
		}
	}
	.action-btn-group {
		display: flex;
		height: 76upx;
		// border-radius: 100px;
		border: none;
		overflow: hidden;
		box-shadow: 0 20upx 40upx -16upx #00b83e;
		box-shadow: 1px 2px 5px rgba(219, 63, 96, 0.4);
		background: linear-gradient(to right, #52ef74, #00b83e, #52ef74);
		// margin-left: 20upx;
		position: relative;
		&:after {
			content: '';
			position: absolute;
			top: 50%;
			right: 50%;
			transform: translateY(-50%);
			height: 28upx;
			width: 0;
			border-right: 1px solid rgba(255, 255, 255, 0.5);
		}
		.action-btn {
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 100px;
			width: 180upx;
			height: 100%;
			margin: 0 20rpx;
			font-size: 30rpx;
			border: none;
			padding: 0;
			border-radius: 0;
			background: transparent;
		}
	}
}
/*弹出层*/
.popup {
	position: fixed;
	left: 0;
	top: 0;
	right: 0;
	bottom: 0;
	z-index: 99;

	&.show {
		display: block;
		.mask {
			animation: showPopup 0.2s linear both;
		}
		.layer {
			animation: showLayer 0.2s linear both;
		}
	}
	&.hide {
		.mask {
			animation: hidePopup 0.2s linear both;
		}
		.layer {
			animation: hideLayer 0.2s linear both;
		}
	}
	&.none {
		display: none;
	}
	.mask {
		position: fixed;
		top: 0;
		width: 100%;
		height: 100%;
		z-index: 1;
		background-color: rgba(0, 0, 0, 0.4);
	}
	.layer {
		position: fixed;
		z-index: 99;
		bottom: 0;
		width: 100%;
		min-height: 40vh;
		border-radius: 10upx 10upx 0 0;
		background-color: #fff;
		.btn {
			height: 66upx;
			line-height: 66upx;
			border-radius: 100upx;
			background: #56ba53;
			font-size: 30rpx;
			color: #fff;
			margin: 30rpx;
		}
	}
	@keyframes showPopup {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 1;
		}
	}
	@keyframes hidePopup {
		0% {
			opacity: 1;
		}
		100% {
			opacity: 0;
		}
	}
	@keyframes showLayer {
		0% {
			transform: translateY(120%);
		}
		100% {
			transform: translateY(0%);
		}
	}
	@keyframes hideLayer {
		0% {
			transform: translateY(0);
		}
		100% {
			transform: translateY(120%);
		}
	}
}
/*规格弹窗*/
.attr-content {
	position: relative;
	.a-t {
		display: flex;
		image {
			width: 170upx;
			height: 170upx;
			flex-shrink: 0;
			margin-top: -40upx;
			border-radius: 8upx;

			.uni-numbox-minus,
			.uni-numbox-plus {
				margin: 0;
				background-color: #f5f5f5;
				width: 60upx;
				height: 100%;
				line-height: 60upx;
				text-align: center;
				position: relative;
			}
			.uni-numbox-minus .yticon,
			.uni-numbox-plus .yticon {
				font-size: 36upx;
				color: #555;
			}
			.uni-numbox-minus {
				border-right: none;
				border-top-left-radius: 6upx;
				border-bottom-left-radius: 6upx;
			}

			.uni-numbox-plus {
				border-left: none;
				border-top-right-radius: 6upx;
				border-bottom-right-radius: 6upx;
			}

			.uni-numbox-value {
				position: relative;
				background-color: #f5f5f5;
				width: 90upx;
				height: 50upx;
				text-align: center;
				padding: 0;
				font-size: 30upx;
			}

			.uni-numbox-disabled.yticon {
				color: #d6d6d6;
			}
		}
		.cart-box {
			position: absolute;

			background-color: #00b83e;
		}
		.right {
			display: flex;
			flex-direction: column;
			padding-left: 24upx;
			font-size: $font-sm + 2upx;
			color: $font-color-base;
			line-height: 42upx;
			.price {
				font-size: $font-lg;
				color: $uni-color-primary;
				margin-bottom: 10upx;
			}
			.selected-text {
				margin-right: 10upx;
			}
		}
	}
	.attr-list {
		display: flex;
		flex-direction: column;
		font-size: $font-base + 2upx;
		color: $font-color-base;
		padding-top: 30upx;
		padding-left: 10upx;
	}
	.item-list {
		padding: 20upx 0 0;
		display: flex;
		flex-wrap: wrap;
		text {
			display: flex;
			align-items: center;
			justify-content: center;
			background: #eee;
			margin-right: 20upx;
			margin-bottom: 20upx;
			border-radius: 100upx;
			min-width: 60upx;
			height: 60upx;
			padding: 0 20upx;
			font-size: $font-base;
			color: $font-color-dark;
		}
		.selected {
			background: #fbebee;
			color: $uni-color-primary;
		}
	}
}
</style>
