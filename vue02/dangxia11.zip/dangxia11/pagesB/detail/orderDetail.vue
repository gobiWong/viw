<template>
	<view class="content">
		<!-- 订单状态 -->
		<view class="order-status">
			<text class="order-status-title" :style="{ color: orderDetailInfo.stateTipColor }">{{orderDetailInfo.stateTip}}</text>
			<view class="order-status-tips">
				<!-- 待支付 -->
				<block v-if="orderDetailInfo.orderStatus==0?true:false">
					<text class="cancel-order" @click="delOrder(orderId)">取消订单</text>
					<text class="pay-order" @click="goPay(orderId)" type="primary">{{orderDetailInfo.descrip}}</text>
				</block>
				<!-- 待发货 -->
				<block v-if="orderDetailInfo.orderStatus==1?true:false">
					<text class="cancel-order" style="visibility: hidden;"></text>
					<text class="pay-order" @click="daifahuo" type="primary">{{orderDetailInfo.descrip}}</text>
				</block>
				<!-- 已发货 -->
				<block v-if="orderDetailInfo.orderStatus==2?true:false">
					<text @click="chakanwuliu(orderDetailInfo.logisticsCode,orderDetailInfo.logisticsNum)" class="cancel-order">查看物流</text>
					<text class="pay-order" @click="querenshouhuo" type="primary">{{orderDetailInfo.descrip}}</text>
				</block>
				<!-- 待评价 -->
				<block v-if="orderDetailInfo.orderStatus==3?true:false">
					<text class="cancel-order" style="visibility: hidden;"></text>
					<text class="pay-order" @click="qupingjia" type="primary">{{orderDetailInfo.descrip}}</text>
				</block>
				
				
			</view>
		</view>
		<!-- 配送信息 -->
		<view class="order-peisong">
			<view class="peisong peisong-time">
				<text class="peisong-title">配送时间</text>
				<text class="peisong-content">待定！</text>
			</view>
			<view class=" peisong peisong-address">
				<text class="peisong-title">收货地址</text>
				<text class="peisong-content">{{orderDetailInfo.shoppingAddress?orderDetailInfo.shoppingAddress.area+orderDetailInfo.shoppingAddress.address:'默认地址'}}</text>
			</view>
			<view class="peisong peisong-type">
				<text class="peisong-title">配送方式</text>
				<text class="peisong-content">送货上门/自提</text>
			</view>
		</view>

		<!-- 商品列表 -->
		<view class="product-list">
			<view class="list-item" v-for="(item,index) in orderDetailInfo.productList" :key='index'>
				<view class="product-img"><image :src="item.productImg" mode=""></image></view>
				<view class="product-desc">
					<view>{{item.productDescription}}</view>
					<view>X{{item.productCount}}</view>
				</view>
				<view class="product-price">
					<text class="price-old">¥{{item.originalPrice}}</text>
					<text class="price-now">¥{{item.discountPrice}}</text>
				</view>
			</view>
		</view>
		<!-- 订单信息 -->
		<view class="order-info">
			<view class="order-total">
				<text class="total-title">商品总价</text>
				<text class="total-content">¥{{orderDetailInfo.orderAmount}}</text>
			</view>
			<view class="order-discount">
				<text class="discount-title">商品优惠</text>
				<text class="discount-content">-¥0.00</text>
			</view>
			<view class="order-pay">
				<text class="pay-title">配送费</text>
				<text class="pay-content">免费</text>
			</view>
		</view>
		<!-- 订单编码信息 -->
		<view class="orderId-info">
			<view class="info-list">
				<text class="list-title">订单编号：</text>
				<text class="list-content">{{orderDetailInfo.orderNo}}</text>
			</view>
			<view class="info-list">
				<text class="list-title">下单时间：</text>
				<text class="list-content">2019-09-09 18:30:20</text>
			</view>
			<view class="info-list">
				<text class="list-title">支付方式：</text>
				<text class="list-content">微信支付</text>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			orderDetailInfo:{},//订单详情
			orderId:'',//订单Id
			userId:uni.getStorageSync('userId')
		};
	},
	onLoad(options) {
		console.log(options.orderId)
		this.orderId=options.orderId
		let allOrder = uni.getStorageSync('allOrder');
		let orderDetailInfo1 = allOrder.filter(item => item.orderId ==options.orderId);
		
		let orderDetailInfo = orderDetailInfo1.filter(item=>{
			//添加不同状态下订单的表现形式
			return item = Object.assign(item, this.orderStateExp(item.orderStatus));
			 
		});
		this.orderDetailInfo=orderDetailInfo[0]
		
		console.log(orderDetailInfo)
	},
	methods: {
		//订单状态过滤
		orderStateExp(state) {
			let stateTip = '',
				stateTipColor = '#56ba53';
			switch (+state) {
				case 0:
					stateTip = '待支付';
					stateTipColor = 'blue';
					break;
				case 1:
					stateTip = '待发货';
					stateTipColor = 'green';
					break;
				case 2:
					stateTip = '已发货';
					stateTipColor = 'red';
					break;
				case 3:
					stateTip = '待评价';
					stateTipColor = 'orange';
					break;
				case 9:
					stateTip = '订单已关闭';
					stateTipColor = '#909399';
					break;
		
				//更多自定义
			}
			return { stateTip, stateTipColor };
		},
		//去支付
		goPay(type){	
			let that = this;
			let productIdList = [];
			
			let goPayproductIdList=that.orderList1.filter((item, index) => {
				return item.orderId=orderId
			});
		
			goPayproductIdList.map((item, index) => {
				productIdList[index] = item.productId;
			});
			
			uni.getStorage({
				key: 'openId',
				success(res) {
					// console.log(res.data);
					that.openId = res.data;
					// console.log(that.openId)
					that.$axios(that.$baseUrl.wxPay, {
						userId: uni.getStorageSync('userId'),
						addressId: goPayproductIdList[0].addressId,
			
						paymentMethod: '微信',
						openId: that.openId,
						money: goPayproductIdList[0].orderAmount * 100,
						body: '智慧乡土',
						productIdList: productIdList
					}).then(res => {
						console.log(res, '1111');
						let payOrderId = res.data.result.payOrderId;
						wx.requestPayment({
							timeStamp: res.data.result.timeStamp,
							nonceStr: res.data.result.nonceStr,
							package: res.data.result.package,
							signType: 'MD5',
							payOrderId: res.data.result.payOrderId,
							paySign: res.data.result.paySign,
							success(res) {
								that.$axios(that.$baseUrl.wxNotify, {
									orderNo: payOrderId,
									addressId: that.addressData.addressId,
									userId:uni.getStorageSync('userId'),
									paymentMethod: '微信',
									remark: '商品测试很好',
									productIdList: productIdList,
									money: that.total * 100
								}).then(res => {
									console.log(res, '888');
								});
							},
							fail(res) {
								uni.navigateTo({
									url: `/pages/order/order?state=0`
								});
							}
						});
					});
				}
			});		
		},
		//取消订单
		delOrder(){
			
			this.$axios(this.$baseUrl.delOrderById, {
				orderId:parseInt(this.orderId),
				userId:this.userId.toString(),
				orderNo:this.orderDetailInfo.orderNo
			}).then(res => {
				console.log(res)
				uni.navigateTo({
					url: `/pages/order/order?state=0`
				});
			});
		},
		//查看物流
		chakanwuliu(shipperCode,logisticCode){
			// console.log(shipperCode,logisticCode);
			
			uni.navigateTo({
				url: `/pages/wuliu/wuliu?shipperCode=ZTO&logisticCode=75164420754764`
			});	
		},
		//确认收获
		querenshouhuo(){
			this.$axios(this.$baseUrl.confirmReceive, {
				orderNo:this.orderDetailInfo.orderNo,
					userId:this.userId.toString()
			}).then(res => {
				console.log(res)
				this.$api.msg(res.data.result);
				setTimeout(()=>{
				uni.navigateTo({
					url: `/pages/order/order?state=0`
				});	
				},1000)
				
			});
			
			
		},
	}
};
</script>

<style lang="scss">
.content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 30rpx;
	background: rgba(248, 248, 248, 1);
}
//订单状态
.order-status {
	width: 690rpx;
	height: 100rpx;
	border-radius: 10rpx;
	margin-bottom: 30rpx;
	display: flex;
	background-color: #fff;
	border-bottom: 1rpx solid #eee;
	line-height: 100rpx;
	.order-status-title {
		width: 400rpx;
	}
	.order-status-tips {
		flex: 1;
		display: flex;
		align-items: center;
		justify-content: space-around;
		.cancel-order {
			display: block;
			width: 125rpx;
			height: 54rpx;
			text-align: center;
			border-radius: 6rpx;
			border: 1rpx solid rgba(174, 174, 174, 1);
			font-size: 26rpx;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
			line-height: 54rpx;
		}
		.pay-order {
			display: block;
			text-align: center;
			width: 110rpx;
			height: 54rpx;
			background: rgba(0, 184, 61, 1);
			border-radius: 6rpx;
			font-size: 26rpx;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			color: rgba(255, 255, 255, 1);
			line-height: 54rpx;
		}
	}
}
//配送信息
.order-peisong {
	background-color: #fff;
	width: 690rpx;
	height: 270rpx;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	border: 1rpx solid #eee;
	// background: rgba(255, 205, 255, 1);
	border-radius: 10rpx;
	.peisong-address {
		border-top: 1rpx solid #eee;
		border-bottom: 1rpx solid #eee;
	}
	.peisong {
		height: 33.33%;
		text-align: center;
		width: 100%;
		display: flex;
		font-size: 28rpx;
		line-height: 300%;
		font-family: PingFangSC-Regular;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		.peisong-title {
			width: 25%;

			height: 100%;
		}
		.peisong-content {
			width: 75%;
			height: 100%;
		}
	}
}
//商品列表
.product-list {
	width: 690rpx;
	margin: 30rpx 0;
	background: rgba(255, 255, 255, 1);
	border-radius: 10rpx;
	.list-item {
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 10rpx;
		border-bottom: 1rpx solid #eee;
	}
	.product-img {
		width: 118rpx;
		height: 118rpx;
		background: rgba(250, 252, 255, 1);
		border: 1rpx solid rgba(238, 238, 238, 1);
		image{
			width: 100%;
			height: 100%;
			background-size: cover;
			vertical-align: middle;
		}
	}
	.product-desc {
		flex:1;
		padding-left:10rpx;
		font-size: 26rpx;
		font-family: PingFangSC-Regular;
		font-weight: 400;
		color: rgba(102, 102, 102, 1);
	}
	.product-price {
		width: 180rpx;
		.price-old {
			text-decoration: line-through;
			font-size: 24rpx;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			color: rgba(153, 153, 153, 1);
			
		}
		.price-now {
			font-size: 28rpx;
			font-family: PingFangSC-Medium;
			font-weight: 500;
			padding-left: 18rpx;
			
		}
	}
}
//订单信息
.order-info {
	width: 690rpx;
	background: rgba(255, 255, 255, 1);
	border-radius: 10rpx;
	.order-total,
	.order-discount,
	.order-pay {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
		font-size: 28rpx;
		font-family: PingFangSC-Regular;
		font-weight: 400;
		color: rgba(51, 51, 51, 1);
		line-height: 40rpx;
		.total-title,
		.discount-title,
		.pay-title {
			width: 50%;
			text-align: left;
		}
		.total-content,
		.discount-content,
		.pay-content {
			width: 50%;
			text-align: right;
		}
	}
	.order-discount {
		color: rgba(102, 102, 102, 1);
	}
}
// 订单编号信息
.orderId-info {
	margin: 30rpx 0;
	width: 690rpx;
	
	background: rgba(255, 255, 255, 1);
	border-radius: 10rpx;
	.info-list {
		font-size: 26rpx;
		font-family: PingFangSC-Regular;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		line-height: 37rpx;
		width: 100%;
		.list-title {
			width: 20%;
		}
		.list-content {
			width: 80%;
		}
	}
}
</style>
