import axios from 'axios'
import qs from 'qs'

// export const baseURL1 = 'https://attorney.meme-hk.com'
export const baseURL1 = 'http://192.168.2.142:8087'

axios.defaults.baseURL = baseURL1

//添加请求拦截器
axios.interceptors.request.use(function (config) {
    // 将token给到一个前后台约定好的key中，作为请求发送
    let token = localStorage.getItem('mytoken')
    if (token) {
        config.headers['Authorization'] = token
    }
    return config
}, function (error) {
    // Do something with request error
    return Promise.reject(error)
})
//线上申请平台
//1. 产品列表
export const getProductCategory = params => {
    return axios.get('/productCategory/getProductCategory', params).then(res => res.data)
}
//2.导入申请产品excel表格
export const importDocument = params => {
    return axios.post('/applyWizard/importDocument', params).then(res => res.data)
}

//2-1 新增保险附件
export const addAnnex = params => {
    return axios.post('/annex/add', params).then(res => res.data)
}
//2-2查询保险附件详情
export const addAnnexdetail = params => {
    return axios.post('/annex/detail', params).then(res => res.data)
}




//3.获取受益人信息
export const getBeneficiaryUser = params => {
    return axios.post('/beneficiary/getBeneficiaryUser', params).then(res => res.data)
}
//4.获取线上申请记录
export const getRecord = params => {
    return axios.post('/record/list', params).then(res => res.data)
}
//5.获取申请详情
export const getRecordInfo = params => {
    return axios.post('/record/getRecordInfo', params).then(res => res.data)
}
//6.获取产品细节
export const getProductDetails = params => {
    return axios.post('/productDetails/getProductDetails', params).then(res => res.data)
}
