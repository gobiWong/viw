import axios from 'axios'
import qs from 'qs'

// export const baseURL1 = 'https://attorney.meme-hk.com'
export const baseURL1 = 'http://192.168.2.142:8087'

axios.defaults.baseURL = baseURL1

//添加请求拦截器
axios.interceptors.request.use(function (config) {
    // 将token给到一个前后台约定好的key中，作为请求发送
    let token = localStorage.getItem('mytoken')
    if (token) {
        config.headers['Authorization'] = token
    }
    return config
}, function (error) {
    // Do something with request error
    return Promise.reject(error)
})


//1佣金报表
// //1-1.查看佣金支付资讯
// export const getCommissionTransferInfoDetail = params => {
//     return axios.get('/commissionTransfer/infoDetail', params).then(res => res.data)
// }
// //1-2.更新佣金支付资讯
// export const updateInfoDetai = params => {
//     return axios.post('/commissionTransfer/updateInfoDetail', params).then(res => res.data)
// }

//2佣金支付资讯
//2-1.查看佣金支付资讯
export const getCommissionTransferInfoDetail = params => {
    return axios.get('/commissionTransfer/infoDetail', params).then(res => res.data)
}
//2-2.更新佣金支付资讯
export const updateInfoDetail = params => {
    return axios.post('/commissionTransfer/updateInfoDetail', params).then(res => res.data)
}

//3佣金细节
//3-1.查看佣金支付资讯
export const getCommissionlist = params => {
    return axios.post('/commission/list', params).then(res => res.data)
}
//3-2.更新佣金支付资讯
// export const updateInfoDetai = params => {
//     return axios.post('/commissionTransfer/updateInfoDetail', params).then(res => res.data)
// }





