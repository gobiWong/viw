import axios from 'axios'
import qs from 'qs'

// export const baseURL = 'https://attorney.meme-hk.com'
export const baseURL = 'http://192.168.2.142:8087'

axios.defaults.baseURL = baseURL

//添加请求拦截器
axios.interceptors.request.use(function (config) {
  // 将token给到一个前后台约定好的key中，作为请求发送
  let token = localStorage.getItem('mytoken')
  if (token) {
    config.headers['Authorization'] = token
  }
  return config
}, function (error) {
  // Do something with request error
  return Promise.reject(error)
})

// 登录验证
export const checkUser = params => {
  return axios.post('user/loginUser', params).then(res => res.data)
}
//2.退出
export const loginOut = params => {
  return axios.get('user/loginOut', params).then(res => res.data)
}
//3.个人信息
export const getUserInfo = params => {
  return axios.post('user/getUserInfo', params).then(res => res.data)
}
//4.代理人/代理信息
export const getIntroducerUser = params => {
  return axios.post('user/getIntroducerUser', params).then(res => res.data)
}
//5.语言列表
export const getLanguage = params => {
  return axios.get('language/getLanguage', params).then(res => res.data)
}

//6.资料库列表
export const getPublicdatabase = params => {
  return axios.get('database/getPublicdatabase', params).then(res => res.data)
}


//7.添加资料库
export const addDatabase = params => {
  return axios.post('database/addDatabase', params).then(res => res.data)
}

//9.个人文件列表(接口一样,请求参数不一样)
export const getDocument = params => {
  return axios.post('document/getDocument', params).then(res => res.data)
}
//10.上传个人文件
export const addDocument = params => {
  return axios.post('document/addDocument', params).then(res => res.data)
}
//11.下载文件
export const downloadDocument = params => {
  return axios.get(`/document/downloadDocument/${params}`).then(res => res.data)
}
//12.国籍列表
export const getCountryList = params => {
  return axios.get('country/getCountry', params).then(res => res.data)
}
//13.部门列表
export const getDepartmentList = params => {
  return axios.get('department/getDepartment', params).then(res => res.data)
}
//14.获取行政人员列表
export const getStaffuserList = params => {
  return axios.get('staffuser/getStaffuser', params).then(res => res.data)
}
//15.添加行政人员
export const addStaff = params => {
  return axios.post('staffuser/addStaff', params).then(res => res.data)
}

//16.随机相应数量题目
export const getEvaluationList = params => {
  return axios.post('evaluation/getEvaluationList', params).then(res => res.data)
}
//17.查看测评分数结果
export const submitEvaluation = params => {
  return axios.post('/evaluation/submitEvaluation', params).then(res => res.data)
}

//1.1介绍人合约模块接口，查询所有

export const getIntroducerUserList = params => {
  return axios.get('/introducerUser/list', params).then(res => res.data)
}
//1.2介绍人合约模块接口，邀请功能接口,添加表单
export const addIntroducerUser = params => {
  return axios.post('/introducerUser/add', params).then(res => res.data)
}
//1-1-4更新修改并保存数据
export const UpdateIntroducerUser = params => {
  return axios.post('/introducerUser/update', params).then(res => res.data)
}
//1-1-3通过id查询获取被邀请人对象信息
export const getIntroducerUserDeatil = params => {
  return axios.get('/introducerUser/deatil', params).then(res => res.data)
}






//1.3登入码校验
export const checkCode = params => {
  return axios.get('/introducerUser/checkCode', params).then(res => res.data)
}

//1.4/通过介绍人id查询佣金转让信息
export const getDeatilByIntroducerId = params => {
  return axios.get('/commissionTransfer/deatilByIntroducerId', params).then(res => res.data)
}
//1.4-1添加佣金转让/更新-保存
export const addCommissionTransfer = params => {
  return axios.post('/commissionTransfer/addOrUpdate', params).then(res => res.data)
}

//1.4-2添加银行自动转账
export const addBankAutopay = params => {
  return axios.post('/bankAutopay/add', params).then(res => res.data)
}
//1.4-3添加电汇转账
export const addWireTransfer = params => {
  return axios.post('/wireTransfer/add', params).then(res => res.data)
}


//1.5回填主管名字接口
export const queryAddress = params => {
  return axios.get('/introducerUser/queryAddress', params).then(res => res.data)
}

//1.6介绍人个人资讯覆盖/introducerUser/update
export const updateIntroducerUser = params => {
  return axios.post('/introducerUser/update', params).then(res => res.data)
}

//1.7添加文件
export const addFileInformation = params => {
  return axios.post('/fileInformation/add', qs.stringify(params), { headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' } }).then(res => res.data)
}

//1.8查询上传文件
export const getFileList = params => {
  return axios.get('/fileInformation/list', params).then(res => res.data)
}
//1.9生成用户
export const createUser = params => {
  return axios.get('/introducerUser/createUser', params).then(res => res.data)
}



