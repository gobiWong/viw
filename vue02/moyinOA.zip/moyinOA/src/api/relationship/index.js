import axios from 'axios'
import qs from 'qs'

// export const baseURL1 = 'https://attorney.meme-hk.com'
export const baseURL1 = 'http://192.168.2.142:8087'

axios.defaults.baseURL = baseURL1

//添加请求拦截器
axios.interceptors.request.use(function (config) {
    // 将token给到一个前后台约定好的key中，作为请求发送
    let token = localStorage.getItem('mytoken')
    if (token) {
        config.headers['Authorization'] = token
    }
    return config
}, function (error) {
    // Do something with request error
    return Promise.reject(error)
})



//1.代理人信息
export const getIntroducerUser = params => {
    return axios.post('/user/getIntroducerUser', params).then(res => res.data)
}







