import axios from 'axios'
// import qs from 'qs'

// export const baseURL1 = 'https://attorney.meme-hk.com'
export const baseURL1 = 'http://192.168.2.142:8087'

axios.defaults.baseURL = baseURL1

//添加请求拦截器
axios.interceptors.request.use(function (config) {
    // 将token给到一个前后台约定好的key中，作为请求发送
    let token = localStorage.getItem('mytoken')
    if (token) {
        config.headers['Authorization'] = token
    }
    return config
}, function (error) {
    // Do something with request error
    return Promise.reject(error)
})
//线上服务互动平台
//1. 获取消息列表
export const getMessageList = params => {
    return axios.post('/message/list', params).then(res => res.data)
}
//2.新增消息
export const addMessage = params => {
    return axios.post('/message/add', params).then(res => res.data)
}
//3.获取消息详情列表
export const getMessageDetailList = params => {
    return axios.post('/messageDetail/list', params).then(res => res.data)
}
//4.新增消息详情
export const addMessageDetail = params => {
    return axios.post('/messageDetail/add', params).then(res => res.data)
}