<template>
  <div id="appRight">
    <el-container class="con_right" style="height:900px">
      <el-header class="right_head">
        <el-row :gutter="20">
          <el-col :span="8">
            <div class="grid-content bg-purple"><b> | </b>首页</div>
          </el-col>
          <el-col :span="8">
            <div class="grid-content bg-purple"><b> | </b>我的账户</div>
          </el-col>
          <el-col :span="4">
            <div class="grid-content bg-purple"><b> | </b>工具</div>
          </el-col>
          <el-col :span="4">
            <div class="grid-content bg-purple"><b> | </b>某某</div>
          </el-col>
        </el-row>
      </el-header>
      <el-main class="right_main">
          <Information></Information>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import Information from '@/views/Information.vue'
export default {

    components:{
        Information
    }
};
</script>
<style lang="less" scoped>
#appRight {
  .con_right {
    background-color: #fff;
    .right_head{
        background-color: #eee;
    }
    .right_main{
        background-color: #ccc
    }
  }
}
</style>
