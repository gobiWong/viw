const en = {
    message: {
        'hello': 'hello, world',
    }
}

export default en