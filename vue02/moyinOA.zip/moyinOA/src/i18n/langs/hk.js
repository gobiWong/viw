const en = {
    message: {
        'hello': '世界,你好!',
    }
}

export default en