import en from './en';
import zh from './zh';
import hk from './hk';
import ja from './ja';
export default {
   en,
   zh,
   hk,
   ja
}