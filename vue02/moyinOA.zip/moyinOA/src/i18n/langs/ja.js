const ja = {
    message: {
        'hello': 'ハローワールド',
    }
}

export default ja