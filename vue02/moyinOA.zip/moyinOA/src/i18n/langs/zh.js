//zh.js
const zh = {
    message: {
        'hello': '你好，世界',
    }
}

export default zh