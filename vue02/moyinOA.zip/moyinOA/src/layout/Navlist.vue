<template>
  <!-- 头部logo -->

  <el-aside class="home_left" width="240px" style="height:100%;backgroundColor:#413B63">
    <div v-if="!flag">
      <el-menu
        router
        :default-active="this.$route.path"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        background-color="#413B63"
        text-color="#fff"
        active-text-color="#ffd04b"
      >
        <el-menu-item index="/information">
          <i class="el-icon-notebook-2"></i>
          <span slot="title">一般资讯</span>
        </el-menu-item>
        <el-menu-item index="/serviceOnline">
          <i class="el-icon-refresh"></i>
          <span slot="title">线上服务互动平台</span>
        </el-menu-item>
        <el-submenu index="/introducerContract">
          <template slot="title">
            <i class="iconfont">&#xe6d3;</i>
            <span>介绍人合约</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/invitation">
              <i class="el-icon-share"></i>邀请
            </el-menu-item>
            <el-menu-item index="/record">
              <i class="el-icon-reading"></i>记录
            </el-menu-item>
          </el-menu-item-group>
        </el-submenu>

        <el-menu-item index="/query">
          <i class="el-icon-search"></i>
          <span slot="title">查询</span>
        </el-menu-item>
        <el-submenu index="/commission">
          <template slot="title">
            <i class="iconfont">&#xe65a;</i>

            <span>佣金</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/commissionFrom">
              <!-- <i class="el-icon-s-finance"></i> -->
              佣金报表
            </el-menu-item>
            <el-menu-item index="/CommissionInfo">佣金支付资讯</el-menu-item>
            <!-- <el-menu-item index="/commissionContract">合约与佣金资讯</el-menu-item> -->
            <el-menu-item index="/commissionDetails">佣金细节</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="/achievement">
          <template slot="title">
            <i class="iconfont">&#xe60f;</i>
            <span>业绩</span>
          </template>
          <el-menu-item-group>
            <!-- <el-menu-item index="/allaAchievement">所有业绩</el-menu-item> -->
            <el-menu-item index="/yearAchievement">今年业绩</el-menu-item>
          </el-menu-item-group>
        </el-submenu>

        <el-submenu index="/ApplyOnline">
          <template slot="title">
            <i class="iconfont">&#xe633;</i>
            <span>线上申请平台</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/applyOnline">新建申请</el-menu-item>
            <el-menu-item index="/applyRecord">记录</el-menu-item>
            <el-menu-item index="/applyAssess">洗钱防制风险评估指引</el-menu-item>
            <el-menu-item index="/applyClause">产品条款表</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-menu-item index="/introducer">
          <i class="el-icon-setting"></i>
          <span slot="title">介绍人行政人员</span>
        </el-menu-item>
        <el-submenu index="/relation">
          <template slot="title">
            <i class="iconfont">&#xe88f;</i>

            <span>关系</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/relationIntro">代理人</el-menu-item>
            <el-menu-item index="/beneficiary">受益人</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-menu-item index="/document">
          <i class="el-icon-setting"></i>
          <span slot="title">文件中心</span>
        </el-menu-item>
        <el-menu-item index="/database">
          <i class="el-icon-document-copy"></i>
          <span slot="title">资料库</span>
        </el-menu-item>
      </el-menu>
    </div>
    <div v-if='flag'>
      <el-menu
        router
        :default-active="this.$route.path"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        background-color="#413B63"
        text-color="#fff"
        active-text-color="#ffd04b"
      >
        <el-submenu index="1">
          <template slot="title">
            <!-- <i class="iconfont">&#xe88f;</i> -->
            <span>一般资讯</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="1-1">概要</el-menu-item>
          </el-menu-item-group>
          <el-submenu index="1-2">
            <span slot="title">主计划</span>
            <el-menu-item index="1-2-1">计划概要</el-menu-item>
             <el-menu-item index="1-2-1">基金记录</el-menu-item>
              <el-menu-item index="1-2-1">产品条款表</el-menu-item>
          </el-submenu>
        </el-submenu>

        <el-menu-item index="2">
          <!-- <i class="el-icon-notebook-2"></i> -->
          <span slot="title">文件中心</span>
        </el-menu-item>

        <el-submenu index="3">
          <template slot="title">
            <!-- <i class="iconfont">&#xe633;</i> -->
            <span>线上平台</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="3-1">线上基金分析</el-menu-item>
            <el-menu-item index="3-2">基金绩效及策略</el-menu-item>
          </el-menu-item-group>
        </el-submenu>

        <el-submenu index="4">
          <template slot="title">
            <!-- <i class="iconfont">&#xe88f;</i> -->
            <span>关系</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="4-1">概要</el-menu-item>
            <el-menu-item index="4-2">持有人</el-menu-item>
            <el-menu-item index="4-3">供款人</el-menu-item>
            <el-menu-item index="4-4">受保人</el-menu-item>
          </el-menu-item-group>
        </el-submenu>

        <el-menu-item index="5">
          <!-- <i class="el-icon-document-copy"></i> -->
          <span slot="title">资料库</span>
        </el-menu-item>
      </el-menu>
    </div>
  </el-aside>
</template>
<script>
export default {
  data() {
    return {
      curTagName: "",
      flag: false,
      menuList: [
        {
          path: "/information", //菜单项所对应的路由路径
          title: "一般资讯", //菜单项名称
          children: [] //是否有子菜单，若没有，则为[]
        },
        {
          path: "/serviceOnline",
          title: "线上服务互动平台",
          children: []
        },
        {
          path: "/testEvaluation",
          title: "测评考试",
          children: []
        },
        {
          path: "/query",
          title: "查询",
          children: []
        },
        {
          path: "/commission",
          title: "佣金",
          children: [
            {
              path: "/commissionFrom",
              title: "佣金报表",
              children: []
            },
            {
              path: "/CommissionInfo",
              title: "佣金支付资讯",
              children: []
            },
            {
              path: "/commissionContract",
              title: "合约与佣金资讯",
              children: []
            },
            {
              path: "/commissionDetails",
              title: "佣金细节",
              children: []
            }
          ]
        },
        {
          path: "/achievement",
          title: "业绩",
          children: [
            {
              path: "/allaAchievement",
              title: "所有业绩",
              children: []
            },
            {
              path: "/yearAchievement",
              title: "今年业绩",
              children: []
            }
          ]
        },
        {
          path: "/applyOnline",
          title: "线上申请平台",
          children: []
        },
        {
          path: "/introducer",
          title: "介绍人行政人员",
          children: []
        },
        {
          path: "/relation",
          title: "关系",
          children: [
            {
              path: "/relationIntro",
              title: "介绍人",
              children: []
            },
            {
              path: "/beneficiary",
              title: "受益人",
              children: []
            }
          ]
        },
        {
          path: "/document",
          title: "文件中心",
          children: []
        }
      ]
    };
  },
  mounted() {
    console.log(localStorage.getItem("userType"));
    if (localStorage.getItem("userType") === "1") {
      this.flag = this.flag;
    } else if (localStorage.getItem("userType") === "2") {
      this.flag = !this.flag;
    }
  },
  watch: {
    $route(to, from) {
      if (from.path === "/welcome") {
        this.$message({
          message: "请先通过测评！",
          type: "warning",
          duration: 2000
        });
        this.$router.push({ path: "/welcome" });
        if (from.path === "/welcome" && to.path === "/success") {
          this.$message({
            message: "测评已通过，欢迎回来！",
            type: "success",
            offset: 4.5
          });
          this.$router.push({ path: "/success" });
        }
      }
    }
    // if(from.path==='/success/:status'){
    // // this.$message({
    // //       message: '请先通过测评！',
    // //       type: 'warning'
    // //     });
    // this.$router.push({ path:'/success/:status' });
    // }
  },
  methods: {
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
    logout() {
      // 清除登录状态，即保存在localStorage中的token
      // localStorage.removeItem("mytoken");
      localStorage.clear();
      // 跳转到登录页面
      this.$router.push({ name: "Login" });
    }
  }
};
</script>
<style lang="less" scoped>
.el-menu {
  border-right-width: 0;
}
</style>
