<template>
  <div class="top_nav">
    <el-row :gutter="20">
      <el-col :span="13">
        <i class="el-icon-arrow-down1 el-icon--right"></i>
      </el-col>
      <el-col :span="2">
        <span class="homePage" @click="$router.push({name:'Welcome'})">
          <i class="el-icon-s-home"></i>首页
        </span>
      </el-col>
      <el-col :span="2">
        <el-dropdown>
          <span class="el-dropdown-link">
            <i class="el-icon-wallet"></i>
            我的账户
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item icon="el-icon-plus">我的介绍人</el-dropdown-item>
            <el-dropdown-item icon="el-icon-circle-plus">我的投资计划</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-col>
      <el-col :span="2">
        <el-dropdown>
          <span class="el-dropdown-link">
            <i class="el-icon-setting"></i>
            工具
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item icon="el-icon-plus">条款与细则</el-dropdown-item>
            <el-dropdown-item icon="el-icon-circle-plus">隐私权声明</el-dropdown-item>
            <el-dropdown-item icon="el-icon-circle-plus-outline">联络我们</el-dropdown-item>
            <el-dropdown-item icon="el-icon-check">协助</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-col>
      <el-col :span="2">
        <el-dropdown>
          <span class="el-dropdown-link">
            <i class="el-icon-user"></i>
            <i>{{userName}}</i>
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item icon="el-icon-check" @click.native="goRelationIntro">基本资料</el-dropdown-item>
            <el-dropdown-item icon="el-icon-circle-check-outline">退出</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-col>

      <el-col :span="2">
        <span class="logout" @click="logout">
          退出
          <i class="el-icon-switch-button"></i>
        </span>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { loginOut } from "@/api";

export default {
  data() {
    return {
      userName: "",
    };
  },
  mounted() {
    this.userName = window.localStorage.getItem("userName");
  },
  methods: {
    logout() {
      // 清除登录状态，即保存在localStorage中的token
      loginOut().then(res => {
        console.log(res);
        if (res.rtnCode == 1) {
          this.$message({
            message: res.rtnMsg,
            type: "success"
          });
        }
        localStorage.clear();
        // this.$store.commit("clearUserName", "");
        // this.$store.commit("clearUserId", "");

        // 跳转到登录页面
        setTimeout(() => {
          this.$router.replace({ name: "Login" });
        }, 500);
      });
    },

    goRelationIntro() {
      this.$router.push({ name: "RelationIntro" });
    }
  }
};
</script>
<style lang="less" scoped>
.el-dropdown-link {
  cursor: pointer;
  color: rgb(3, 3, 3);
}
.homePage {
  font-size: 14px;
}
.logout {
  cursor: pointer;
  font-size: 14px;
  color: #444;
}

.top_con {
  display: flex;
  justify-content: space-around;
  align-items: center;

  .top_nav {
    flex: 1;
    text-align: left;
    line-height: 60px;
    font-size: 16px;
  }
}
</style>
