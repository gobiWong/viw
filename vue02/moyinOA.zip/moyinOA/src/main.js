// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);
import './assets/reset.css'
import './assets/icon/iconfont.css'

import axios from 'axios'
Vue.prototype.$axios = axios


// 引入Echarts
import Echarts from 'echarts'
Vue.prototype.echarts = Echarts
Vue.use(Echarts)


//引入 animate.css动画
import animated from 'animate.css' // npm install animate.css --save安装，在引入
 
Vue.use(animated)
// import enLocale from 'element-ui/lib/locale/lang/en'
// import zhLocale from 'element-ui/lib/locale/lang/zh-CN'
// import jaLocale from 'element-ui/lib/locale/lang/ja'
// import twLocale from 'element-ui/lib/locale/lang/zh-TW'
import i18n from './i18n/i18n'
Vue.config.lang = 'zh-cn'


// Vue.locale('zh-cn', zhLocale)
// Vue.locale('en', enLocale)
// Vue.locale('ja', jaLocale)
// Vue.locale('tw', twLocale)
import store from '@/store/store';

import filters from './utils/filters.js'
import router from './router'
// 遍历注册全局过滤器
Object.keys(filters).forEach(key => Vue.filter(key, filters[key]))

Vue.config.productionTip = false

router.beforeEach((to, from, next) => {
  if (to.meta.requireAuth) {
    if (localStorage.getItem('userName')) {
      next()
    } else {
      next({
        path: '/login',
        query: { redirect: to.fullPath }
      })
    }
  }
  else {
    next()
  }

})
//注册一个全局守卫，作用是在路由跳转前，对路由进行判断，防止未登录的用户跳转到其他需要登录的页面去
// router.beforeEach((to, from, next) => {
//   let token = localStorage.getItem('mytoken')
//   // 如果已经登录，那我不干涉你，让你随便访问
//   if (token) {
//     next()
//   } else {
//     if (to.path !== '/login') {
//       // 如果没有登录，但你访问其他需要登录的页面，那我就让你跳到登录页面去
//       next({path: '/login'})
//     } else {
//       // 如果没有登录，但你访问的login，那就不干涉你，让你访问
//       next()
//     }
//   }
// })


/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  i18n,
  components: { App },
  template: '<App/>'
})
