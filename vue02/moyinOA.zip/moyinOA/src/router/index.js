import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/views/Login'//登入页

import Register from '@/views/Register'//注册页
import Agreement from '@/views/register/Agreement'//同意页面
import LoginCode from '@/views/register/LoginCode'//填写验证码页面
import GetCode from '@/views/register/GetCode'//填写验证码页面
import Confirm from '@/views/register/Confirm'//信息注册页面

import Introtype from '@/views/register/registerInfo/Introtype'//信息注册页面---受益人页面
import RegBeneficiary from '@/views/register/registerInfo/RegBeneficiary'//信息注册页面---受益人页面
import Contracts from '@/views/register/registerInfo/Contracts'//信息注册页面---合约总览
import GrantInfo from '@/views/register/registerInfo/GrantInfo'//信息注册页面---佣金发放资讯

import IntroInfo from '@/views/register/registerInfo/IntroInfo'//信息注册页面---介绍人资讯
import UploadFile from '@/views/register/registerInfo/UploadFile'//信息注册页面---上传文件
import Infosure from '@/views/register/registerInfo/Infosure'//信息注册页面---确认信息





import Home from '@/views/Home'//主页
import Welcome from '@/views/welcome/Welcome'//测评页面
import Test from '@/views/welcome/Test'//测评页面1
import Success from '@/views/welcome/Success'//测评通过页面
import Information from '@/views/information/Information'//一般资讯页
import ServiceOnline from '@/views/serviceOnline/ServiceOnline'//线上服务页

import Invitation from '@/views/introducerContract/Invitation'//介绍人合约-邀请
import Record from '@/views/introducerContract/Record'//介绍人合约-记录

import Query from '@/views/query/Query'//查询页


import CommissionFrom from '@/views/commission/CommissionFrom'//佣金报表
import CommissionInfo from '@/views/commission/CommissionInfo'//佣金支付资讯
// import CommissionContract from '@/views/commission/CommissionContract'//佣金合约与佣金资讯
import CommissionDetails from '@/views/commission/CommissionDetails'//佣金细节

// import AllAchievement from '@/views/achievement/AllAchievement'//所有业绩
import YearAchievement from '@/views/achievement/YearAchievement'//今年业绩

import ApplyOnline from '@/views/applyOnline/applyOnline'//新建申请
import ApplyRecord from '@/views/applyOnline/applyRecord'//申请记录
import ApplyAssess from '@/views/applyOnline/applyAssess'//风险评估指引
import ApplyClause from '@/views/applyOnline/applyClause'//产品条款表

import Introducer from '@/views/introducer/Introducer'//介绍人行政
import Document from '@/views/document/Document'//文件中心

import RelationIntro from '@/views/relationship/RelationIntro'//关系介绍人
import Beneficiary from '@/views/relationship/Beneficiary'//关系受益人

import Database from '@/views/database/Database'//资料库

Vue.use(Router)

export default new Router({
  routes: [
    {//登入路径路由
      path: '/login',
      name: 'Login',
      component: Login,
      meta: {
        title: '登入',roles: ['0', '1']
      }
    },
    {//注册路径路由
      path: '/Register',
      name: 'register',
      component: Register,
      meta: {
        title: '注册',
      },
      redirect: { path: '/agreement' },
      children: [
        {
          name: 'Agreement',
          path: '/agreement',
          component: Agreement,

        },
        {
          name: 'LoginCode',
          path: '/loginCode/:id/:code',
          component: LoginCode,
          // beforeEnter(to,from,next){
          //   if(to.path==="/loginCode/:id"){
          //     alert("请登录");
          //     next(false); // 禁止跳转
          //   }else{
          //     next()
          //   }
          // }


        },
        {
          name: 'GetCode',
          path: 'getCode/:id',
          component: GetCode
        },
        {
          name: 'Confirm',
          path: '/confirm',
          component: Confirm,
          redirect: { path: '/introtype/:id' },
          children: [
            {
              name: 'Introtype',
              path: '/introtype/:id',
              component: Introtype,
              meta: {
                title: '介绍人类别'
              },
            },
            {
              name: 'RegBeneficiary',
              path: '/regBeneficiary/:id',
              component: RegBeneficiary,
              meta: {
                title: '受益人'
              },
            },
            {
              name: 'Contracts',
              path: '/contracts/:id',
              component: Contracts,
              meta: {
                title: '合约总览'
              },
            },
            {
              name: 'GrantInfo',
              path: '/grantInfo/:id',
              component: GrantInfo,
              meta: {
                title: '佣金发放资讯'
              },
            },
            {
              name: 'IntroInfo',
              path: '/introInfo/:id',
              component: IntroInfo,
              meta: {
                title: '介绍人资讯'
              },
            },
            {
              name: 'UploadFile',
              path: '/uploadFile/:id',
              component: UploadFile,
              meta: {
                title: '上传文件'
              },
            },
            {
              name: 'Infosure',
              path: '/infosure/:id',
              component: Infosure,
              meta: {
                title: '结果'
              },
            },
            {
              path: '*',
              redirect: '/404'
            }
          ]
        },
      ]
    },
    {//系统内容路由
      path: '/',
      name: 'Home',
      component: Home,
      redirect: { path: 'welcome' },
      children: [
        {
          name: 'Welcome',
          path: 'welcome',
          component: Welcome,
          meta: {
            title: '欢迎',
            requireAuth: true
          },
        },
        {
          name: 'Success',
          path: 'success',
          component: Success,
          meta: {
            title: '测评通过',
            requireAuth: true
          }
        },
        {
          name: 'Information',
          path: 'information',
          component: Information,
          meta: {
            title: '一般资讯',roles: ['0'],
            requireAuth: true
          }
        },
        {
          name: 'ServiceOnline',
          path: 'serviceOnline',
          component: ServiceOnline,
          meta: {
            title: '线上服务互动平台',roles: ['0'],
            requireAuth: true
          }
        },
        {
          name: 'Invitation',
          path: 'invitation',
          component: Invitation,
          meta: {
            title: '邀请',roles: ['0'],
            requireAuth: true
          }
        },
        {
          name: 'Record',
          path: 'record',
          component: Record,
          meta: {
            title: '记录',roles: ['0'],
            requireAuth: true
          }
        },
        {
          name: 'Query',
          path: 'query',
          component: Query,
          meta: {
            title: '查询',roles: ['0'],
            requireAuth: true
          }
        },
        {
          name: 'CommissionFrom',
          path: 'commissionFrom',
          component: CommissionFrom,
          meta: {
            title: '佣金报表',roles: ['0'],
            requireAuth: true
          }
        },
        {
          name: 'CommissionInfo',
          path: 'commissionInfo',
          component: CommissionInfo,
          meta: {
            title: '佣金支付资讯',roles: ['0'],
            requireAuth: true
          }
        },
        // {
        //   name: 'CommissionContract',
        //   path: 'commissionContract',
        //   component: CommissionContract,
        //   meta: {
        //     title: '查询',
        //     requireAuth: true
        //   }
        // },
        {
          name: 'CommissionDetails',
          path: 'commissionDetails',
          component: CommissionDetails,
          meta: {
            title: '佣金细节',roles: ['0'],
            requireAuth: true
          }
        },
        // {
        //   name: 'AllAchievement',
        //   path: 'allaAchievement',
        //   component: AllAchievement,
        //   meta: {
        //     title: '查询',
        //     requireAuth: true
        //   }
        // },
        {
          name: 'YearAchievement',
          path: 'yearAchievement',
          component: YearAchievement,
          meta: {
            title: '查询',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'ApplyOnline',
          path: 'applyOnline',
          component: ApplyOnline,
          meta: {
            title: '新建申请',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'ApplyRecord',
          path: 'applyRecord',
          component: ApplyRecord,
          meta: {
            title: '申请记录',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'ApplyAssess',
          path: 'applyAssess',
          component: ApplyAssess,
          meta: {
            title: '风险评估指引',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'ApplyClause',
          path: 'applyClause',
          component: ApplyClause,
          meta: {
            title: '产品条款表',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'Introducer',
          path: 'introducer',
          component: Introducer,
          meta: {
            title: '查询',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'Document',
          path: 'document',
          component: Document,
          meta: {
            title: '查询',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'RelationIntro',
          path: 'relationIntro',
          component: RelationIntro,
          meta: {
            title: '查询',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'Beneficiary',
          path: 'beneficiary',
          component: Beneficiary,
          meta: {
            title: '查询',roles: ['1'],
            requireAuth: true
          }
        },
        {
          name: 'Database',
          path: 'database',roles: ['1'],
          component: Database,
          meta: {
            title: '查询',
            requireAuth: true
          }
        }


      ]
    },
    {//404路由
      name: '404',
      path: '/404',
      component: () => import('@/views/NotFound.vue')
    },
    {//全局404重定向
      path: '*',
      redirect: '/404'
    }
  ]
})

// var routeList = [];
// router.beforeEach((to, from, next) => {
//   var index = -1;
// //   判断路由之前是否存在，并返回位置
//   for (var i = 0; routeList.length; i++) {
//     if (routeList[i].name == to.name) {
//       index = i;
//       break;
//     }
//   }
//   if (index !== -1) {
//     //   如果存在，则回到重复路由的之前位置
//     routeList.splice(index + 1, routeList.length - index - 1);
//   } else {
//     //   不存在则加入循环数组内 （注1）
//     routeList.push({ name: to.name, path: to.path});
//   }
//   to.meta.routeList = routeList;
//   next();
// });
