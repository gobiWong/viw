import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
const state = {
  userName: '',
  userId: '',
  total: '',
  IntroducerId:'',
  userType:'',

}
const mutations = {
  setUserType: (state, userType) => {
    state.userType = userType
    localStorage.setItem('userType', userType)
  },
  setUsername: (state, userName) => {
    state.userName = userName
    localStorage.setItem('userName', userName)
  },

  setUserId: (state, userId) => {
    state.userId = userId
    localStorage.setItem('userId', userId)
  },
  setIntroducerId: (state, IntroducerId) => {
    state.IntroducerId = IntroducerId
    localStorage.setItem('IntroducerId', IntroducerId)
  },

  setTotal: (state, total) => {
    state.total = total
    localStorage.setItem('total', total)
  },

  clearUserId: (state, userId) => {
    state.userId = userId
  },
  clearUserName: (state, userName) => {
    state.userName = userName

  },
}
const actions = {}
const getters = {
  userName: (state) => localStorage.getItem('userName'),
  userId: (state) => localStorage.getItem('userId'),
  total: (state) => localStorage.getItem('total'),
  IntroducerId:(state)=>localStorage.getItem('IntroducerId'),
  userType:(state)=>localStorage.getItem('userType'),
}
export default new Vuex.Store({
  state,
  getters,
  actions,
  mutations
})
