const LANGUAGE = (num) => {
    let status = ""
    switch (parseInt(num)) {
        case 1:
            status = "英语"
            break;
        case 2:
            status = "中文简体"
            break;
        case 3:
            status = "中文繁体"
            break;
        case 4:
            status = "日语"
            break;
    }
    return status;
}
const COUNTRY = (num) => {
    let status = ""
    switch (parseInt(num)) {
        case 1:
            status = "英国"
            break;
        case 2:
            status = "中国"
            break;
        case 3:
            status = "日本"
            break;
    }
    return status;
}
const CURRENCY = (num) => {
    let status = ""
    switch (parseInt(num)) {
        case 1:
            status = "人民币"
            break;
        case 2:
            status = "美元"
            break;
        case 3:
            status = "日元"
            break;
    }
    return status;
}
const PERIOD = (num) => {
    let status = ""
    switch (parseInt(num)) {
        case 1:
            status = "每周"
            break;
        case 2:
            status = "每两周"
            break;
        case 3:
            status = "每月"
            break;
        case 4:
            status = "每季"
            break;
        case 5:
            status = "每半年"
            break;
        case 6:
            status = "每年"
            break;
    }
    return status;
}
const RECORD = (num) => {
    let status = ""
    switch (parseInt(num)) {
        case 1:
            status = "已发送"
            break;
        case 2:
            status = "进行中"
            break;
        case 3:
            status = "已重新发送"
            break;
        case 4:
            status = "等待审核中"
            break;
        case 5:
            status = "已取消"
            break;
        case 6:
            status = "已完成"
            break;
    }
    return status;
}
// const DATEFORMAT =(num)=>{
//     var d = new Date(num);

//     var year = d.getFullYear(); //年
//     var month = d.getMonth() + 1; //月
//     var day = d.getDate(); //日

//     var hh = d.getHours(); //时
//     var mm = d.getMinutes(); //分
//     var ss = d.getSeconds(); //秒

//     var clock = year + "/";

//     if (month < 10) clock += "0";

//     clock += month + "/";

//     if (day < 10) clock += "0";

//     clock += day + " ";

//     if (hh < 10) clock += "0";

//     clock += hh + ":";
//     if (mm < 10) clock += "0";
//     clock += mm + ":";

//     if (ss < 10) clock += "0";
//     clock += ss;
//     return clock;
// }

export default {//此处导出
    LANGUAGE,
    COUNTRY,
    CURRENCY,
    PERIOD,
    RECORD,
    //DATEFORMAT
}
