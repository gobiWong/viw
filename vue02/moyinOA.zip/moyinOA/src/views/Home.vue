<template>
  <div class="parent">
    <!-- 头部导航 -->
    <div class="top">
      <div class="top_con">
        <!-- 头部选项 -->

        <TopNav></TopNav>
      </div>
      <div class="top_log">
        <div class="log">
          <!-- <p>{{$t('message.hello')}}</p> -->
        </div>
      </div>
    </div>
    <!-- 左侧菜单栏 -->
    <div class="left">
      <!-- 组件拆分引入 -->
      <Navlist></Navlist>
    </div>
    <!-- 右侧主体区域 -->
    <div class="right">
      <div class="inner">
        <router-view></router-view>
      </div>
    </div>
    <!-- 固定底部版权 -->
    <div class="bottom">
      Copyright [2018-2019]
      <span>YIRONG</span> .All rights reserved.
    </div>
  </div>
</template>
<script>
import Navlist from "@/layout/Navlist.vue"; //菜单栏组件
import TopNav from "@/layout/topNav.vue"; //头部组件
export default {
  components: {
    Navlist,
    TopNav
  },
  provide() {
    return {
      reload: this.reload
    };
  },
  data() {
    return {
      isRouterAlive: true
    };
  },
 

  methods: {
    reload() {
      this.isRouterAlive = false;
      this.$nextTick(function() {
        this.isRouterAlive = true;
      });
    }
  }
};
</script>
<style lang="less" scoped>
html,
body,
.parent {
  height: 100%;
  overflow: hidden;
}
.top {
  position: absolute;
  top: 0;
  left: 240px;
  right: 0;
  height: 60px;
  background-color: rgb(179, 192, 209);
 
  .top_log {
    position: absolute;
    bottom: 0;
    left: -240px;
    width: 240px;
    height: 60px;
    background-color: rgb(209, 220, 240);
  }
  .log {
    box-sizing: border-box;
    width: 240px;
    height: 60px;
    background-color: cornflowerblue;
  }
}

.left {
  position: absolute;
  top: 60px;
  left: 0;
  bottom: 50px;
  width: 240px;
  background-color: #bbb;
  .el-menu {
    border-right-width: 0;
  }
}
.right {
  position: absolute;
  overflow: auto;
  top: 60px;
  left: 240px;
  bottom: 50px;
  right: 0;
  //   background-color: #e0e4e0;
}
.bottom {
  position: absolute;
  text-align: center;
  left: 0;
  right: 0;
  bottom: 0;
  height: 50px;
  line-height: 50px;
  background-color: #bdbdc0d5;
  span {
    margin: 0 5px;
  }
}
.inner {
  box-sizing: border-box;
  min-height: 839px;
  padding: 20px 30px 0 10px;
  background-color: #e9eef3;
}
.error {
  // font-size: 100px;
  text-align: center;
  // text-shadow: 1px 2px 3px #FF0000;//数值意思是-----1px水平阴影的位置,允许负值。2px垂直阴影的位置,允许负值。3px模糊的距离。#FF0000阴影的颜色。
}
</style>
