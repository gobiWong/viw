<template>
  <div class="parent">
    <div class="top">
      <div class="head">
         
          <!-- <div class="logo">logo</div>
       
          <div class="language">语言切换</div> -->
      
      </div>
     
    </div>

    <div class="right">
      <div class="inner">
        <div class="container">
          <router-view></router-view>
        </div>
      </div>
    </div>
    <div class="bottom"></div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      radio: "1",
      activeName: "1",
      addForm: {
        languageId: "",
        countryId: "",
        departmentId: "",
        englishName: "",
        chineseName: "",
        beneficiaryBirthday: "",
        beneficiarySex: "",
        staffCertificateType: "",
        staffCertificateNo: "",
        staffFaData: "",
        staffOutData: "",
        staffEmail: "",
        staffTrueEmail: "",
        staffPhoneType: "",
        staffCountryCode: "",
        staffMobile: "",
        staffLandline: "",
        staffName: ""
      }
    };
  }
};
</script>
<style lang="less" scoped>
html,
body,
.parent {
  height: 100%;
  overflow: hidden;
}
.top {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 60px;
  background-color: #dfe0e7;
  .head{
    width: 1140px;
    height: 100%;
    margin: 0 auto;
  }
  .logo {
    float: left;
    width: 200px;
    height: 60px;
    background-color: #fff;
  }
  .language {
   float: right;
    width: 200px;
    height: 60px;
    background-color: #fff;
  }
}
// .left{
//     position: absolute;
//     top: 100px;
//     left: 0;
//     bottom: 50px;
//     width: 200px;
//     background-color: #3f4266;
// }
.right {
  position: absolute;
  overflow-x: hidden;
  overflow: auto;
  top: 60px;
  // left: 200px;
  left: 0;
  bottom: 50px;
  right: 0;
  background-color: #f6f2f7;
}
.bottom {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 50px;
  background-color: #5f67a8;
}
.inner {
  min-height: 600px;
  .container {
    margin: 0 auto;
    width: 1140px;
    margin-top: 10px;
  }
}
.el-collapse-item__header {
  background-color: #5f67a8;
}
</style>
