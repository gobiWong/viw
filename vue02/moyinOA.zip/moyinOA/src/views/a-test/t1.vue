<template>
  <div class="apply_online">
    <div class="title_tips">
      <p>请选择需要申请的产品并上传相关的文件资料</p>
    </div>
    <!-- 提交产品种类 -->
    <div class="upload_file">
      <el-form label-width="auto" ref="addDocumentForm" size="mini" :model="applyDocument">
        <el-form-item label="种类" :label-width="formLabelWidth" prop="categoryID">
          <!-- <el-select v-model="applyDocument.categoryID" placeholder="请选择产品">
            <el-option
              v-for="item in productList"
              :key="item.value"
              :label="item.categoryName"
              :value="item.categoryId"
            ></el-option>
          </el-select>-->
          <el-select v-model="applyDocument.categoryID" @change="proChange" placeholder="请选择产品">
            <el-option label="保险" value="1"></el-option>
            <el-option label="投顾" value="2" disabled></el-option>
            <el-option label="信托" value="3" disabled></el-option>
          </el-select>
        </el-form-item>

        <!-- <div class="insurance" v-for="(item,index) in productList" :key='index'>
          <el-form-item label="文件" :label-width="formLabelWidth" prop="insuranceFile">
            <el-upload
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">上传保险申请</el-button>
            </el-upload>
          </el-form-item>
        </div>-->
        <div class="insurance">
          <el-form-item label="文件" :label-width="formLabelWidth" prop="insuranceFile">
            <!-- <el-upload
              style="display:inline-block"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              accept=".xls, .xlsx"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button slot="trigger" size="small" type="primary" plain>选取文件</el-button>
                 <el-button type="primary" @click="submitUpload" size="small">导入数据</el-button>
              <el-button slot="trigger" @click="resetForm('addDocumentForm')" size="small">取 消</el-button>
            </el-upload>-->
            <!-- demo样式 -->
            <el-upload
              style="display:inline-block"
              :limit="1"
              class="upload-demo"
              ref="uploadPro"
              accept=".xls, .xlsx"
              :on-success="handleProFileSuccess"
              :before-upload="beforeProUpload"
              action
              :file-list="fileList"
              :http-request="uploadSectionProFile"
              :on-change="handleProChange"
              :auto-upload="false"
              v-model="applyDocument.insuranceFile"
            >
              <el-button slot="trigger" size="small" type="primary" plain>选取文件</el-button>
              <el-button
                slot="tip"
                plain
                type="info"
                @click="resetForm('addDocumentForm')"
                size="small"
              >重 置</el-button>
              <el-button
                style="margin-left: 10px;"
                size="small"
                icon="el-icon-upload2"
                type="success"
                @click="submitProUpload"
              >导入</el-button>
            </el-upload>
          </el-form-item>
        </div>
        <!-- <div class="insurance" v-if="this.applyDocument.categoryID==3">
          <el-form-item label="文件" :label-width="formLabelWidth" prop="insuranceFile">
            <el-upload
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">上传信托申请</el-button>
            </el-upload>
          </el-form-item>
        </div>-->
      </el-form>
      <!-- <div slot="footer" class="dialog-footer" v-if="this.applyDocument.categoryID">
        <el-button @click="resetForm('addDocumentForm')" size="small">取 消</el-button>
        <el-button type="primary" @click="submitUpload" size="small">确 定</el-button>
      </div>-->
    </div>
    <!-- 上传附件demo1 -->

    <!-- <div class="upload_file">
      <el-form label-width="auto" :rules="rules" ref="annexForm" size="mini" :model="annexFormList">
        <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
          <el-select
            v-model="annexFormList.categoryID"
            @change="((val)=>{changeStatus(val)})"
            placeholder="请选择附件类型"
          >
            <el-option label="身份证正面照片" value="1"></el-option>
            <el-option label="身份证反面照片" value="2"></el-option>
            <el-option label="住址证明扫描件" value="3"></el-option>
            <el-option label="出生证" value="4"></el-option>
            <el-option label="港澳通行证/护照（正面）" value="5"></el-option>
            <el-option label="*港澳通行证/护照（反面）" value="6"></el-option>
            <el-option label="户口" value="7"></el-option>
            <el-option label="其他" value="8"></el-option>
          </el-select>
        </el-form-item>

        <div class="insurance">
          <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
          
            <el-upload
              style="display:inline-block"
              class="upload-demo"
              ref="uploadAnnex"
              action
              accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
              :file-list="AnnexFileList"
              :http-request="uploadSectionAnnexFile"
              :before-upload="beforeAnnexUpload"
              :on-success="handleAnnexFileSuccess"
              :auto-upload="false"
            >
              <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
            
              <el-button
                style="margin-left: 10px;"
                size="small"
                icon="el-icon-upload2"
                type="success"
                @click="submitAnnexUpload"
              >上传附件</el-button>
            </el-upload>
          </el-form-item>
        </div>
      </el-form>
    </div>-->
    <div class="annex_content">
      <p class="pp">请选择需要申请的产品并上传相关的附件！</p>

      <div class="annex_from">
        <el-form :model="dynamicValidateForm" ref="dynamicValidateForm" class="demo-dynamic" inline>
          <div class="default">
            <el-form-item
              prop="email"
              label="类型1"
              :rules="[
      { required: true, message: '请输入邮箱地址', trigger: 'blur' },
      { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
    ]"
            >
              <div class="upload_file1">
                <el-form
                  class="temp_file"
                  :rules="rules"
                  ref="annexForm"
                  size="mini"
                  :model="annexFormList"
                >
                  <el-form-item style="width:180px" prop="categoryID">
                    <el-select
                      v-model="annexFormList.categoryID"
                      @change="((val)=>{changeStatus(val)})"
                      placeholder="请选择附件类型"
                    >
                      <el-option label="身份证正面照片" value="1"></el-option>
                      <el-option label="身份证反面照片" value="2"></el-option>
                      <el-option label="住址证明扫描件" value="3"></el-option>
                      <el-option label="出生证" value="4"></el-option>
                      <el-option label="港澳通行证/护照（正面）" value="5"></el-option>
                      <el-option label="*港澳通行证/护照（反面）" value="6"></el-option>
                      <el-option label="户口" value="7"></el-option>
                      <el-option label="其他" value="8"></el-option>
                    </el-select>
                  </el-form-item>

                  <div class="insurance">
                    <el-form-item :label-width="formLabelWidth" prop="insuranceFile">
                      <el-upload
                        style="display:inline-block"
                        class="upload-demo"
                        ref="uploadAnnex"
                        action
                        accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                        :file-list="AnnexFileList"
                        :http-request="uploadSectionAnnexFile"
                        :before-upload="beforeAnnexUpload"
                        :on-success="handleAnnexFileSuccess"
                        :auto-upload="false"
                      >
                        <el-button
                          slot="trigger"
                          size="small"
                          icon="el-icon-edit"
                          type="primary"
                          plain
                        >选取附件</el-button>

                        <el-button
                          style="margin-left: 10px;"
                          size="small"
                          icon="el-icon-upload2"
                          type="success"
                          @click="submitAnnexUpload"
                        >上传附件</el-button>
                      </el-upload>
                    </el-form-item>
                  </div>
                </el-form>
              </div>
            </el-form-item>
          </div>

          <el-form-item
            v-for="(domain, index) in dynamicValidateForm.domains"
            :label="'类型' + (index+2)"
            :key="domain.key"
            :prop="'domains.' + index + '.value'"
            :rules="{
      required: true, message: '域名不能为空', trigger: 'blur'
    }"
            class="file_item"
          >
            <div class="upload_file1">
              <el-form
                :rules="rules"
                ref="annexForm"
                class="temp_file"
                size="mini"
                :model="annexFormList"
              >
                <el-form-item prop="categoryID" style="width:180px">
                  <el-select
                    v-model="annexFormList.categoryID"
                    @change="((val)=>{changeStatus(val)})"
                    placeholder="请选择附件类型"
                  >
                    <el-option label="身份证正面照片" value="1"></el-option>
                    <el-option label="身份证反面照片" value="2"></el-option>
                    <el-option label="住址证明扫描件" value="3"></el-option>
                    <el-option label="出生证" value="4"></el-option>
                    <el-option label="港澳通行证/护照（正面）" value="5"></el-option>
                    <el-option label="*港澳通行证/护照（反面）" value="6"></el-option>
                    <el-option label="户口" value="7"></el-option>
                    <el-option label="其他" value="8"></el-option>
                  </el-select>
                </el-form-item>

                <div class="insurance">
                  <el-form-item :label-width="formLabelWidth" prop="insuranceFile">
                    <el-upload
                      style="display:inline-block"
                      class="upload-demo"
                      ref="uploadAnnex"
                      action
                      accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                      :file-list="AnnexFileList"
                      :http-request="uploadSectionAnnexFile"
                      :before-upload="beforeAnnexUpload"
                      :on-success="handleAnnexFileSuccess"
                      :auto-upload="false"
                    >
                      <el-button
                        slot="trigger"
                        size="small"
                        con="el-icon-edit"
                        type="primary"
                        plain
                      >选取附件</el-button>

                      <el-button
                        style="margin-left: 10px;"
                        size="small"
                        icon="el-icon-upload2"
                        type="success"
                        @click="submitAnnexUpload"
                      >上传附件</el-button>
                    </el-upload>
                  </el-form-item>
                </div>
              </el-form>
              <div class="delete el-icon-circle-close" @click.prevent="removeDomain(domain)"></div>
              <!-- <el-button class="delete" @click.prevent="removeDomain(domain)">删除</el-button> -->
            </div>
          </el-form-item>
          <el-form-item>
            <!-- <el-button type="primary" @click="submitForm('dynamicValidateForm')">提交</el-button>
        <el-button @click="addDomain">新增域名</el-button>
            <el-button @click="resetForm('dynamicValidateForm')">重置</el-button>-->
          </el-form-item>
        </el-form>

        <div class="btn_three">
          <el-button
            size="small"
            type="warning"
            icon="el-icon-check"
            @click="submitForm('dynamicValidateForm')"
          >提交</el-button>
          <el-button
            size="small"
            type="success"
            icon="el-icon-circle-plus-outline"
            @click="addDomain"
          >添加附件</el-button>
          <!-- <el-button size="small" type="info" @click="resetForm('dynamicValidateForm')">重置</el-button> -->
        </div>
      </div>

      <!-- 必须上传 -->
      <!-- <el-row :gutter="20">
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="类别" :label-width="formLabelWidth" prop="categoryID">
                <p>身份证正面</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="idCardFront"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="idCardFrontSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
               
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitIdCardFront"
                    >上传</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="类别" :label-width="formLabelWidth" prop="categoryID">
                <p>身份证反面</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                 
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="idCardSide"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
                
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitIdCardSide"
                    >上传</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="类别" :label-width="formLabelWidth" prop="categoryID">
                <p>港澳正面</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
               
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="hkCardFront"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
              
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitHkCardFront"
                    >上传</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="类别" :label-width="formLabelWidth" prop="categoryID">
                <p>港澳反面</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                 
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="hkCardSide"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
               
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitHkCardSide"
                    >上传</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
      </el-row>-->

      <!-- <el-button
                slot="tip"
                plain
                type="info"
                @click="resetForm('addDocumentForm')"
                size="small"
      >取 消</el-button>-->
      <!-- 可选上传 -->
      <!-- <el-row>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>身份证正面</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                 
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
                
                    <el-button
                      style="margin-left: 20px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>出生证</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>

                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传附件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>户口证</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>

                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传附件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>疫苗证</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传附件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
      </el-row>-->

      <!-- 附件提交保存 -->
      <!-- <div style="background:#fff;padding-bottom:10px;margin-top:10px;padding-top:10px;">
        <el-button
          style="margin-left: 10px;"
          size="small"
          icon="el-icon-check"
          type="warning"
          @click="submitAnnexList"
        >提交</el-button>
      </div> -->
    </div>

    <!-- 上传附件demo1 -->
    <!-- <div class="upload_annex">
      <el-row>
        <el-col :span="2">
          <p>
            <i>*</i>身份证正面照片
          </p>
        </el-col>
        <el-col :span="6">
          <div class="demo">
             
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :file-list="fileList"
              :auto-upload="false"
              :limit="1"
            >
             <el-button slot="trigger" size="small"  type="primary" plain>选择附件</el-button>
            </el-upload>
          </div>
        </el-col>
        <el-col :span="5">
          <el-button
            style="margin-left: 10px;"
            size="small"
            icon="el-icon-upload2"
            type="success"
            @click="submitProUpload"
          >上传</el-button>
        </el-col>
        <el-col :span="2">
          <el-button size="small" type="primary">重置</el-button>
        </el-col>
      </el-row>
    </div>-->

    <!-- <div class="upload_annex">

      <p>请选择需要申请的产品并上传相关的附件！</p>
      

      <el-row class="annex_list">
        <el-col :span="6">
          <p>
            <i>*</i>身份证正面照片
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>
            <i>*</i>港澳通行证/护照（正面）
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>住址证明扫描件</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>出生证</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
        </el-col>
        <el-col :span="14">
          <p>
            <i>*</i>身份证反面照片
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>
            <i>*</i>港澳通行证/护照（反面）
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>户口文件</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>其他</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
        </el-col>
      </el-row>

    </div>-->
  </div>
</template>
<script>
import axios from "axios";
import qs from "qs";
import {
  getProductCategory,
  importDocument,
  baseURL1
} from "@/api/applyOnline";
export default {
  data() {
    return {
      // success: false, //上传附件显隐o
      annexFiles: {
        applicationNumber: "", //申请号
        idCardFront: "", //身份证正面照片
        idCardSide: "", //身份证反面照片
        hkCardFront: "", //港澳通行证/护照（正面）
        hkCardSide: "" //港澳通行证/护照（反面）
      }, //提交新增的附件请求参数对象
      doUpload: `${baseURL1}/upload/uploadFile`, //上传文件地址
      applicationNumber: "", //申请号，新保险增附件用到。
      ProFile: {}, //上传产品文件列表
      formLabelWidth: "", //表单label宽度（可选）
      rules: {
        documentType: [
          { required: true, message: "请选文件类型", trigger: "change" }
        ],
        documentDetail: [
          { required: true, message: "请填写文件细节", trigger: "blur" }
        ],
        documentUrl: [
          {
            type: "date",
            required: true,
            message: "请选择文件",
            trigger: "change"
          }
        ]
      }, //表单验证
      productList: [
        {
          categoryId: 1,
          categoryName: "保险",
          categoryNo: "001",
          detailsCurrency: "美元",
          productLanguage: 1
        }
      ], // //产品列表 返回示例：
      categoryNames: [], //产品名称
      annexFormList: {}, //附件参数
      applyDocument: {
        userID: "", //用户ID 整数int
        categoryID: "", //产品ID string 1：保险 2：投顾 3：信托
        insuranceFile: "" //申请产品对应excel表格
      }, //产品参数
      fileList: [], //产品文件列表
      AnnexFileList: [] ,//附件文件列表
        dynamicValidateForm: {
        domains: [
          {
            value: ""
          }
        ],
        email: ""
      }
    };
  },

  created() {
    //获取产品列表
    getProductCategory().then(res => {
      // console.log(res);
      this.productList = res;
      // const [{ categoryName }] = res;

      res.forEach(item => this.categoryNames.push(item.categoryName));
      // console.log(this.categoryNames);
    });
  },

  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          alert("submit!");
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    removeDomain(item) {
      var index = this.dynamicValidateForm.domains.indexOf(item);
      if (index !== -1) {
        this.dynamicValidateForm.domains.splice(index, 1);
      }
    },
    addDomain() {
      this.dynamicValidateForm.domains.push({
        value: "",
        key: Date.now()
      });
    },




    // 上传文件，获取文件流
    handleProChange(file) {
      this.ProFile = file.raw;
      console.log("on-change方法获取文件：", file);
    },
    //产品上传前（可配置其他参数）
    beforeProUpload(file) {
      // let fd = new FormData();
      // fd.append("insuranceFile", file); //传文件
      // fd.append("categoryID", this.applyDocument.categoryID); //传其他参数
      // fd.append("userID", parseInt(this.$store.getters.userId));
      // // fd.append("insuranceFile", this.applyDocument.insuranceFile);
      // this.fd = fd;
      // this.fileList = [];
      // console.log(this.fd, "123");
      // axios
      //   .post(`${baseURL1}/applyWizard/importDocument`, this.fd)
      //   .then(res => {
      //     console.log(res);
      //     // this.getdocumentList();
      //     if (res.data.rtnCode === 0) {
      //       this.$message({
      //         type: "error",
      //         message: "导入数据失败！"
      //       });
      //     } else if (res.data.rtnCode === 1) {
      //       this.fileList = [{ name: res.data.data.name }];
      //       this.$message({
      //         type: "success",
      //         message: "操作成功！"
      //       });
      //       //  this.success = true;
      //     }
      //   });
    },
    //手动添加请求头（产品）功能与beforeProUpload一样
    uploadSectionProFile(param) {
      var fileObj = param.file;
      // FormData 对象
      var proForm = new FormData();
      // console.log("表单方式获取文件：", this.applyDocument.insuranceFile);
      // 文件对象
      proForm.append("insuranceFile", fileObj); //产品文件
      proForm.append("categoryID", this.applyDocument.categoryID); //传其他参数
      proForm.append("userID", parseInt(this.$store.getters.userId)); //用户id
      // proForm.append("insuranceFile", this.applyDocument.insuranceFile); //产品文件
      console.log("http-request方法获取文件", param.file);

      console.log(proForm);
      axios
        .post(`${baseURL1}/applyWizard/importDocument`, proForm)
        .then(res => {
          console.log(res);

          if (res.data.rtnCode === 0) {
            this.$message({
              type: "error",
              message: res.data.rtnMsg + ",请提交正确的表单数据！"
            });
          } else if (res.data.rtnCode === 1) {
            // this.fileList = [{ name: res.data.data.name }];
            this.$message({
              type: "success",
              message: res.data.rtnMsg
            });
            //保存申请号
            this.applicationNumber = res.data.data;
            this.annexFiles = {
              ...this.annexFiles,
              applicationNumber: res.data.data
            };
            //  this.success = true;
          }
        });
    },

    //附件上传前（可配置其他参数）
    beforeAnnexUpload(file) {
      // let fd = new FormData();
      // fd.append("insuranceFile", file); //传文件
      // fd.append("categoryID", this.applyDocument.categoryID); //传其他参数
      // fd.append("userID", parseInt(this.$store.getters.userId));
      // // fd.append("insuranceFile", this.applyDocument.insuranceFile);
      // this.fd = fd;
      // this.fileList = [];
      // console.log(this.fd, "123");
      // axios
      //   .post(`${baseURL1}/upload/uploadFile`, file)
      //   .then(res => {
      //     console.log(res);
      //     // this.getdocumentList();
      //     if (res.data.rtnCode === 0) {
      //       this.$message({
      //         type: "error",
      //         message: "导入数据失败！"
      //       });
      //     } else if (res.data.rtnCode === 1) {
      //       this.fileList = [{ name: res.data.data.name }];
      //       this.$message({
      //         type: "success",
      //         message: "操作成功！"
      //       });
      //       //  this.success = true;
      //     }
      //   });
    },
    //手动添加请求头（附件）功能与beforeProUpload一样
    uploadSectionAnnexFile(param) {
      var fileObj = param.file;
      // const nweFile = qs.stringfy(fileObj);
      // // FormData 对象
      var annexForm = new FormData();
      // // 文件对象
      annexForm.append("file", fileObj);
      // qs.stringfy()
      // form.append("categoryID", this.applyDocument.categoryID); //传其他参数
      // form.append("userID", parseInt(this.$store.getters.userId));
      // console.log(param.file);
      // console.log(form);
      axios.post(`${baseURL1}/upload/uploadFile`, annexForm).then(res => {
        console.log(res);
        // this.getdocumentList();
        if (res.data.rtnCode === 0) {
          this.$message({
            type: "error",
            message: "导入数据失败！"
          });
        } else if (res.data.rtnCode === 1) {
          // this.fileList = [{ name: res.data.data.name }];
          this.$message({
            type: "success",
            message: "操作成功！"
          });

          //  this.success = true;
        }
      });
    },

    //上传产品文件成功回调（产品）
    handleProFileSuccess(response, file, fileList) {
      console.log(this.applyDocument.categoryID);
      console.log("产品类型上传成功", response);
      // this.applyDocument.insuranceFile = URL.createObjectURL(file.raw);
    },
    //附件上传成功回调（附件）
    handleAnnexFileSuccess(response, file, fileList) {
      console.log("附件上传成功", response);
      // this.applyDocument.insuranceFile = URL.createObjectURL(file.raw);
    },

    //重置上传文件
    resetForm(formName) {
      // this.$refs[formName].resetFields();
      this.applyDocument.categoryID = "";
      this.fileList = [];
    },

    //提交上传产品文件（自定义手动上传哦）
    submitProUpload() {
      console.log(this.$refs.uploadPro.uploadFiles.length, "文件个数"); //判断是否已选择文件
      console.log(this.applyDocument.categoryID, "参数ID"); //产品参数id
      if (
        this.$refs.uploadPro.uploadFiles.length === 0 ||
        this.applyDocument.categoryID === ""
      ) {
        this.$message({
          type: "warning",
          message: "请选产品类型并导入数据文件！"
        });
      } else {
        // this.success = true;
        // this.$message({
        //   type: "success",
        //   message: "OK！"
        // });
        this.$refs.uploadPro.submit();
      }
    },
    //上传身份证正面（）
    submitIdCardFront() {
      // console.log("自动上传不用调用submit()方法");
      console.log("附件：", this.$refs.idCardFront.uploadFiles);
      this.$refs.idCardFront.submit();
    },
    idCardFrontSuccess(res, file) {
      this.annexFiles = {
        ...this.annexFiles,
        idCardFront: res.data.data
      };
    },
    //上传身份证反面（）
    submitIdCardSide() {
      // console.log("自动上传不用调用submit()方法");
      console.log("附件：", this.$refs.idCardSide.uploadFiles);
      this.$refs.idCardSide.submit();
    },
    //上传港澳正面（）
    submitHkCardFront() {
      // console.log("自动上传不用调用submit()方法");
      console.log("附件：", this.$refs.hkCardFront.uploadFiles);
      this.$refs.hkCardFront.submit();
    },
    //上传港澳反面（）
    submitHkCardSide() {
      // console.log("自动上传不用调用submit()方法");
      console.log("附件：", this.$refs.hkCardSide.uploadFiles);
      this.$refs.hkCardSide.submit();
    },

    //选择产品类型下拉框的值改变时
    proChange() {
      // console.log(3);
      // if (this.fileList.length != 0) {
      // }
      // this.fileList = [];
      // this.success = false;
    },
    //选择附件下拉框的值改变时
    changeStatus(val) {
      console.log(val);
      // console.log(3);
      // if (this.fileList.length != 0) {
      // }
      // this.fileList = [];
      // this.success = false;
    },
    //提交附件列表
    submitAnnexList() {
      console.log("提交");

      console.log(this.annexFiles);
    },
    //上传
    submitAnnexUpload(){
      // console.log("自动上传不用调用submit()方法");
      console.log("附件：", this.$refs.uploadAnnex.uploadFiles);
      this.$refs.uploadAnnex.submit();
    },
  }
};
</script>













































<style lang="less" scoped>
.apply_online {
  .title_tips {
    width: 100%;
    height: 30px;
  }
  .upload_file {
    height: 140px;
    padding: 10px;
    background-color: #fff;
    p {
      font-size: 16px;
    }
  }
  .annex_content {
    .pp {
      height: 50px;
      line-height: 45px;
    }
    .annex_from{
      .demo-dynamic {
  padding-left: 10px;
  margin-top: 5px;
 margin-bottom: 10px;
  .default {
    margin-right: 15px;
    display: inline-block;
    background: #fff;
    height: 160px;
    width: 300px;
  }
  .file_item {
    background-color: #fff;
    height: 160px;
    width: 300px;
    margin-right: 20px;
  }
}
.btn_three {
  margin-top: 20px;
}
.upload_file1 {
  position: relative;
  padding-right: 5px;
  .temp_file {
    margin-top: 5px;
  }

  .delete {
    position: absolute;
    text-align: center;
    border: none;
    width: 30px;
    height: 30px;
  
    top: -5px;
    right: -44px;
    // background-color: #ccc;
    cursor: pointer;
  }
}
    }
  }
  .upload_annex {
    // background-color: #555;
    width: 100%;
    height: 100px;
    .annex_list {
      p {
        font-weight: 550;
        line-height: 26px;
        font-size: 14px;
        i {
          color: red;
        }
      }
    }
    .demo {
      .upload_demo {
        display: flex;
        box-sizing: border-box;
        //  align-items: center;
        justify-content: space-around;
        background-color: aqua;
        height: 38px;
        line-height: 38px;

        /deep/.el-upload-list__item:first-child {
          margin-top: 0;
          width: 100%;
          line-height: 38px;
        }
      }
    }
  }
  .el-tabs {
    /deep/.el-tabs__header {
      text-align: center;

      position: relative;
      margin: 0 0 20px;
    }
    height: 800px;
    background-color: #aaa;
    padding: 0 30px 0;
    .el-tab-pane {
      box-sizing: border-box;
      width: 100%;
      height: 660px;
      padding-bottom: 20px;
    }
    .el-tab-pane:nth-of-type(1) {
      background-color: #eee;
    }
    .el-tab-pane:nth-of-type(2) {
      background-color: #ccc;
    }
    .el-tab-pane:nth-of-type(3) {
      background-color: rgb(172, 165, 165);
    }
    .el-tab-pane:nth-of-type(4) {
      background-color: rgb(124, 104, 156);
    }
  }
  .dialog-footer {
    position: absolute;
    left: 2%;
    top: 25%;
  }
}






</style>
