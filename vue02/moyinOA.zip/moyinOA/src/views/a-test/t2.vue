<div class="annex_from">
        <el-form :model="dynamicValidateForm" ref="dynamicValidateForm" class="demo-dynamic" inline>
          <div class="default">
            <el-form-item
              prop="email"
              label="类型1"
              :rules="[
      { required: true, message: '请输入邮箱地址', trigger: 'blur' },
      { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
    ]"
            >
              <div class="upload_file1">
                <el-form
                  class="temp_file"
                  :rules="rules"
                  ref="annexForm"
                  size="mini"
                  :model="annexFormList"
                >
                  <el-form-item style="width:180px" prop="categoryID">
                    <el-select
                      v-model="annexFormList.categoryID"
                      @change="((val)=>{changeStatus(val)})"
                      placeholder="请选择附件类型"
                    >
                      <el-option label="身份证正面照片" value="1"></el-option>
                      <el-option label="身份证反面照片" value="2"></el-option>
                      <el-option label="住址证明扫描件" value="3"></el-option>
                      <el-option label="出生证" value="4"></el-option>
                      <el-option label="港澳通行证/护照（正面）" value="5"></el-option>
                      <el-option label="*港澳通行证/护照（反面）" value="6"></el-option>
                      <el-option label="户口" value="7"></el-option>
                      <el-option label="其他" value="8"></el-option>
                    </el-select>
                  </el-form-item>

                  <div class="insurance">
                    <el-form-item :label-width="formLabelWidth" prop="insuranceFile">
                      <el-upload
                        style="display:inline-block"
                        class="upload-demo"
                        ref="uploadAnnex"
                        action
                        accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                        :file-list="AnnexFileList"
                        :http-request="uploadSectionAnnexFile"
                        :before-upload="beforeAnnexUpload"
                        :on-success="handleAnnexFileSuccess"
                        :auto-upload="false"
                      >
                        <el-button
                          slot="trigger"
                          size="small"
                          icon="el-icon-edit"
                          type="primary"
                          plain
                        >选取附件</el-button>

                        <el-button
                          style="margin-left: 10px;"
                          size="small"
                          icon="el-icon-upload2"
                          type="success"
                          @click="submitAnnexUpload"
                        >上传附件</el-button>
                      </el-upload>
                    </el-form-item>
                  </div>
                </el-form>
              </div>
            </el-form-item>
          </div>

          <el-form-item
            v-for="(domain, index) in dynamicValidateForm.domains"
            :label="'类型' + (index+2)"
            :key="domain.key"
            :prop="'domains.' + index + '.value'"
            :rules="{
      required: true, message: '域名不能为空', trigger: 'blur'
    }"
            class="file_item"
          >
            <div class="upload_file1">
              <el-form
                :rules="rules"
                ref="annexForm"
                class="temp_file"
                size="mini"
                :model="annexFormList"
              >
                <el-form-item prop="categoryID" style="width:180px">
                  <el-select
                    v-model="annexFormList.categoryID"
                    @change="((val)=>{changeStatus(val)})"
                    placeholder="请选择附件类型"
                  >
                    <el-option label="身份证正面照片" value="1"></el-option>
                    <el-option label="身份证反面照片" value="2"></el-option>
                    <el-option label="住址证明扫描件" value="3"></el-option>
                    <el-option label="出生证" value="4"></el-option>
                    <el-option label="港澳通行证/护照（正面）" value="5"></el-option>
                    <el-option label="*港澳通行证/护照（反面）" value="6"></el-option>
                    <el-option label="户口" value="7"></el-option>
                    <el-option label="其他" value="8"></el-option>
                  </el-select>
                </el-form-item>

                <div class="insurance">
                  <el-form-item :label-width="formLabelWidth" prop="insuranceFile">
                    <el-upload
                      style="display:inline-block"
                      class="upload-demo"
                      ref="uploadAnnex"
                      action
                      accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                      :file-list="AnnexFileList"
                      :http-request="uploadSectionAnnexFile"
                      :before-upload="beforeAnnexUpload"
                      :on-success="handleAnnexFileSuccess"
                      :auto-upload="false"
                    >
                      <el-button
                        slot="trigger"
                        size="small"
                        con="el-icon-edit"
                        type="primary"
                        plain
                      >选取附件</el-button>

                      <el-button
                        style="margin-left: 10px;"
                        size="small"
                        icon="el-icon-upload2"
                        type="success"
                        @click="submitAnnexUpload"
                      >上传附件</el-button>
                    </el-upload>
                  </el-form-item>
                </div>
              </el-form>
              <div class="delete el-icon-circle-close" @click.prevent="removeDomain(domain)"></div>
              <!-- <el-button class="delete" @click.prevent="removeDomain(domain)">删除</el-button> -->
            </div>
          </el-form-item>
          <el-form-item>
            <!-- <el-button type="primary" @click="submitForm('dynamicValidateForm')">提交</el-button>
        <el-button @click="addDomain">新增域名</el-button>
            <el-button @click="resetForm('dynamicValidateForm')">重置</el-button>-->
          </el-form-item>
        </el-form>

        <div class="btn_three">
          <el-button
            size="small"
            type="warning"
            icon="el-icon-check"
            @click="submitForm('dynamicValidateForm')"
          >提交</el-button>
          <el-button
            size="small"
            type="success"
            icon="el-icon-circle-plus-outline"
            @click="addDomain"
          >添加附件</el-button>
          <!-- <el-button size="small" type="info" @click="resetForm('dynamicValidateForm')">重置</el-button> -->
        </div>
      </div>






         <!-- <div class="upload_file">
      <el-form label-width="auto" :rules="rules" ref="annexForm" size="mini" :model="annexFormList">
        <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
          <el-select
            v-model="annexFormList.categoryID"
            @change="((val)=>{changeStatus(val)})"
            placeholder="请选择附件类型"
          >
            <el-option label="身份证正面照片" value="1"></el-option>
            <el-option label="身份证反面照片" value="2"></el-option>
            <el-option label="住址证明扫描件" value="3"></el-option>
            <el-option label="出生证" value="4"></el-option>
            <el-option label="港澳通行证/护照（正面）" value="5"></el-option>
            <el-option label="*港澳通行证/护照（反面）" value="6"></el-option>
            <el-option label="户口" value="7"></el-option>
            <el-option label="其他" value="8"></el-option>
          </el-select>
        </el-form-item>

        <div class="insurance">
          <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
          
            <el-upload
              style="display:inline-block"
              class="upload-demo"
              ref="uploadAnnex"
              action
              accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
              :file-list="AnnexFileList"
              :http-request="uploadSectionAnnexFile"
              :before-upload="beforeAnnexUpload"
              :on-success="handleAnnexFileSuccess"
              :auto-upload="false"
            >
              <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
            
              <el-button
                style="margin-left: 10px;"
                size="small"
                icon="el-icon-upload2"
                type="success"
                @click="submitAnnexUpload"
              >上传附件</el-button>
            </el-upload>
          </el-form-item>
        </div>
      </el-form>
    </div>-->








    <!-- <el-button
                slot="tip"
                plain
                type="info"
                @click="resetForm('addDocumentForm')"
                size="small"
      >取 消</el-button>-->
      <!-- 可选上传 -->
      <!-- <el-row>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>身份证正面</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                 
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
                
                    <el-button
                      style="margin-left: 20px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>出生证</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>

                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传附件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>户口证</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>

                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传附件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="upload_file">
            <el-form
              label-width="auto"
              :rules="rules"
              ref="annexForm"
              size="mini"
              :model="annexFormList"
            >
              <el-form-item label="附件类别" :label-width="formLabelWidth" prop="categoryID">
                <p>疫苗证</p>
              </el-form-item>

              <div class="insurance">
                <el-form-item label="附件" :label-width="formLabelWidth" prop="insuranceFile">
                  <el-upload
                    style="display:inline-block"
                    class="upload-demo"
                    ref="uploadAnnex"
                    action
                    accept=".jpg, .jpeg, .png, .gif, .bmp, .pdf, .JPG, .JPEG, .PBG, .GIF, .BMP, .PDF"
                    :file-list="AnnexFileList"
                    :http-request="uploadSectionAnnexFile"
                    :before-upload="beforeAnnexUpload"
                    :on-success="handleAnnexFileSuccess"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary" plain>选取附件</el-button>
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      icon="el-icon-upload2"
                      type="success"
                      @click="submitAnnexUpload"
                    >上传附件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </el-col>
      </el-row>-->









       <!-- 上传附件demo1 -->
    <!-- <div class="upload_annex">
      <el-row>
        <el-col :span="2">
          <p>
            <i>*</i>身份证正面照片
          </p>
        </el-col>
        <el-col :span="6">
          <div class="demo">
             
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :file-list="fileList"
              :auto-upload="false"
              :limit="1"
            >
             <el-button slot="trigger" size="small"  type="primary" plain>选择附件</el-button>
            </el-upload>
          </div>
        </el-col>
        <el-col :span="5">
          <el-button
            style="margin-left: 10px;"
            size="small"
            icon="el-icon-upload2"
            type="success"
            @click="submitProUpload"
          >上传</el-button>
        </el-col>
        <el-col :span="2">
          <el-button size="small" type="primary">重置</el-button>
        </el-col>
      </el-row>
    </div>-->

    <!-- <div class="upload_annex">

      <p>请选择需要申请的产品并上传相关的附件！</p>
      

      <el-row class="annex_list">
        <el-col :span="6">
          <p>
            <i>*</i>身份证正面照片
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>
            <i>*</i>港澳通行证/护照（正面）
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>住址证明扫描件</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>出生证</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
        </el-col>
        <el-col :span="14">
          <p>
            <i>*</i>身份证反面照片
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>
            <i>*</i>港澳通行证/护照（反面）
          </p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>户口文件</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
          <p>其他</p>
          <div class="demo">
            <el-upload
              class="upload_demo"
              v-model="applyDocument.insuranceFile"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              :file-list="fileList"
              :on-success="handleFileSuccess"
              :auto-upload="false"
              :limit="1"
            >
              <el-button size="small" type="primary">选择附件</el-button>
            </el-upload>
          </div>
        </el-col>
      </el-row>

    </div>-->