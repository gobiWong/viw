<template>
  <div class="query">
    <!-- 搜素表头 -->
    <div class="mm_button">
      <el-form
        :inline="true"
        :model="formInline"
        ref="serviceForm"
        class="demo-form-inline"
        size="small"
      >
        <el-form-item prop="user">
          <el-input v-model="formInline.user" placeholder="介绍人代码"></el-input>
        </el-form-item>
        <el-form-item prop="region">
          <el-select v-model="formInline.region" placeholder="产品">
            <el-option label="德贤" value="shanghai"></el-option>
            <el-option label="金沙" value="beijing"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item prop="region">
          <el-select v-model="formInline.region" placeholder="选择状态">
            <el-option label="德贤" value="shanghai"></el-option>
            <el-option label="金沙" value="beijing"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            icon="el-icon-search"
            @click="onSubmit('serviceForm')"
            plain
            size="small"
          >搜索</el-button>
          <el-button
            type="info"
            icon="el-icon-delete"
            @click="onReset('serviceForm')"
            plain
            size="small"
          >重置</el-button>
          <!-- <el-button type="success" icon="el-icon-share" size="small" @click="startFilter">开启</el-button> -->
        </el-form-item>
      </el-form>
    </div>



    <!-- 保留备用 -->
    <!-- <el-button @click="resetDateFilter">清除日期过滤器</el-button>
    <el-button @click="clearFilter">清除所有过滤器</el-button> -->

    <div class="query_table">
      <el-table ref="filterTable" :data="tableData" style="width: 100%">
      <el-table-column
        prop="intro_code"
        label="介绍人代码"
        sortable
        width="180"
        column-key="date"
        :filters="[{text: '9527', value: '9527'}, {text: 'WJ957', value: 'WJ957'}, {text: 'GTR8000', value: 'GTR8000'}, {text: 'hhuy2232', value: 'hhuy2232'}]"
        :filter-method="filterHandler"
      ></el-table-column>
      <el-table-column prop="intro_name" label="介绍人名字" width="100"></el-table-column>
      <el-table-column prop="account_num" label="帐户号码" :formatter="formatter" width="100"></el-table-column>
      <el-table-column prop="account_name" label="帐户持有人姓名" width="180"></el-table-column>
      <el-table-column prop="query_status" label="状态" width="80"></el-table-column>
      <el-table-column prop="product" label="产品" width="80"></el-table-column>
      <el-table-column prop="effect_date" label="生效日期"></el-table-column>
      <el-table-column prop="close_date" label="关闭日期"></el-table-column>
      <el-table-column
        prop="tag"
        label="标签"
        width="100"
        :filters="[{ text: '完成', value: '完成' }, { text: '未处理', value: '未处理' }]"
        :filter-method="filterTag"
        filter-placement="bottom-end"
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.tag === '未处理' ? 'primary' : 'success'"
            disable-transitions
          >{{scope.row.tag}}</el-tag>
        </template>
      </el-table-column>
    </el-table>
    </div>
    
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [
        {
          intro_code: "9527",
          intro_name: "王小虎",
          account_num: "jb33658",
          account_name: "张总",
          query_status: "默认",
          product: "融科天城",
          effect_date: "2018-01-01",
          close_date: "2019-08-08",
          tag: "完成"
        },
        {
          intro_code: "WJ957",
          intro_name: "王大锤",
          account_num: "DC123456",
          account_name: "克里斯.岚",
          query_status: "冻结",
          product: "基金",
          effect_date: "2019-01-01",
          close_date: "2019-06-06",
          tag: "完成"
        },
        {
          intro_code: "GTR8000",
          intro_name: "王多余",
          account_num: "DY52638",
          account_name: "建林",
          query_status: "正常",
          product: "万达",
          effect_date: "2017-09-06",
          close_date: "2019-12-05",
          tag: "完成"
        },
        {
          intro_code: "hhuy2232",
          intro_name: "柯基",
          account_num: "HJ55586",
          account_name: "胡冰",
          query_status: "正常",
          product: "证券",
          effect_date: "2018-06-25",
          close_date: "2019-06-31",
          tag: "未处理"
        }
      ],
      value: [],
       //搜索选框测试数据
      formInline: {
        user: "",
        region: ""
      }
    };
  },
  methods: {
    //表头搜索提交按钮
    onSubmit(formName) {},
    //表头搜索重置按钮
    onReset(formName) {
      this.$refs[formName].resetFields();
    },



    resetDateFilter() {
      this.$refs.filterTable.clearFilter("date");
    },
    clearFilter() {
      this.tableData.map(item => {
        return this.value.push(item.intro_code);
      });
      // console.log(this.value);




    },
    formatter(row, column) {
      return row.account_num;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    }
  }
};
</script>


<style lang="less" scoped>
.query{
    .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    // .el-button{
    //     height: 30px;
    //     text-align: center;
    // }
  }
  .query_table {
    margin-top: 10px;
  }
}
</style>
