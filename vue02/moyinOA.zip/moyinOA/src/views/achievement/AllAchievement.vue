<template>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    style="width: 100%"
  >
    <el-table-column class="head_template">
      <template slot="header" slot-scope="" class="head_template">
        <el-input v-model="search" size="mini" placeholder="输入日期搜索"/>
      </template>
      <el-table-column label="Date" prop="date"></el-table-column>
    </el-table-column>
    <el-table-column>
      <template slot="header" slot-scope="">
        <el-input v-model="search" size="mini" placeholder="输入名字搜索"/>
      </template>
      <el-table-column label="Name" prop="name"></el-table-column>
    </el-table-column>
    <el-table-column>
      <template slot="header" slot-scope="">
        <el-input v-model="search" size="mini" placeholder="输入地址搜索"/>
      </template>
      <el-table-column label="Address" prop="address"></el-table-column>
    </el-table-column>


<el-table-column label="操作">
       
        <template slot-scope="scope">
        <el-button size="mini" plain @click="handleEdit(scope.$index, scope.row)">Edit</el-button>
        <el-button size="mini" plain type="danger" @click="handleDelete(scope.$index, scope.row)">Delete</el-button>
      </template>
      </el-table-column>
   
  </el-table>
</template>

<script>
export default {
  data() {
    return {
      tableData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄"
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄"
        }
      ],
      search: ""
    };
  },
  methods: {
    handleEdit(index, row) {
      // console.log(index, row);
    },
    handleDelete(index, row) {
      // console.log(index, row);
    }
  }
};
</script>