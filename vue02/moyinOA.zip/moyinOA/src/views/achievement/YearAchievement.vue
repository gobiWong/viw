
<template>
  <div class="service_online">
    <div class="mm_table">
      <el-table
        :data="tableData"
        v-loading="loading"
        border
        style="width: 100%"
        :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'center',
     }"
        :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    }"
      >
        <el-table-column prop="applicationNumber" label=" 申请编号" width="220" sortable>
          <template slot-scope="scope">
            <el-button
              @click.prevent="messageDetail(scope.row)"
              type="text"
              size="small"
            >{{scope.row.applicationNumber}}</el-button>
          </template>
        </el-table-column>

        <el-table-column prop="insuranceCompany" label="产品" width="180"></el-table-column>
        <el-table-column prop="plan_times" label="次数"></el-table-column>
        <el-table-column prop="recordStatus2" label="状态"></el-table-column>
        <el-table-column prop="createTime" sortable label="生效日期"></el-table-column>
        <el-table-column prop="annualPremium" label="供款额"></el-table-column>
        <el-table-column prop="points" label="累计点数"></el-table-column>
      </el-table>

      <!-- 分页工具 -->
      <div class="page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="1"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="10"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
        <!-- <Pagination></Pagination> -->
      </div>
    </div>
    <!-- 详细信息 -->
    <el-dialog
      title="详细信息"
      top="5vh"
      :visible.sync="detailVisible"
      width="80%"
      :before-close="handleClose"
    >
      <el-card class="box-card" shadow="never">
        <el-row class="user_info">
          <el-col :span="8">
            <div class="grid-content bg-purple">
              <h3>参考#</h3>
              <p>565810</p>
              <h3>独一编号</h3>
              <p>2108960</p>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="grid-content bg-purple-light">
              <h3>全名</h3>
              <p>565810</p>
              <h3>档案文件类型</h3>
              <p>2108960</p>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="grid-content bg-purple">
              <h3>介绍人</h3>
              <p>565810</p>
              <h3>最后更新</h3>
              <p>2019-07-14 23:35:48</p>
            </div>
          </el-col>
        </el-row>
      </el-card>
      <el-card class="box-card" shadow="never">
        <el-row class="user_info">
          <el-col :span="24">
            <div class="grid-content bg-purple">
              <h3>验证报告：</h3>
              <ul class="report_list">
                <li>ASDCJJJYEUCB.PDF</li>
                <li>ADFRGIDFHEWFHIO(VER 20-190).PGF</li>
                <li>HHFHEWOFJDYFEJIIJISJAKCJAS(VER1.23).PDF</li>
              </ul>
            </div>
          </el-col>
        </el-row>
      </el-card>
      <el-card class="box-card" shadow="never">
        <el-row class="third_info">
          <el-col :span="8">
            <div class="third_left">
              <p>
                <i>讯息#:</i>
                <span>1407860</span>
              </p>
              <p>
                <i>提交人:</i>
                <span>System（ITA）</span>
              </p>
              <p>
                <i>日期:</i>
                <span>2019-07-14 23:26:16</span>
              </p>
            </div>
          </el-col>
          <el-col :span="16">
            <div class="third_right">
              <p>此协议/申请书将继续等待核准，直到我们收齐及审核所有文件</p>
              <p>若已提交所有的文件，我们将会立即审核此协议/申请书。必要时，我们将会发布一个新信息以要求任何缺少，不完整或额外（若需要）丶以及需要更正的资讯或文件。</p>
            </div>
          </el-col>
        </el-row>
      </el-card>
      <el-card class="box-card forth" shadow="never">
        <el-row class="third_info">
          <el-col :span="8">
            <div class="third_left">
              <p>
                <i>讯息#:</i>
                <span>1407860</span>
              </p>
              <p>
                <i>提交人:</i>
                <span>System（ITA）</span>
              </p>
              <p>
                <i>日期:</i>
                <span>2019-07-14 23:26:16</span>
              </p>
              <p>
                <i>附件:</i>
              </p>
              <ul class="report_list">
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4...</li>
              </ul>
            </div>
          </el-col>
          <el-col :span="16">
            <div class="forth_right">
              <p>您好：</p>
              <p>收到顾问的报聘协议书。</p>
              <p>经审核，烦请顾问568810查看上方文件分享区验证报告"SDF-dd.pdf"</p>
              <p>-若顾问确认与验证报告里提及的人士为同一人，请于此线上服务互动平台通知我们。</p>
              <p>-若顾问确认本人并非与验证报告"SDF-dd.pdf"里所提及的人士为同一人,请提交以下文件:</p>
              <p>(i)请完成并提交II204身份证明声明书.</p>
              <p>(ii)请在验证报告"SDF-dd.pdf"的每一页空白处简签,证明顾问已查阅相关文件。</p>
              <p>谢谢您。</p>
            </div>
          </el-col>
        </el-row>
      </el-card>
      <span slot="footer" class="dialog-footer">
        <el-button @click="detailVisible = false" size="small">取 消</el-button>
        <el-button type="primary" @click="detailVisible = false" size="small">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { queryPerform } from "@/api/achievement";
export default {
  data() {
    return {
      loading: true,
      detailVisible: false, //详情信息弹框
      pageSize: 10, //每页显示数量
      pageNum: 1, //页数
      total: 0, //总条数
      tableData: [
        {
          plan_num: "yy9527",
          plan_times: "王小虎",
          plan_status: "金沙",
          effect_date: "类型1",
          company: "2020-02-02",
          counts: "已读",
          money: "未读消息",
          Contribution: "100",
          points: "3000"
        },
        {
          annualPremium: "105000", //供款额
          applicationNumber: "156137644965291140174", //产品编号
          createTime: "2019-07-23 09:33:06", //日期
          insuranceCompany: "平安", //产品
          productCurrency: "HKD", //货币
          recordStatus: 1, //计划状态
          recordStatus2: "等待审核中" //状态说明
        }
      ]
    };
  },

  created() {
    this.initList();
  },

  methods: {
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.pageSize = val;
      // this.pageNum = 1;
      this.initList();
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.pageNum = val;
      this.initList();
    },
    //获取详情弹框
    messageDetail(row) {
      this.detailVisible = true;
      console.log(row);
    },

    handleClose() {
      this.detailVisible = false;
    },
    // 初始化表格数据
    initList() {
      this.loading = true;

      queryPerform({
        userId: 1,
        queryType: 1,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
        console.log(res);
        this.tableData = res.dataList;
        this.pageSize = res.myPageInfo.pageSize; //每页显示数量
        this.pageNum = res.myPageInfo.currentPage; //页数
        this.total = res.myPageInfo.total; //总条数
        this.loading = false;
      });
    },

    searchFilter() {},
    resetDateFilter() {
      this.$refs.filterTable.clearFilter("date");
    },
    clearFilter() {
      this.$refs.filterTable.clearFilter();
    },
    startFilter() {},
    formatter(row, column) {
      return row.address;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    }
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    // .el-button{
    //     height: 30px;
    //     text-align: center;
    // }
  }
  .mm_table {
    margin-top: 10px;
  }
}
.box-card {
  background-color: #eee;
  margin-bottom: 10px;
}
.report_list {
  text-indent: 0.5em;
  line-height: 20px;
}
.forth {
  height: 260px;
  .forth_right {
    height: 200px;
    line-height: 20px;
    background-color: #fff;
    margin: 10px 5px 0 0;
  }
}
.user_info {
  h3 {
    font-weight: 600;
    line-height: 20px;
  }
  p {
    line-height: 20px;
  }
}
.third_info {
  .third_left {
    p > i {
      font-weight: 600;
      line-height: 20px;
    }
  }
  .third_right {
    margin-top: 6px;
    margin-right: 5px;
    background-color: #fff;
    line-height: 20px;
  }
}
.forth_right {
  height: 200px;
}
</style>
