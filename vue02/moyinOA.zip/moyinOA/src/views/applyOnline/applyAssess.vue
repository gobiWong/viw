<template>
  <div>
    <el-collapse v-model="activeName"  @change="handleChange">
      <el-collapse-item title="付款的信息" name="1">
        <div class="guide">
          <el-form
            :model="addForm"
            label-width="auto"
            label-position="top"
            :rules="rules"
            size="small"
            ref="addIntroducerForm"
          >
            <p>供款类型</p>
            <el-form-item prop="englishName">
              <el-select v-model="addForm.englishName" placeholder="供款类型">
                <el-option label="新件申请" value="新件申请"></el-option>
                <el-option label="新附加计划" value="新附加计划"></el-option>
                <el-option label="续缴款项" value="续缴款项"></el-option>
                <el-option label="超额供款" value="超额供款"></el-option>
              </el-select>
            </el-form-item>
            <p>计划案状态</p>
            <el-form-item prop="chineseName">
              <el-select v-model="addForm.chineseName" placeholder="计划案状态">
                <el-option label="新计划（还未递至公司的新化）" value="新计划（还未递至公司的新化）"></el-option>
                <el-option label="新计划（未递至公司，但已有存在的计划案）" value="新计划（未递至公司，但已有存在的计划案）"></el-option>
                <el-option label="审核中的新计划（已递送至公司的新计划）" value="审核中的新计划（已递送至公司的新计划）"></el-option>
              </el-select>
            </el-form-item>
            <p>计划号码</p>
            <el-form-item prop="englishName">
              <el-input
                v-model="addForm.englishName"
                auto-complete="off"
                prefix-icon="el-icon-user"
                placeholder="计划号码"
              ></el-input>
            </el-form-item>
            <p>此次付款金额</p>
            <el-form-item prop="beneficiaryBirthday">
              <el-input
                v-model="addForm.beneficiaryBirthday"
                auto-complete="off"
                prefix-icon="el-icon-user"
              ></el-input>
            </el-form-item>
            <p>供款方式</p>
            <el-form-item prop="beneficiarySex">
              <el-select v-model="addForm.beneficiarySex" placeholder="供款方式">
                <el-option label="从美国银行账户自动扣款" value="从美国银行账户自动扣款"></el-option>
                <el-option label="行用卡" value="行用卡"></el-option>

                <el-option label="支票" value="支票"></el-option>
                <el-option label="电汇" value="电汇"></el-option>
                <el-option label="资产转移（仅限投资组合系列产品）" value="资产转移（仅限投资组合系列产品）"></el-option>
              </el-select>
            </el-form-item>
            <p>供款来源</p>
            <el-form-item prop="countryId">
              <el-select v-model="addForm.countryId" placeholder="供款来源" prefix-icon="el-icon-user">
                <el-option label="个人账户" value="个人账户"></el-option>
                <el-option label="第三方账户" value="第三方账户"></el-option>
                <el-option label="投资顾问" value="投资顾问"></el-option>
              </el-select>
            </el-form-item>
            <p>供款来源国家</p>
            <el-form-item prop="languageId">
              <el-select v-model="addForm.languageId" placeholder="供款来源国家">
                <el-option
                  v-for="(item,index) in langs"
                  :key="index"
                  :label="item.countryName"
                  :value="item.languageId"
                ></el-option>
              </el-select>
            </el-form-item>
            <p>财力来源</p>
            <el-form-item prop="departmentId">
              <el-select v-model="addForm.departmentId" placeholder="财力来源">
                <el-option label="买卖房地产或其他投资项目" value="买卖房地产或其他投资项目"></el-option>
                <el-option label="奖金" value="奖金"></el-option>
                <el-option label="投资/投资组合" value="投资/投资组合"></el-option>
                <el-option label="投资期满" value="投资期满"></el-option>
                <el-option label="收入所得（薪资/其他）" value="收入所得（薪资/其他）"></el-option>
                <el-option label="继承" value="继承"></el-option>
                <el-option label="赠款" value="赠款"></el-option>
              </el-select>
            </el-form-item>
            <!-- <el-form-item label="语言" prop="languageId">
            <el-select v-model="addForm.languageId" placeholder="语言">
              <el-option
                v-for="(item,index) in langs"
                :key="index"
                :label="item.countryName"
                :value="item.languageId"
              ></el-option>
            </el-select>
            </el-form-item>-->
          </el-form>
          <div class="guide_confirm">
            <el-button type="primary" size="small" @click="closed">确定</el-button>
          </div>
        </div>
      </el-collapse-item>
      
    </el-collapse>
    <el-collapse v-model="activeName" @change="handleChange">
      <el-collapse-item title="结果" name="2" :disabled="flag">
        <div class="clause_content">
          <el-row style="font-size:18px;font-weight:600;line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">产品</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">亚盛投资组合5025</div>
            </el-col>
          </el-row>
          <el-row style="line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">产品代码：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">ACS5025E</div>
            </el-col>
          </el-row>
          <el-row style="line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">货币：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">欧元</div>
            </el-col>
          </el-row>
          <el-row style="line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">最低供款额：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">€75，000</div>
            </el-col>
          </el-row>
          <el-row style="line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">最低超额金额：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">€7，500</div>
            </el-col>
          </el-row>
          <el-row style="line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">设置费用：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">无</div>
            </el-col>
          </el-row>
          <el-row style="line-height:36px">
            <el-col :span="6">
              <div class="grid-content bg-purple">计划手续费：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light">每季€180（每年€720）。</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <div class="grid-content bg-purple" style="height:60px;line-height:36px">投资交易细节*：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light" style="height:60px;line-height:18px">
                <p>最低交易金额为€7，500。</p>
                <p>交易费每次€30。</p>
                <p>*若资产最低交易额高于产品最低交易额,将采用资产最低交易额计算。</p>
              </div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <div class="grid-content bg-purple" style="height:50px;line-height:36px">资产流动限制：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light" style="height:50px;line-height:20px">
                <p>现金账户必须保证足够的余额以支付手续费及产品整体的费用。</p>
                <p>若在任何的时候此账户的余额是负值，将采用透支利率计算利息。</p>
              </div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <div class="grid-content bg-purple" style="height:50px;line-height:36px">行政费用：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light" style="height:50px;line-height:20px">
                <p>以已支付的供款金额或账户价值为计算基础，</p>
                <p>于计划前5年每季采较高者扣取0.3625%（每年1.45%）行政费。</p>
              </div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <div class="grid-content bg-purple" style="height:120px;line-height:60px">解约费用：</div>
            </el-col>
            <el-col :span="18">
              <div class="grid-content bg-purple-light" style="height:120px ;line-height:16px">
                <p>以已支付的供款金额或账户价值为计算基础,费用采较高者扣取</p>
                <p>自初始赎回费用7.25%开始，每日降低，到第五年底为零。</p>
                <p>1年底-5.80%</p>
                <p>2年底-4.35%</p>
                <p>3年底-2.90%</p>
                <p>4年底-1.45%</p>
                <p>5年底-0.00%</p>
              </div>
            </el-col>
          </el-row>
        </div>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>
<script>
import {
  getUserList,
  getStaffuserList,
  addStaff,
  getLanguage,
  getCountryList,
  getDepartmentList,
  getUserById,
  editUser,
  getRoleList,
  grantUserRole
} from "@/api";
export default {
  data() {
    return {
      loading: true,
      flag: false,
      activeName: "1",
      tableData: [
        {
          name: "王小虎",
          sex: "女",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 952718 弄"
        },
        {
          name: "王虎",
          sex: "男",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          name: "王老虎",
          sex: "男",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          name: "啊虎",
          sex: "男",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 1518 弄"
        }
      ],
      langs: [],
      departments: [],
      countries: [],
      StaffuserList: [
        {
          staffId: 3,
          languageId: 4,
          countryId: 3,
          departmentId: 2,
          englishName: "李",
          chineseName: "四",
          beneficiaryBirthday: "2014-11-11",
          beneficiarySex: "女",
          staffCertificateType: "身份证",
          staffCertificateNo: "4206251996",
          staffFaData: "2014-11-11",
          staffOutData: "2014-11-11",
          staffEmail: "987654@163.com",
          staffTrueEmail: "987654321@163.com",
          staffPhoneType: "移动电话",
          staffCountryCode: "02777",
          staffMobile: "18627787219",
          staffLandline: "02777117",
          staffName: "李四-尼格拉斯"
        }
      ],
      search: "",
      dialogVisible: false,
      loading: true,
      userList: [],
      query: "",
      total: 0,
      pagesize: 10,
      pagenum: 1,
      addDialogFormVisible: false,
      addForm: {
        languageId: "",
        countryId: "",
        departmentId: "",
        englishName: "",
        chineseName: "",
        beneficiaryBirthday: "",
        beneficiarySex: "",
        staffCertificateType: "",
        staffCertificateNo: "",
        staffFaData: "",
        staffOutData: "",
        staffEmail: "",
        staffTrueEmail: "",
        staffPhoneType: "",
        staffCountryCode: "",
        staffMobile: "",
        staffLandline: "",
        staffName: ""
      },

      editDialogFormVisible: false,
      editForm: {
        username: "",
        email: "",
        mobile: "",
        id: 0
      },
      grantDialogFormVisible: false,
      grantForm: {},
      roleList: [],
      roleId: "",
      // 添加用户的表单验证
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" }
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        email: [
          { required: true, message: "请输入邮箱地址", trigger: "blur" },
          {
            type: "email",
            message: "请输入正确的邮箱地址",
            trigger: "blur,change"
          }
        ],
        mobile: [{ required: true, message: "电话不能为空" }]
      }
    };
  },
  created() {
    this.initList();
  },
  mounted() {
    this.getlangs(), this.getdepartments(), this.getcountries();
  },
  methods: {
    handleEdit(index, row) {
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    handleChange(val) {
      console.log(val[0]);

      // console.log(this.addForm);
      if (val[0] === "2" && Object.values(this.addForm).includes("")) {
        this.$message({
          message: "请填写全部信息",
          type: "warning"
        });
      }
    },
    // 初始化表格数据
    initList() {
      this.loading = true;
      getStaffuserList({
        // params: {
        //   query: this.query,
        //   pagenum: this.pagenum,
        //   pagesize: this.pagesize
        // }
      }).then(res => {
        console.log(res);
        this.tableData = res;
        // this.total = res.data.total
        this.loading = false;
      });
    },
    // 添加介绍人行政人员
    addIntroducer(formName) {
      this.$refs[formName].validate(valide => {
        if (valide) {
          // 执行添加用户方法
          addStaff(this.addForm).then(res => {
            console.log(res);
            if (res.rtnCode === 1) {
              this.$message({
                type: "success",
                message: res.rtnMsg
              });
            }
            this.addDialogFormVisible = false;
            this.initList();
          });
        }
      });
    },
    closed() {
      this.activeName = "";
    },
    //获取语言选框
    getlangs() {
      getLanguage({}).then(res => {
        console.log(res);
        this.langs = res;
      });
    },

    //获取国家选框
    getcountries() {
      getCountryList({}).then(res => {
        console.log(res);
        this.countries = res;
      });
    },

    //获取部门选框
    getdepartments() {
      getDepartmentList({}).then(res => {
        console.log(res);
        this.departments = res;
      });
    },
    // 显示删除对话框
    showDeleteDialog(row) {
      this.$confirm("此操作将永久删除该用户, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // 执行删除用户操作
          deleteUser(row.id).then(res => {
            if (res.meta.status === 200) {
              this.$message({
                type: "success",
                message: "删除成功!"
              });
              this.initList();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>
<style lang="less" scoped>
.introducer {
  .add_intro {
    .el-button {
      margin-top: 12px;
    }
  }
}

.el-row {
  margin-bottom: 2px;
  &:last-child {
    margin-bottom: 0;
  }
}
.el-col {
  border-radius: 2px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 2px 0;
  background-color: #f9fafc;
}
.clause_content {
  font-weight: 500;
  text-indent: 1em;
  .el-row {
    .el-col:nth-of-type(1) {
      font-weight: 600;
    }
  }
}

.guide {
  padding-left: 20px;

  p {
    font-size: 14px;
    font-weight: 600;
    line-height: 20px;
    height: 30px;
  }
  .el-form-item {
    width: 500px;
    .el-select {
      width: 100%;
    }
  }
  .guide_confirm {
    margin-top: 15px;
    width: 100%;
    text-align: right;
    background-color: #eee;
    .el-button {
      margin-right: 20px;
    }
  }
}
</style>