<template>
  <div class="apply_clause">
    <!-- 搜素表头 -->
    <div class="mm_button">
      <el-form
        :inline="true"
        :model="formInline"
        ref="serviceForm"
        class="demo-form-inline"
        size="small"
      >
        <el-form-item prop="promakr">
          <el-select
            size="small"
            v-model="formInline.promakr"
            placeholder="产品代码"
            style="width:180px"
          >
            <el-option label="ACS5025U" value="ACS5025U"></el-option>
            <el-option label="ACS9527J" value="ACS9527J"></el-option>
            <el-option label="ACS0007C" value="ACS9527J"></el-option>
            <el-option label="ACS8887E" value="ACS8887E"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item prop="proname">
          <el-input v-model="formInline.proname" size="small" placeholder="产品名称" style="width:180px"></el-input>
        </el-form-item>

        <el-form-item prop="proseries">
          <el-select
            size="small"
            v-model="formInline.proseries"
            placeholder="产品系列"
            style="width:180px"
          >
            <el-option label="亚盛投资组合" value="亚盛投资组合"></el-option>
            <el-option label="亚盛投资基金" value="亚盛投资基金"></el-option>
            <el-option label="亚盛投资保险" value="亚盛投资保险"></el-option>
            <el-option label="亚盛投资期货" value="亚盛投资期货"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item prop="currency">
          <el-select size="small" v-model="formInline.currency" placeholder="货币" style="width:180px">
            <el-option label="人民币/CNY" value="人民币/CNY"></el-option>
            <el-option label="美元/USD" value="美元/USD"></el-option>
            <el-option label="日元/JPY" value="日元/JPY"></el-option>
            <el-option label="欧元/EUR" value="欧元/EUR"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="language">
          <el-select size="small" v-model="formInline.language" placeholder="语言" style="width:180px">
            <el-option label="中文简体" value="中文简体"></el-option>
            <el-option label="中文繁体" value="中文繁体"></el-option>
            <el-option label="日文" value="日文"></el-option>
            <el-option label="英文" value="英文"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button
            style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
            icon="el-icon-search"
            @click="onSubmit('serviceForm')"
            plain
            size="small"
          >搜索</el-button>
          <el-button
            style="backgroundColor: #656FE7;color:#fff;border-radius:8px;"
            icon="el-icon-delete"
            @click="onReset('serviceForm')"
            plain
            size="small"
          >重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 条款列表 -->
    <div>
      <el-table
        :data="tableData"
        border
        :cell-style="{'text-align':'center',}"
        :header-cell-style="headerStyle"
      >
        <el-table-column label="产品代码" sortable width="200" prop="promakr"></el-table-column>

        <el-table-column label="产品名称" sortable width="200" prop="proname"></el-table-column>

        <el-table-column label="产品系列" sortable width="200">
          <template slot-scope="scope">
            <el-popover trigger="hover" placement="top">
              <p>系列: {{ scope.row.proseries }}</p>
              <p>代码: {{ scope.row.promakr }}</p>
              <div slot="reference" class="name-wrapper">
                <el-tag size="medium">{{ scope.row.proseries }}</el-tag>
              </div>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column label="货币" sortable width="200" prop="currency"></el-table-column>
        <el-table-column label="语言" sortable width="200" prop="language"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="primary"
              icon="el-icon-edit"
              @click="handleEdit(scope.$index, scope.row)"
            >查看</el-button>
            <!-- <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button> -->
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 查看详情弹框 -->

    <el-dialog
      :visible.sync="dialogVisible"
      width="55%"
      :before-close="handleClose"
      top="10vh"
      style="boxsizing:border-box"
    >
      <div class="clause_content">
        <el-row style="font-size:18px;font-weight:600;line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">产品</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">亚盛投资组合5025</div>
          </el-col>
        </el-row>
        <el-row style="line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">产品代码：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">ACS5025E</div>
          </el-col>
        </el-row>
        <el-row style="line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">货币：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">欧元</div>
          </el-col>
        </el-row>
        <el-row style="line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">最低供款额：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">€75，000</div>
          </el-col>
        </el-row>
        <el-row style="line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">最低超额金额：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">€7，500</div>
          </el-col>
        </el-row>
        <el-row style="line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">设置费用：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">无</div>
          </el-col>
        </el-row>
        <el-row style="line-height:36px">
          <el-col :span="6">
            <div class="grid-content bg-purple">计划手续费：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light">每季€180（每年€720）。</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <div class="grid-content bg-purple" style="height:60px;line-height:36px">投资交易细节*：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light" style="height:60px;line-height:18px">
              <p>最低交易金额为€7，500。</p>
              <p>交易费每次€30。</p>
              <p>*若资产最低交易额高于产品最低交易额,将采用资产最低交易额计算。</p>
            </div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <div class="grid-content bg-purple" style="height:50px;line-height:36px">资产流动限制：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light" style="height:50px;line-height:20px">
              <p>现金账户必须保证足够的余额以支付手续费及产品整体的费用。</p>
              <p>若在任何的时候此账户的余额是负值，将采用透支利率计算利息。</p>
            </div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <div class="grid-content bg-purple" style="height:50px;line-height:36px">行政费用：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light" style="height:50px;line-height:20px">
              <p>以已支付的供款金额或账户价值为计算基础，</p>
              <p>于计划前5年每季采较高者扣取0.3625%（每年1.45%）行政费。</p>
            </div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <div class="grid-content bg-purple" style="height:120px;line-height:60px">解约费用：</div>
          </el-col>
          <el-col :span="18">
            <div class="grid-content bg-purple-light" style="height:120px ;line-height:16px">
              <p>以已支付的供款金额或账户价值为计算基础,费用采较高者扣取</p>
              <p>自初始赎回费用7.25%开始，每日降低，到第五年底为零。</p>
              <p>1年底-5.80%</p>
              <p>2年底-4.35%</p>
              <p>3年底-2.90%</p>
              <p>4年底-1.45%</p>
              <p>5年底-0.00%</p>
            </div>
          </el-col>
          <div style="margin-top:15px" class="fr">
            <el-button type="primary" size="small" @click="closed">确定</el-button>
          </div>
        </el-row>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dialogVisible: false,
      value: {},
      headerStyle: {
        "text-align": "center",
        margin: "-10px 0",
        height: "30px",
        overflow: "hidden",
        "background-color": "#ddd"
      },
      //搜索选框测试数据
      formInline: {
        promakr: "", //产品代码
        proname: "", //产品名称
        language: "", //语言
        proseries: "", //产品系列
        currency: "" //货币
      },
      tableData: [
        {
          promakr: "ACS5025E", //产品代码
          proname: "亚盛债券组合5025(欧元)", //产品名称
          language: "中文简体", //语言
          proseries: "亚盛投资组合", //产品系列
          currency: "欧元/EUR" //货币
        },
        {
          promakr: "ACS5025E", //产品代码
          proname: "亚盛债券组合5025(欧元)", //产品名称
          language: "中文繁体", //语言
          proseries: "亚盛投资组合", //产品系列
          currency: "欧元/EUR" //货币
        },
        {
          promakr: "ACS5025E", //产品代码
          proname: "亚盛债券组合5025(欧元)", //产品名称
          language: "日文", //语言
          proseries: "亚盛投资组合", //产品系列
          currency: "欧元/EUR" //货币
        },
        {
          promakr: "ACS5025E", //产品代码
          proname: "亚盛债券组合5025(欧元)", //产品名称
          language: "英文", //语言
          proseries: "亚盛投资组合", //产品系列
          currency: "欧元/EUR" //货币
        }
      ],
      idcard: [
        //查看详情数据格式
        {
          id_type: "身份证",
          id_num: "420103198909071222"
        },
        {
          id_type: "护照",
          id_num: "E02599882"
        },
        {
          id_type: "税号",
          id_num: "420103198909071222"
        }
      ]
    };
  },
  methods: {
    //表头搜索提交按钮
    onSubmit(formName) {
      console.log(this.formInline);
    },
    //表头搜索重置按钮
    onReset(formName) {
      this.$refs[formName].resetFields();
    },
    //查看详情
    handleEdit(index, row) {
      this.dialogVisible = true;
      // console.log(index, row);
    },
    //确定
    closed() {
      this.dialogVisible = false;
    },
    //删除（备用）
    handleDelete(index, row) {
      // console.log(index, row);
    },
    //弹框关闭提示
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then(_ => {
          done();
        })
        .catch(_ => {});
    }
  }
};
</script>

<style lang="less" scoped>
.apply_clause {
  .mm_button{
    .demo-form-inline{
    .el-form-item {
     margin: 8px; 
    }
  }
  }
  .search_nav {
    margin: 10px 0;
    .el-row {
      text-align: center;
      background-color: #fff;
    }
  }
  /deep/ thead {
    /deep/ tr:nth-of-type(1) {
      /deep/ .cell {
        text-align: center;
        margin: -10px 0;
        height: 40px;
        overflow: hidden;
        background-color: #ddd;
      }
    }
  }
  .el-row {
    margin-bottom: 2px;
    &:last-child {
      margin-bottom: 0;
    }
  }
  .el-col {
    border-radius: 2px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 2px 0;
    background-color: #f9fafc;
  }
  .clause_content {
    font-weight: 500;
    text-indent: 1em;
    .el-row {
      .el-col:nth-of-type(1) {
        font-weight: 600;
      }
    }
  }
}
</style>
