<template>
  <div class="service_online">
    <!-- 搜素表头 -->
    <div class="mm_button">
      <el-form
        :inline="true"
        :model="formInline"
        ref="serviceForm"
        class="demo-form-inline"
        size="small"
      >
        <el-form-item label=" 建立日期：" prop="start_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.start_value" type="date" placeholder="开始日期"></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item label="-" prop="end_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.end_value" type="date" placeholder="终止日期"></el-date-picker>
          </el-col>
        </el-form-item>
     

        <el-form-item prop="name">
          <el-input v-model="formInline.name" placeholder="由建立"></el-input>
        </el-form-item>
     
        <el-form-item prop="doc_type">
          <el-select v-model="formInline.categoryName" placeholder="投资产品">
            <el-option label="保险" value="保险"></el-option>
            <el-option label="信托" value="信托"></el-option>
            <el-option label="投顾" value="投顾"></el-option>
          
          </el-select>
        </el-form-item>
        <el-form-item prop="doc_type">
          <el-select v-model="formInline.doc_type" placeholder="状态">
            <el-option label="进行中" value="已发送"></el-option>
            <!-- <el-option label="被弃用" value="被弃用"></el-option> -->
            <el-option label="已提交" value="已提交"></el-option>
            <!-- <el-option label="期限已满" value="期限已满"></el-option> -->
          </el-select>
        </el-form-item>

       <el-form-item>
          <el-button
            style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
            icon="el-icon-search"
            @click="onSubmit('serviceForm')"
            plain
            size="small"
          >搜索</el-button>
          <el-button
            style="backgroundColor: #656FE7;color:#fff;border-radius:8px;"
            icon="el-icon-delete"
            @click="onReset('serviceForm')"
            plain
            size="small"
          >重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 记录表格 -->
    <div class="mm_table">
      <el-table
        :data="tableData"
        v-loading="loading"
        border
        style="width: 100%"
        :header-cell-style="{
        'background-color': '#DCDFE6',
        'height':'40px',
		    'text-align':'center',
         }"
        :cell-style="{'text-align':'center',}"
      >
        <el-table-column prop="createTime" label="建立日期" width="180" sortable></el-table-column>
        <el-table-column prop="memeUsers.userName" label="由建立" width="180"></el-table-column>
        <!-- <el-table-column prop="introducer" label="申请人"></el-table-column> -->
        <el-table-column prop="productCategory.categoryName" label="投资产品"></el-table-column>

        <el-table-column prop="recordStatus" sortable label="状态">
          <template slot-scope="scope">
            <el-tag
              plain
              size="mini"
              :type="scope.row.recordStatus===1 ? 'warning' : 'success'"
            >{{scope.row.recordStatus | statusFormat}}</el-tag>
          </template>
        </el-table-column>

        <!-- <el-table-column prop="status" label="最后更新时间"></el-table-column>
        <el-table-column prop="status" label="最后更新由"></el-table-column>-->
        <el-table-column prop="unread_msg" label="审查">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="primary"
              plain
              icon="el-icon-edit"
              @click="showEditDialog(scope.row)"
            >审查</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页工具 -->
      <div class="page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="1"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="10"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
        <!-- <Pagination></Pagination> -->
      </div>
    </div>

    <!-- 保险详细弹框 -->
    <el-dialog
      title="保险"
      :visible.sync="dialogVisible"
      width="80%"
      top="5vh"
      :before-close="handleClose"
    >
      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item title="审查(已提交)" name="1">
          <div class="box-card">
            <el-row :gutter="20">
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <h3>建立日期</h3>
                  <p>{{data.memeProduct?data.memeProduct.createTime:''}}</p>
                  <h3>由建立</h3>
                  <p>{{ data.memeUsers?data.memeUsers.userName:''}}</p>
                  <h3>状态</h3>
                  <p>{{data.recordStatus|statusFormat}}</p>
                  <h3>状态</h3>
                  <p>{{data.recordStatus|statusFormat}}</p>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple-light">
                  <h3>产品</h3>
                  <p>{{data.memeProduct?data.memeProduct.productName:''}}</p>
                  <h3>保险公司</h3>
                  <p>{{data.memeProduct?data.memeProduct.insuranceCompany:''}}</p>
                  <h3>年期</h3>
                  <p>{{data.memeProduct?data.memeProduct.productAnnual:''}}</p>
                  <h3>预约时间</h3>
                  <p>{{data.memeProduct?data.memeProduct.productAppointment:''}}</p>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <h3>投保人</h3>
                  <p>{{data.memeProduct?data.memeProduct.productInsured:''}}</p>
                  <h3>受保人</h3>
                  <p>{{data.memeProduct?data.memeProduct.productProtectionInsured:''}}</p>
                  <h3>是否有附加保障</h3>
                  <p>{{data.memeProduct?data.memeProduct.productAttach:''}}</p>
                  <h3>是否申请保单生效日回溯</h3>
                  <p>{{data.memeProduct?data.memeProduct.isBack:''}}</p>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <h3>缴费币种</h3>
                  <p>{{data.memeProduct?data.memeProduct.productCurrency:''}}</p>
                  <h3>缴费方式</h3>
                  <p>{{data.memeProduct?data.memeProduct.productMonner:''}}</p>
                  <h3>年保费</h3>
                  <p>{{data.memeProduct?data.memeProduct.annualPremium:''}}</p>
                  <h3>保额</h3>
                  <p>{{data.memeProduct?data.memeProduct.insuranceAmount:''}}</p>
                </div>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
      </el-collapse>

      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item title="确认资料" name="1-2">
          <div class="box-card" style="padding:20px">
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="投保人信息" name="2">
                  <el-row>
                    <el-col :span="6">
                      <h3>名字</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredNamePy.toUpperCase():''}}({{data.memeInsured?data.memeInsured.insuredName:''}})</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>性别</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredSex:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>职业</h3>
                      <p>{{data.memeInsured?data.memeInsured.jobTitle:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>国籍</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredCountry:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>教育程度</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredEducation:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>出生日期</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredBorn:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>身份证号码</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredNo:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>身份证地址</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredAddres:''}}</p>
                    </el-col>
                  </el-row>

                  <el-row>
                    <el-col :span="6">
                      <h3>护照/通行证号码</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredNumber:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>护照/通行证日期</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredTime:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>公司名称</h3>
                      <p>{{data.memeInsured?data.memeInsured.companyName:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>公司业务性质</h3>
                      <p>{{data.memeInsured?data.memeInsured.businessNature:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>职称</h3>
                      <p>{{data.memeInsured?data.memeInsured.jobTitle:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>月收入（港币）</h3>
                      <p>{{data.memeInsured?data.memeInsured.monthlyIncome:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>手机</h3>
                      <p>{{data.memeInsured?data.memeInsured.phone:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>座机</h3>
                      <p>{{data.memeInsured?data.memeInsured.landline:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>邮箱</h3>
                      <p>{{data.memeInsured?data.memeInsured.email:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>公司地址</h3>
                      <p>{{data.memeInsured?data.memeInsured.companyAddress:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>是否为美国公民或美国税务居民?</h3>
                      <p>{{data.memeInsured?data.memeInsured.isUsa:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>婚姻状况</h3>
                      <p>{{data.memeInsured?data.memeInsured.maritalStatus:''}}</p>
                    </el-col>
                  </el-row>

                  <el-row>
                    <el-col :span="6">
                      <h3>眷属数目</h3>
                      <p>{{data.memeInsured?data.memeInsured.genusNumber:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>身高(单位cm)</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredHeight:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>体重(单位kg)</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredWeight:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>通讯地址(合同邮寄地址)</h3>
                      <p>{{data.memeInsured?data.memeInsured.insuredRelationship:''}}</p>
                    </el-col>
                  </el-row>

                  <el-row>
                    <el-col :span="6">
                      <h3>是否以身份证地址为地址证明</h3>
                      <p>{{data.memeInsured?data.memeInsured.isCar:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>赴港联系人</h3>
                      <p>{{data.memeInsured?data.memeInsured.personHk:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>赴港联系人电话</h3>
                      <p>{{data.memeInsured?data.memeInsured.personHkPhone:''}}</p>
                    </el-col>
                  </el-row>

                  <el-row>
                    <el-col :span="24">
                      <h3>其他人资讯</h3>
                      <p>请问您目前或是否曾被政府、国家、或国际组织的相关机构委任某些重要的公职，如国家元首或政府首脑、资深或具有影响力的政治家、政府高级人员、司法或军事官员、或国有企业的高级管理人员？</p>
                      <p>或者您是否与此类的政治敏感身份者拥有密切的关系或是其直系亲属？</p>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="受保人信息" name="3">
                  <el-row>
                    <el-col :span="6">
                      <h3>受保人（中文）</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredName:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>受保人（拼音）</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredNamePy:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>国籍</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredCountry:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>教育程度</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredEducation:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>身份证号</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredNo:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>身份证地址</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredAddres:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>护照/通行证号码</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredNumber:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>护照/通行证日期</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredNumber:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>公司名称</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.companyName:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>公司业务性质</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.businessNature:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>职称</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.jobTitle:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>月收入(港币)</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.monthlyIncome:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>手机</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.phone:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>座机</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.landline:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>邮箱</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.email:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>公司地址</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.companyAddress:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>是否为美国公民或美国税务居民?</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.isUsa:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>婚姻状况</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.maritalStatus:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>眷属数目</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.genusNumber:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>身高(单位cm)</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredHeight:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>体重(单位kg)</h3>
                      <p>{{data.memeInsuredS?data.memeInsuredS.insuredWeight:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>受保人与投保人关系</h3>
                      <p>{{data.memeInsuredS?(data.memeInsuredS.relationship?data.memeInsuredS.relationship:'少字段'):''}}</p>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="财务资料信息分析声明" name="4">
                  <el-row>
                    <el-col :span="6">
                      <h3>首期供款方式</h3>
                      <p>{{data.memeFinance?data.memeFinance.paymentMethod:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>续期缴费方式</h3>
                      <p>{{data.memeFinance?data.memeFinance.renewalMethod:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>个人资金来源</h3>
                      <p>{{data.memeFinance?data.memeFinance.sourcesFunds:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>在香港投保原因</h3>
                      <p>{{data.memeFinance?data.memeFinance.insuredReason:''}}</p>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6">
                      <h3>平均每月支出</h3>
                      <p>{{data.memeFinance?data.memeFinance.monthlyExpenditure:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>现时持有流动资产</h3>
                      <p>{{data.memeFinance?data.memeFinance.currentAssets:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>不动资产的总值(约)</h3>
                      <p>{{data.memeFinance?data.memeFinance.totalAssets:''}}</p>
                    </el-col>
                    <el-col :span="6">
                      <h3>保费收入占比</h3>
                      <p>20%</p>
                    </el-col>
                  </el-row>

                  <el-row>
                    <el-col :span="6">
                      <h3>现时负债</h3>
                      <p>{{data.memeFinance?data.memeFinance.debtApproximately:''}}</p>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="受益人资料" name="5">
                  <!-- 1 -->
                  <p class="beneficiary">受益人1</p>
                  <el-row>
                    <el-col :span="4">
                      <h3>姓名</h3>
                      <p>{{memeApplyEneficiary1[0]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>英文名</h3>
                      <p>{{memeApplyEneficiary1[1]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>年龄</h3>
                      <p>{{memeApplyEneficiary1[2]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>身份证号码</h3>
                      <p>{{memeApplyEneficiary1[3]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>与受保人关系</h3>
                      <p>{{memeApplyEneficiary1[4]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>受益比例</h3>
                      <p>{{memeApplyEneficiary1[5]}}</p>
                    </el-col>
                  </el-row>
                  <p class="beneficiary">受益人2</p>
                  <!-- 2 -->
                  <el-row>
                    <el-col :span="4">
                      <h3>姓名</h3>
                      <p>{{memeApplyEneficiary2[0]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>英文名</h3>
                      <p>{{memeApplyEneficiary2[1]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>年龄</h3>
                      <p>{{memeApplyEneficiary2[2]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>身份证号码</h3>
                      <p>{{memeApplyEneficiary2[3]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>与受保人关系</h3>
                      <p>{{memeApplyEneficiary2[4]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>受益比例</h3>
                      <p>{{memeApplyEneficiary2[5]}}</p>
                    </el-col>
                  </el-row>
                  <p class="beneficiary">受益人3</p>
                  <!-- 3 -->
                  <el-row>
                    <el-col :span="4">
                      <h3>姓名</h3>
                      <p>{{memeApplyEneficiary1[0]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>英文名</h3>
                      <p>{{memeApplyEneficiary2[1]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>年龄</h3>
                      <p>{{memeApplyEneficiary3[2]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>身份证号码</h3>
                      <p>{{memeApplyEneficiary3[3]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>与受保人关系</h3>
                      <p>{{memeApplyEneficiary3[4]}}</p>
                    </el-col>
                    <el-col :span="4">
                      <h3>受益比例</h3>
                      <p>{{memeApplyEneficiary3[5]}}</p>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="个人产品资料声明" name="6">
                  <el-row>
                    <el-col :span="24">
                      <p>1.在过去投购人寿、伤病、医疗或其 他保险时，又或在要求恢复该类保单效力时，曾否遭拒绝、延期、加费或 接受更改受保条件？</p>
                      <h5>{{data.memeProductInformation?data.memeProductInformation.oneTxt:''}}</h5>
                      <p>2. 曾否因意外、伤病或健康理由而申请社会福利或保险赔偿？</p>
                      <h5>{{data.memeProductInformation?data.memeProductInformation.twoTxt:''}}</h5>
                      <p>3. 是否有现行生效（包括在申请中）之 保险保障？（如有，需补充签发日期-保单号-投保人-受保人以及当时填写的财务信息）</p>
                      <h5>{{data.memeProductInformation?data.memeProductInformation.threeTxt:''}}</h5>
                      <p>4. 是否设第二持有人（如有，需补充姓名-英文姓名/拼音-年龄-身份证 号-与受保人关系）</p>
                      <h5>{{data.memeProductInformation?data.memeProductInformation.fourTxt:''}}</h5>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="个人生活习惯声明" name="7">
                  <el-row>
                    <el-col :span="24">
                      <p>1.是否吸烟（投保人、受保人。如 填写“是”，请写明每天吸烟几支，吸烟几年。如已戒烟，请写明某年某月某日戒烟，戒烟原因。）</p>
                      <h5>{{data.memeLivingHabit?data.memeLivingHabit.oneTxt:''}}</h5>
                      <p>2. 是否饮酒（投保人、受保人。如 “是”，则写明饮用的酒精种类，及每周的饮用量。）</p>
                      <h5>{{data.memeLivingHabit?data.memeLivingHabit.twoTxt:''}}</h5>
                      <p>3. 是否曾惯性使用药物或麻醉剂？（如“是”，则写明服用的药物种类，及用量。）</p>
                      <h5>{{data.memeLivingHabit?data.memeLivingHabit.threeTxt:''}}</h5>
                      <p>4.是否参与或计划参与任何工作或娱乐有关之危险性活动？（如潜水、爬山、赛车或飞行等，不包括以乘客身份搭乘商业性民航客机）</p>
                      <h5>{{data.memeLivingHabit?data.memeLivingHabit.fourTxt:''}}</h5>
                      <p>5.是否于过去十二个月内在中国以外居留超过六个月？（如“是”则请写明逗留哪个国家、城市，逗留时间、原因。）</p>
                      <h5>{{data.memeLivingHabit?data.memeLivingHabit.fivesTxt:''}}</h5>
                      <p>6.体重过去一年内是否增减？（如“是”，则写明体重增减多少kg及原因。）</p>
                      <h5>{{data.memeLivingHabit?data.memeLivingHabit.sixTxt:''}}</h5>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>
            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="个人健康声明" name="8">
                  <p>个人健康声明 （如有，则须写明“病发日记及次数-最后病发日期-受影响之关节-接受何种治疗/药物或改变饮食习惯-有否出现并发症-有否需要定期复诊-就诊医生姓名及地址”并附上病历本。）</p>
                  <el-row utter="20">
                    <el-col :span="12" style="padding-right:8px">
                      <p>1.任何缺陷、断肢、先天及/或后天的 身体缺损？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.oneTxt:''}}</h5>
                      <p>2.糖尿病、甲状腺或其他内泌失调？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.twoTxt:''}}</h5>
                      <p>3.哮喘、肺炎、肺结核或呼吸系统 疾病？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.threeTxt:''}}</h5>
                      <p>4.胸痛、心悸、心脏血管或循环系统 疾病？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.fourTxt:''}}</h5>
                      <p>5.肝炎或带菌、胆囊、胆管及其他肝 脏之疾病/功能失常？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.fivesTxt:''}}</h5>
                      <p>6.神经炎、关节炎、痛风症、脊柱裂、 其他肢体关节、脊柱或肌肉骨骼疾病？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.fivesTxt:''}}</h5>
                      <p>7.任何种类之贫血症或血友病或其他 有关血液之疾病？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.sevenTxt:''}}</h5>
                      <p>8.过去三个月内有否连续一星期以上 出现疲倦、体重下降、腹泻、淋巴肿大或不正常的皮肤破损？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.eightTxt:''}}</h5>
                      <p>9.您有否因上述疾病及/或意外而正 在接受诊治或药物治疗？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.nineTxt:''}}</h5>
                      <p>10.您的父母、兄弟姊妹或子女曾否 被诊断患有及/或接受治疗心脏疾病、中风、高血压、糖尿病、肝病、肾病、精神病、肿瘤或癌症、唐氏综合症、脊柱裂、系统性红斑狼疮、先天的身体缺损或任何遗传疾病？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenTxt:''}}</h5>
                      <p>11.曾否或将会接受唐氏综合症的测试？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenOneTxt:''}}</h5>
                      <p>12.在过去十年内，您曾否在怀孕期间患有并发症(例如：宫外孕、弥漫性血管内凝血、糖尿病或高血压等)？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenTwoTxt:''}}</h5>
                      <p>13.在过去五年内，您曾否因任何肿瘤 或癌症、心血管及循环系统、中风、肝、肾或神经系统的疾病而接受或被建议接受住院观察、外科手术或治疗？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenThreeTxt:''}}</h5>
                    </el-col>
                    <el-col :span="12" style="padding-left:8px">
                      <p>14.大脑性痲痹、癫痫症、中风、抑郁或其他精神失常？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenFourTxt:''}}</h5>
                      <p>15.眼睛、鼻、喉或耳朵之疾病/功能 失常？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenFivesTxt:''}}</h5>
                      <p>16.血脂高或高血压？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenFivesTxt:''}}</h5>
                      <p>17.溃疡、疝气、痔瘘、肠胃不适或消化系统疾病？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenSevenTxt:''}}</h5>
                      <p>18.肾脏、膀胱、前列腺或生殖系统之 疾病/功能失常或结石？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.oneTxt:''}}</h5>
                      <p>19.任何囊肿、肿瘤或癌症？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenEightTxt:''}}</h5>
                      <p>20.您曾否接受或有意接受艾滋病或此 病症有关或任何经性接触传染之疾病的医药建议、辅导或治疗？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenNineTxt:''}}</h5>
                      <p>21.您曾否患有任何上文未有提及的心 理或生理疾病、手术或意外？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tenTenTxt:''}}</h5>
                      <p>22.在过去五年内您曾否接受X光、超 声波检查、磁力共振、计算机扫描、细胞组织化验、心电图、血液或小便检查</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tensOneTxt:''}}</h5>
                      <p>23.您现在是否怀孕？(只限女性填写）</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tensTwoTxt:''}}</h5>
                      <p>24.您曾否因为妇科问题而看医生，例如：于两次经期间之出血、盆腔炎疾病、子宫颈部或乳房异常？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tensThreeTxt:''}}</h5>
                      <p>25.您曾否接受或被建议接受或打算接 受乳房X光像、乳房或盆腔超声波检查、子宫颈细胞涂片检查、锥形切片检查或阴道镜检查？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tensFourTxt:''}}</h5>
                      <p>26.您是否于过去12个月内（或者计划 未来12个月内）以这份投保申请书取代您任何现有寿险保单，或取代任何现有寿险内大部分的寿险成份？</p>
                      <h5>{{data.memeHealthStatement?data.memeHealthStatement.tensFivesTxt:''}}</h5>
                    </el-col>
                  </el-row>
                </el-collapse-item>
              </el-collapse>
            </div>

            <div class="box-items">
              <el-collapse v-model="activeNames" @change="handleChange">
                <el-collapse-item title="上传材料" name="9">
                  <el-row>
                    <el-col
                      :span="24"
                    >一旦公司收到您的协议/申请书，所有的资讯及相关文件将会被审核。公司会与您的办事处及直属主管以要求任何缺少、不完整或额外（若需要）、以及需要更正的资讯或文件。</el-col>
                  </el-row>

                  <div>
                    <h3>身份证明（正/反面）</h3>
                    <ul>
                      <li>{{data.memeAnnex?data.memeAnnex.idCardFront:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.idCardSide:''}}</li>
                    </ul>
                  </div>
                  <div>
                    <h3>港澳通行证/护照（正/反面）</h3>
                    <ul>
                      <li>{{data.memeAnnex?data.memeAnnex.hkCardFront:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.hkCardSide:''}}</li>
                    </ul>
                  </div>
                  <div>
                    <h3>户口文件</h3>
                    <ul>
                      <li>{{data.memeAnnex?data.memeAnnex.accountOne:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.accountTwo:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.accountThree:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.accountFour:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.accountFives:''}}</li>
                    </ul>
                  </div>
                  <div>
                    <h3>出生证</h3>
                    <ul>
                      <li>{{data.memeAnnex?data.memeAnnex.birthCertificate:''}}</li>
                    </ul>
                  </div>
                  <div>
                    <h3>住址文件</h3>
                    <ul>
                      <li>{{data.memeAnnex?data.memeAnnex.addresPg:''}}</li>
                    </ul>
                  </div>
                  <div>
                    <h3>其他</h3>
                    <ul>
                      <li>{{data.memeAnnex?data.memeAnnex.attachmentsOne:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.attachmentsTwo:''}}</li>
                      <li>{{data.memeAnnex?data.memeAnnex.attachmentsThree:''}}</li>
                    </ul>
                  </div>
                </el-collapse-item>
              </el-collapse>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false" size="small">返 回</el-button>
        <el-button type="primary" @click="dialogVisible = false" size="small">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 投顾详细弹框 -->
    <el-dialog
      title="投顾"
      :visible.sync="dialogInvestVisible"
      width="80%"
      top="5vh"
      :before-close="handleClose"
    >
      <div class="invest">暂无投顾数据</div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogInvestVisible = false" size="small">返 回</el-button>
        <el-button type="primary" @click="dialogInvestVisible = false" size="small">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 信托详细弹框 -->
    <el-dialog
      title="信托"
      :visible.sync="dialogTrustVisible"
      width="80%"
      top="5vh"
      :before-close="handleClose"
    >
      <div class="trust">暂无信托数据</div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogTrustVisible = false" size="small">返 回</el-button>
        <el-button type="primary" @click="dialogTrustVisible = false" size="small">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getRecord, getRecordInfo, addAnnexdetail } from "@/api/applyOnline"; //api

import Pagination from "@/components/pagination.vue"; //分页器组件

export default {
  components: {
    Pagination
  },

  data() {
    return {
      loading: true,
      activeNames: ["1"],
      dialogVisible: false,
      dialogInvestVisible: false, //投顾
      dialogTrustVisible: false, //信托
      pageSize: 10, //每页显示数量
      pageNum: 1, //页数
      total: 0, //总条数
      tableData: [
        {
          applicationNumber: "", //申请编号
          categoryId: "", //产品id3
          createTime: "", //创建时间1
          lastUser: "", //最后由谁更新
          memeAnnex: "",
          memeApplyEneficiary: "",
          memeFinance: "",
          memeHealthStatement: "",
          memeInsured: "",
          memeInsuredS: "",
          memeLivingHabit: "",
          memeProduct: "",
          memeProductInformation: "",
          recordApplicant: "", //申请人2
          recordId: "", //记录id
          recordStatus: 1, //状态4
          updateTime: "", //最后编辑时间
          userId: "" //用户id
        },
        {
          ref_num: "yy952766",
          name: "王小龙",
          introducer: "德贤",
          doc_type: "类型2",
          last_update: "2020-03-03",
          status: "已回复",
          unread_msg: "未读消息1"
        }
      ],
      //搜索选框测试数据
      formInline: {
        start_value: "", //邀请开始日期
        end_value: "", //终止日期
        name: "", //由建立
       
        categoryName: "", //投资产品
       
        doc_type: "" //状态
      },
      data: "",
      memeAnnex: {},
      memeApplyEneficiary1: [],
      memeApplyEneficiary2: [],
      memeApplyEneficiary3: [],
      memeFinance: {},
      memeHealthStatement: {},
      memeInsured: {},
      memeInsuredS: {},
      memeLivingHabit: {},
      memeProduct: {},
      memeProductInformation: {},
      memeUsers: {},
      productCategory: {}, //产品属性
      recordStatus: "" //状态
    };
  },
  created() {
    this.initList();
  },
  filters: {
    statusFormat(row) {
      return row === 1 ? "进行中" : "已提交";
    }
  },

  methods: {
   //表头搜索提交按钮
    onSubmit(formName) {
      console.log( this.formInline)
    },
    //表头搜索重置按钮
    onReset(formName) {
      this.$refs[formName].resetFields();
    },

    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.pageSize = val;
      // this.pageNum = 1;
      this.initList();
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.pageNum = val;
      this.initList();
    },
    // 初始化表格数据
    initList() {
      this.loading = true;

      getRecord({
        userID: 1,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
       
        this.tableData = res.dataList;
        this.pageSize = res.myPageInfo.pageSize; //每页显示数量
        this.pageNum = res.myPageInfo.currentPage; //页数
        this.total = res.myPageInfo.total; //总条数
        this.loading = false;
      });
    },

    handleChange(val) {
      console.log(val);
    },
    resetDateFilter() {
      this.$refs.filterTable.clearFilter("date");
    },
    clearFilter() {
      this.$refs.filterTable.clearFilter();
    },
    startFilter() {},
    formatter(row, column) {
      return row.address;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },

    //审查按钮
    showEditDialog(row) {
      console.log(row.productCategory.categoryId);
      if (row.productCategory.categoryId == 1) {
        getRecordInfo({ recordID: row.recordId }).then(res => {
          console.log(res);
          this.data = res.data;
          // const node = {
          //   loc: {
          //     start: {
          //       line: 1,
          //       column: 5
          //     }
          //   }
          // };
          // let {
          //   loc,
          //   loc: { start },
          //   loc: {
          //     start: { line }
          //   }
          // } = node;
          // line; // 1
          // loc; // Object {start: Object}
          // start; // Object {line: 1, column: 5}

          let {
            memeAnnex,
            memeApplyEneficiary,
            memeFinance,
            memeHealthStatement,
            memeInsured,
            memeInsuredS,
            memeLivingHabit,
            memeProduct,
            memeProductInformation,
            memeUsers,
            productCategory
          } = res.data;

          // console.log(memeApplyEneficiary);
          this.memeApplyEneficiary1 = memeApplyEneficiary.oneInfo.split("-");
          this.memeApplyEneficiary2 = memeApplyEneficiary.twoInfo.split("-");
          this.memeApplyEneficiary3 = memeApplyEneficiary.threeInfo.split("-");
          this.memeUsers = memeUsers; //由建立字段
          this.recordStatus = res.recordStatus; //状态
          this.productCategory = productCategory; //产品属性
        });

        this.dialogVisible = true;
      } else if (row.productCategory.categoryId == 2) {
        this.dialogInvestVisible = true; //投顾
      } else if (row.productCategory.categoryId == 3) {
        this.dialogTrustVisible = true; //投顾
      }

      // this.dialogVisible = true;
    },
    formatter(row, column) {
      return row.address;
    },
    handleClose() {
      this.dialogVisible = false;
      this.dialogInvestVisible = false;
      this.dialogTrustVisible = false;
    }
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
   
  }
  .mm_table {
    margin-top: 10px;
  }
  .demo-form-inline{
    .el-form-item {
      .el-input {
        width: 150px;
      }
    }
  }
  .box-card {
    background-color: #fff;

    padding: 8px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    border: 1px solid #ebeef5;
    .el-col {
      margin-bottom: 8px;
      h3 {
        font-weight: 600;
      }
      p {
        text-indent: 0.5em;
        color: dimgrey;
      }
      h5 {
        text-indent: 1em;
      }
    }

    .box-items {
      margin-bottom: 10px;
    }
    .bg-purple {
      background: #d3dce6;
    }
    .bg-purple-light {
      background: #e5e9f2;
    }
    .grid-content {
      border-radius: 4px;
      min-height: 36px;
      p {
        margin-bottom: 5px;
      }
    }
  }
}
.beneficiary {
  font-size: 16px;
  color: dimgrey;
  background-color: #eee;
}
.box-shadow-test {
  height: 100px;
  width: 100px;
  margin: 100px auto;
  transform: rotate(45deg);
  border-radius: 100px 0 0 0;
  box-shadow:
  /*参数依次为：颜色、水平阴影位置、垂直阴影位置、模糊距离、阴影大小*/ #f44336 -2px -2px
      0 1px,
    #ff9800 -4px -4px 0 3px, #ffeb3b -6px -6px 0 5px, #8bc34a -8px -8px 0 7px,
    #00bcd4 -10px -10px 0 9px, #2196f3 -12px -12px 0 11px,
    #9c27b0 -14px -14px 0 13px;
}
</style>
