<template>
  <div class="commission_from">
    <div class="items one">
      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item title=" 合约总览" name="1">
          <el-row>
            <el-col :span="12">
              <div class="grid-content bg-purple">
                <h3>状态</h3>
                <p>执行中</p>
              </div>
            </el-col>
            <el-col :span="12">
              <div class="grid-content bg-purple-light">
                <h3>生效日期</h3>
                <p>2018-08-08</p>
              </div>
            </el-col>
          </el-row>
        </el-collapse-item>
      </el-collapse>
    </div>

    <div class="items two">
      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item title="  合约内容" name="2">
          <el-table
            :data="contract"
            border
            style="width: 100%"
            :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'center',
     }"
            :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    }"
          >
            <el-table-column prop="insuranceCompany" label="直属主管"></el-table-column>
            <el-table-column prop="plan_times" label="生效日期"></el-table-column>
            <el-table-column prop="recordStatus2" label="佣金合约"></el-table-column>
          </el-table>
        </el-collapse-item>
      </el-collapse>
    </div>
    <!-- 第三 -->
    <div class="items three">
      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item title=" 佣金比率" name="3">
          <el-table
            :data="tableData"
            border
            style="width: 100%"
            :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'center',
     }"
            :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    }"
          >
            <el-table-column prop="applicationNumber" label=" 计划种类" width="220" sortable>
              <template slot-scope="scope">
                <el-button
                  @click.prevent="messageDetail(scope.row)"
                  type="text"
                  size="small"
                >{{scope.row.applicationNumber}}</el-button>
              </template>
            </el-table-column>

            <el-table-column prop="insuranceCompany" label="第一年" width="180"></el-table-column>
            <el-table-column prop="plan_times" label="第二年"></el-table-column>
            <el-table-column prop="recordStatus2" label="第三年"></el-table-column>
            <el-table-column prop="createTime" sortable label="第四年"></el-table-column>
            <el-table-column prop="annualPremium" label="第五年"></el-table-column>
           
          </el-table>
        </el-collapse-item>
      </el-collapse>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [
        {
          date: "2016-05-02",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "打开"
        },
        {
          date: "2016-05-01",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "关闭"
        },
        {
          date: "2016-06-02",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "打开"
        },
        {
          date: "2016-07-02",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "关闭"
        }
      ],
      contract:{},
      start_value: "",
      end_value: "",
      activeNames: ["1"]
    };
  },
  methods: {
    handleChange(val) {
      console.log(val);
    }
  }
};
</script>
<style lang="less" scoped>
.commission_from {
  width: 99%;

  background-color: #fff;
  padding: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  border: 1px solid #ebeef5;

  .items {
    width: 100%;

    background-color: #ccc;
    margin: 5px 0 10px 0;
  }
}
</style>
