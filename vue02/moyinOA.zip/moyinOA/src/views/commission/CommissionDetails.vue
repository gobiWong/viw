<template>
  <div class="service_online">
    <!-- 搜素表头 -->
    <div class="mm_button">
      <el-form
        :inline="true"
        :model="formInline"
        ref="serviceForm"
        class="demo-form-inline"
        size="small"
      >
        <el-form-item label=" 交易日期" prop="start_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.start_value" type="date" placeholder="开始日期"></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item label="-" prop="end_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.end_value" type="date" placeholder="终止日期"></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item prop="name">
          <el-input v-model="formInline.name" placeholder="介绍人"></el-input>
        </el-form-item>
        <el-form-item prop="introducer">
          <el-input v-model="formInline.introducer" placeholder="申请编号"></el-input>
        </el-form-item>
        <el-form-item prop="doc_type">
          <el-input v-model="formInline.doc_type" placeholder="产品"></el-input>
        </el-form-item>

        <el-form-item prop="status">
          <el-input v-model="formInline.status" placeholder="供款额"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button
            style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
            icon="el-icon-search"
            @click="onSubmit('serviceForm')"
            plain
            size="small"
          >搜索</el-button>
          <el-button
            style="backgroundColor: #656FE7;color:#fff;border-radius:8px;"
            icon="el-icon-delete"
            @click="onReset('serviceForm')"
            plain
            size="small"
          >重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="mm_table">
      <el-table
        :data="dataList"
        border
        style="width: 100%"
        :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'30px',
		'text-align':'center',
     }"
        :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    }"
      >
        <el-table-column prop="dealTime" label="交易日期" width="180" sortable></el-table-column>
        <!-- <el-table-column prop="name" label="交易种类" width="180"></el-table-column> -->
        <el-table-column prop="memeUsers.userName" label="介绍人"></el-table-column>
        <el-table-column prop="applicationNumber" label="申请编号"></el-table-column>

        <el-table-column prop="memeProduct.insuranceCompany" sortable label="产品"></el-table-column>
        <el-table-column prop="memeProduct.annualPremium" label="供款额"></el-table-column>
        <!-- <el-table-column prop="unread_msg" label="佣金比例"></el-table-column> -->
        <el-table-column prop="commissionMoney" label="佣金额"></el-table-column>
      </el-table>
      <!-- 分页工具 -->
      <div class="page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="1"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="10"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { getCommissionlist } from "@/api/commission";
export default {
  data() {
    return {
      // loading: true,
      pageSize: 10, //每页显示数量
      pageNum: 1, //页数
      total: 0, //总条数
      dataList: [
        {
          ref_num: "yy9527",
          name: "王小虎",
          introducer: "金沙",
          doc_type: "类型1",
          last_update: "2020-02-02",
          status: "已读",
          unread_msg: "未读消息"
        },
        {
          ref_num: "yy952766",
          name: "王小龙",
          introducer: "德贤",
          doc_type: "类型2",
          last_update: "2020-03-03",
          status: "已回复",
          unread_msg: "未读消息1"
        }
      ],
      //搜索选框测试数据
      formInline: {
        start_value: "", //邀请开始日期
        end_value: "", //终止日期
        name: "", //邀请人
        introducer: "", //受邀人
        status: "", //最后更新人
        start_update: "", //最后更新时间
        end_update: "", //最后更新时间
        doc_type: "" //状态
      },
      value: "",
      input: ""
    };
  },
  created() {
    this.initList();
  },


  methods: {
    //表头搜索提交按钮
    onSubmit(formName) {},
    //表头搜索重置按钮
    onReset(formName) {
      this.$refs[formName].resetFields();
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.pageSize = val;
      // this.pageNum = 1;
      this.initList();
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.pageNum = val;
      this.initList();
    },

    initList() {
      getCommissionlist({
        userId: 1,
       introduceId: parseInt(window.localStorage.getItem("IntroducerId")),
        productId: 1,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
        // console.log(res);
        this.dataList = res.dataList;

        this.pageSize = res.myPageInfo.pageSize; //每页显示数量
        this.pageNum = res.myPageInfo.currentPage; //页数
        this.total = res.myPageInfo.total;
      });
    },
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    .el-form-item {
      .el-input {
        width: 160px;
      }
    }
  }
  .mm_table {
    margin-top: 10px;
  }
}
</style>
