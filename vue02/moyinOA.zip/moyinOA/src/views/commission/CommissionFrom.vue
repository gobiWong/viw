<template>
  <div class="commission_from">
    <div class="search">
      <el-form
        :inline="true"
        :model="formInline"
        ref="searchDatabaseForm"
        class="demo-form-inline"
        size="small"
      >
        <el-form-item label=" 起" prop="start_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.start_value" type="date" placeholder="开始日期"></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item label="至 " prop="end_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.end_value" type="date" placeholder="终止日期"></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item>
          <el-button
            style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
            @click="onSubmit('searchDatabaseForm')"
            plain
            icon="el-icon-search"
            size="small"
          >搜索</el-button>
          <el-button
            style="backgroundColor: #656FE7;color:#fff;border-radius:8px;"
            @click="onReset('searchDatabaseForm')"
            plain
             icon="el-icon-delete"
            size="small"
          >重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="items">
      <el-table
        :data="tableData"
        stripe
        style="width: 100%"
        border
        :header-cell-style="{'background-color': '#DCDFE6', 'height':'40px','text-align':'center', }"
        :cell-style="{	'text-align': 'center',}"
      >
        <el-table-column type="expand">
          <template slot-scope="props">
            <el-row>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>交易日期</h3>
                  <p>{{ props.row.deal_data }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>交易种类</h3>
                  <p>{{ props.row.deal_type }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>个人介绍人</h3>
                  <p>{{ props.row.introducer }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>计划号码</h3>
                  <p>{{ props.row.plan_num }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>细节</h3>
                  <p>{{ props.row.detail }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>产品代码</h3>
                  <p>{{ props.row.pro_code }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>货币</h3>
                  <p>{{ props.row.money }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>期间</h3>
                  <p>{{ props.row.data_data }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>供款额</h3>
                  <p>{{ props.row.apply_quota }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>佣金比例</h3>
                  <p>{{ props.row.commission_percent }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>分配比例</h3>
                  <p>{{ props.row.distribution_percent }}</p>
                </div>
              </el-col>
              <el-col :span="2">
                <div class="grid-content">
                  <h3>佣金额</h3>
                  <p>{{ props.row.quota }}</p>
                </div>
              </el-col>
            </el-row>
          </template>
        </el-table-column>
        <el-table-column prop="date" label="报表日期" width="180"></el-table-column>

        <!-- <el-table-column prop="money" label="货币" width="180"></el-table-column> -->
        <el-table-column prop="last_balance" label="上次已结"></el-table-column>
        <el-table-column prop="quota" label="佣金额" width="180"></el-table-column>
        <!-- <el-table-column prop="adjust" label="调整" width="180"></el-table-column> -->
        <el-table-column prop="summary" label="累计佣金"></el-table-column>
        <!-- <el-table-column prop="current_balance" label="此期结余"></el-table-column>
        <el-table-column prop="status" label="状态"></el-table-column> -->
      </el-table>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [
        {
          date: "2016-05-02", //报表日期
          money: "人民币", //货币
          last_balance: "33.33", //上次结余
          quota: "33.33", //佣金额
          adjust: "0.00", //调整
          summary: "0.00", //佣金总额
          current_balance: "66.66", //此期结余
          status: "打开", //状态

          deal_data: "2016-05-01", //交易日期
          deal_type: "佣金", //交易种类
          introducer: "543658-Shi Liu", //个人介绍人
          plan_num: "TDFDGRH258", //计划号码
          detail: "WONGNAN", //细节
          pro_code: "SPX15-X", //产品代码
          data_data: "1", //期间
          apply_quota: "833.33", //供款额
          commission_percent: "833.33", //佣金比例
          distribution_percent: "833.33" //分配比例
        },
        {
          date: "2016-05-01",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "关闭"
        },
        {
          date: "2016-06-02",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "打开"
        },
        {
          date: "2016-07-02",
          money: "人民币",
          last_balance: "33.33",
          quota: "33.33",
          adjust: "0.00",
          summary: "0.00",
          current_balance: "66.66",
          status: "关闭"
        }
      ],
      start_value: "",
      end_value: "",
      //搜索选框测试数据
      formInline: {
        start_value: "", //邀请开始日期
        end_value: "" //终止日期
      }
    };
  },
  methods: {
    //表头搜索提交按钮
    onSubmit(formName) {
      console.log(this.formInline);
    },
    //表头搜索重置按钮
    onReset(formName) {
      this.$refs[formName].resetFields();
    }
  }
};
</script>
<style lang="less" scoped>
.commission_from {
  .search {
    box-sizing: border-box;
    padding-bottom: 10px;
    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    span {
      padding-right: 10px;
    }
    .el-button {
      margin-left: 10px;
    }
    .demo-form-inline{
      .el-form-item {
      .el-input {
        width: 160px;
      }
    }
    }
  }
  .grid-content {
    text-align: center;
    h3 {
      line-height: 26px;
      font-weight: 600;
    }
    p {
      line-height: 26px;
    }
  }
}
</style>
