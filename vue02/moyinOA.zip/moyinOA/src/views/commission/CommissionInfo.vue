<template>
  <div class="comm_info">
    <el-card class="box-card" v-loading="loading">
      <!-- 周期 -->
      <el-row>
        <el-col :span="8">
          <div class="grid-content">周期</div>
        </el-col>
        <el-col :span="16">
          <div class="grid-content">
            <span
              class="el-dropdown-link"
              v-if="!showPeriod"
              @click="updatePeriod"
            >{{commissionInfoData?commissionInfoData.period:'undefined'| PERIOD}}</span>
            <el-select
              v-model="periodValue"
              style="width:100px"
              size="small"
              v-if="showPeriod"
              placeholder="请选择"
            >
              <el-option
                v-for="item in Period"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
            <span v-if="showPeriod">
              <el-button
                type="success"
                size="mini"
                @click="confirmPeriod"
                icon="el-icon-check"
                circle
              ></el-button>
              <el-button
                type="danger"
                size="mini"
                icon="el-icon-delete"
                @click="cancelPeriod"
                circle
              ></el-button>
            </span>
          </div>
        </el-col>
      </el-row>
      <!-- 支付方式 -->
      <el-row>
        <el-col :span="8">
          <div class="grid-content">支付方式</div>
        </el-col>
        <el-col :span="16">
          <div class="grid-content">电汇</div>
        </el-col>
      </el-row>
      <!-- 支付币种 -->
      <el-row>
        <el-col :span="8">
          <div class="grid-content">支付币值</div>
        </el-col>
        <el-col :span="16">
          <div class="grid-content">
            <span
              class="el-dropdown-link"
              v-if="!showCurrency"
              @click="updateCurrency"
            >{{commissionInfoData?commissionInfoData.currency:'undefined' | CURRENCY}}</span>
            <el-select
              v-model="currencyValue"
              style="width:100px"
              size="small"
              v-if="showCurrency"
              placeholder="请选择"
            >
              <el-option
                v-for="item in Currency"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
            <span v-if="showCurrency">
              <el-button
                type="success"
                size="mini"
                @click="confirmCurrency"
                icon="el-icon-check"
                circle
              ></el-button>
              <el-button
                type="danger"
                size="mini"
                icon="el-icon-delete"
                @click="cancelCurrency"
                circle
              ></el-button>
            </span>
          </div>
        </el-col>
      </el-row>
      <!-- 最低支付数额 -->
      <el-row>
        <el-col :span="8">
          <div class="grid-content">最低支付数额</div>
        </el-col>
        <el-col :span="16">
          <div class="grid-content">
            <span
              class="el-dropdown-link"
              v-if="!showAmount"
              @click="updateAmount"
            >{{commissionInfoData?commissionInfoData.minimum_amount:'undefined'}}</span>
            <el-input
              style="width:100px"
              size="small"
              v-model="amountValue"
              v-if="showAmount"
              placeholder="请输入内容"
            ></el-input>
            <span v-if="showAmount">
              <el-button
                type="success"
                size="mini"
                icon="el-icon-check"
                @click="confirmAmount"
                circle
              ></el-button>
              <el-button
                type="danger"
                size="mini"
                icon="el-icon-delete"
                @click="cancelAmount"
                circle
              ></el-button>
            </span>
          </div>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
import {
  getCommissionTransferInfoDetail, //查看佣金支付资讯
  updateInfoDetail //更新佣金支付资讯
} from "@/api/commission";
export default {
  data() {
    return {
      loading: true,
      showPeriod: false,
      showCurrency: false,
      showAmount: false,
      commissionInfoData: null,
      Period: [
        {
          value: 1,
          label: "每周"
        },
        {
          value: 2,
          label: "每两周"
        },
        {
          value: 3,
          label: "每月"
        },
        {
          value: 4,
          label: "每季"
        },
        {
          value: 5,
          label: "每半年"
        },
        {
          value: 6,
          label: "每年"
        }
      ],
      Currency: [
        {
          value: 1,
          label: "人民币"
        },
        {
          value: 2,
          label: "美元"
        },
        {
          value: 3,
          label: "日元"
        }
      ],

      periodValue: "",
      currencyValue: "",
      amountValue: ""
    };
  },

  mounted() {
    this.initList();
  },

  methods: {
    // 初始化表格数据
    initList() {
      this.loading = true;
      getCommissionTransferInfoDetail({
        params: {
          introduceId: parseInt(window.localStorage.getItem("IntroducerId"))
        }
      }).then(res => {
        this.commissionInfoData = res.data;
        // console.log(this.commissionInfoData);
        this.loading = false;
      });
    },
    //修改周期
    updatePeriod() {
    
      this.showPeriod = true;
    },
    //修改币别
    updateCurrency() {
  
      this.showCurrency = true;
    },
    //修改最低支付额数
    updateAmount() {
    
      this.showAmount = true;
    },
    //确定修改周期
    confirmPeriod() {
      // console.log(this.periodValue);
      if (!this.periodValue) {
        this.showPeriod = false;
        return;
      }
      updateInfoDetail({
        period: this.periodValue,
        introduceId: parseInt(window.localStorage.getItem("IntroducerId")),
        updateTag: "period"
      }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
        }
        this.showPeriod = false;
        this.initList();
      });
    },
    //确定修改币别
    confirmCurrency() {
      // console.log(this.currencyValue);
      if (!this.currencyValue) {
        this.showCurrency = false;
        return;
      }
      updateInfoDetail({
        currency: this.currencyValue,
        introduceId: parseInt(window.localStorage.getItem("IntroducerId")),
        updateTag: "currency"
      }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
        }
        this.showCurrency = false;
        this.initList();
      });
    },
    //确定修改最低支付额数
    confirmAmount() {
      // console.log(this.amountValue);
      updateInfoDetail({
        minimumAmount: this.amountValue,
       introduceId: parseInt(window.localStorage.getItem("IntroducerId")),
        updateTag: "minimumAmount"
      }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
        }
        this.showAmount = false;
        this.initList();
      });
    },

    //取消周期
    cancelPeriod() {
      this.showPeriod = false;
    },
    //取消币别
    cancelCurrency() {
      this.showCurrency = false;
    },
    //取消最低支付额数
    cancelAmount() {
      this.showAmount = false;
    }
  }
};
</script>
<style lang="less" scoped>
.comm_info {
  .box-card {
    padding: 20px;
    // text-align: center;

    .el-row {
      margin-bottom: 10px;
      &:last-child {
        margin-bottom: 0;
      }
    }
    .grid-content {
      border-radius: 6px;
      min-height: 40px;
      line-height: 40px;
      padding-left: 20px;
      box-sizing: border-box;
      background: #e1e3e9;
      .el-dropdown-link {
        cursor: pointer;
        color: #409eff;
      }
      .success {
        background-color: rgb(76, 100, 235);
      }
    }
  }
}
</style>
