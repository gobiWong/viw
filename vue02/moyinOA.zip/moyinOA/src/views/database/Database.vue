<template>
  <div class="service_online">
    <el-form
      :inline="true"
      :model="formInline"
      ref="searchDatabaseForm"
      class="demo-form-inline"
      size="small"
    >
      <el-form-item prop="user">
        <el-input v-model="formInline.user" placeholder="类别"></el-input>
      </el-form-item>
      <el-form-item prop="region">
        <el-select v-model="formInline.region" placeholder="选择语言">
          <el-option label="区域一" value="shanghai"></el-option>
          <el-option label="区域二" value="beijing"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
          icon="el-icon-search"
          @click="onSubmit('searchDatabaseForm')"
          plain
          size="small"
        >搜索</el-button>
        <el-button
          style="backgroundColor: #656FE7;color:#fff;border-radius:8px;"
          icon="el-icon-delete"
          @click="onReset('searchDatabaseForm')"
          plain
          size="small"
        >重置</el-button>
      </el-form-item>
    </el-form>

    <!-- 表格区域开始!! -->
    <div class="mm_table">
      <el-table
        :data="dataBase"
        border
        style="width: 100%"
        :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'30px',
		'text-align':'center',
     }"
        :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    }"
      >
        <!-- <el-table-column
          prop="ref_num"
          label="参考号码"
          width="180"
          sortable
          :filters="[{text: '2016-05-01', value: '2016-05-01'}, {text: '2016-05-02', value: '2016-05-02'},]"
          :filter-method="filterHandler"
        ></el-table-column>-->
        <el-table-column prop="databaseType" label="类别" width="180"></el-table-column>
        <el-table-column prop="databaseName" label="名称"></el-table-column>

        <el-table-column label="地址" min-width>
          <template slot-scope="scope">
            <a
              :href="'http://'+scope.row.databaseUrl"
              target="_blank"
              class="buttonText"
            >{{scope.row.databaseUrl}}</a>
          </template>
        </el-table-column>
        <el-table-column prop="languageId" label="语言" :formatter="filterLanguage"></el-table-column>

        <el-table-column prop="databaseTranslation" label="指引"></el-table-column>
        <el-table-column prop="databaseData" label="发布日期" :formatter="dateFormat"></el-table-column>

        <!-- <el-table-column label="执行">
        <template slot-scope="scope">
          <el-button size="mini" type="primary" plain icon="el-icon-edit" @click="showEditDialog(scope.row)">查看</el-button>
       
        </template>
        </el-table-column>-->
      </el-table>
    </div>
    <!-- 表格区域结束!! -->

    <!-- 新增资料库弹框开始-->
    <el-dialog title="添加资料库" :visible.sync="addDialogFormVisible">
      <el-form
        :inline="true"
       
        :rules="rules"
        ref="addDatabaseForm"
        size="mini"
        class="add_database"
        :model="formDatabase"
      >
        <el-form-item label="类别"  prop="databaseType">
          <el-select v-model="formDatabase.databaseType" placeholder="请选择类别">
            <el-option label="资讯" value="资讯"></el-option>
            <el-option label="工具与指南" value="工具与指南"></el-option>
            <el-option label="目录" value="目录"></el-option>
            <el-option label="时事通讯" value="时事通讯"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="名称"  prop="databaseName">
          <el-input v-model="formDatabase.databaseName" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="网址"  prop="databaseUrl">
          <el-input placeholder="请输入内容" v-model="formDatabase.databaseUrl" autocomplete="off">
            <!-- <template class="tt" slot="prepend">Http://</template> -->
          </el-input>
        </el-form-item>
        <el-form-item label="语言"  prop="languageId">
          <el-select v-model="formDatabase.languageId" placeholder="选择语言">
            <el-option
              v-for="(item,index) in langs"
              :key="index"
              :label="item.countryName"
              :value="item.languageId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="指引"  prop="databaseTranslation">
          <el-input v-model="formDatabase.databaseTranslation" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm('addDatabaseForm')" size="small">取 消</el-button>
        <el-button type="primary" @click="addData('addDatabaseForm')" size="small">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 新增资料库弹框完成 -->

    <!-- 新增按钮 -->
    <el-button
      type="success"
      size="small"
      icon="el-icon-plus"
      @click="addDialogFormVisible = true"
      style="margin-top:10px"
    >新增资料库</el-button>
  </div>
</template>

<script>
import { getPublicdatabase, addDatabase, getLanguage } from "@/api";
//验证网址
let checkUrl = (rule, value, callback) => {
  if (value == "" || value == undefined) {
    callback();
  } else {
    let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
    if (!reg.test(value)) {
      callback(new Error("格式不对"));
    } else {
      callback();
    }
  }
};
export default {
  data() {
    return {
      addDialogFormVisible: false,
      loading: true,
      tableData: [
        {
          ref_num: "yy9527",
          name: "王小虎",
          introducer: "金沙",
          doc_type: "类型1",
          last_update: "2020-02-02",
          status: "已读",
          unread_msg: "未读消息"
        },
        {
          ref_num: "yy952766",
          name: "王小龙",
          introducer: "德贤",
          doc_type: "类型2",
          last_update: "2020-03-03",
          status: "已回复",
          unread_msg: "未读消息1"
        }
      ],
      formDatabase: {
        databaseType: "",
        databaseName: "",
        languageId: "",
        databaseTranslation: "",
        databaseUrl: ""
      },
      dataBase: [
        //       {
        //     databaseId: 1,
        //     languageId: 4,
        //     databaseType: "目录",
        //     databaseName: "网易体育",
        //     databaseTranslation: "Installation guide",
        //     databaseData: "2019-05-30T16:00:00.000+0000",
        //     databaseUrl: "http://sports.sina.com.cn/"
        // }
      ],
      options: [
        {
          value: "选项1",
          label: "黄金糕"
        },
        {
          value: "选项2",
          label: "双皮奶"
        },
        {
          value: "选项3",
          label: "蚵仔煎"
        },
        {
          value: "选项4",
          label: "龙须面"
        },
        {
          value: "选项5",
          label: "北京烤鸭"
        }
      ],
      value: "",
      input: "",
      formLabelWidth: "",
      // 添加资料表单验证自定义
      rules: {
        databaseType: [
          { required: true, message: "请输入类别", trigger: "blur" }
        ],
        databaseName: [
          { required: true, message: "请输入名称", trigger: "blur" }
        ],
        languageId: [
          { required: true, message: "请选择语言", trigger: "blur" }
          // {
          //   type: "email",
          //   message: "请输入正确的邮箱地址",
          //   trigger: "blur,change"
          // }
        ],
        databaseTranslation: [{ required: true, message: "请输入内容" }],
        databaseUrl: [
          { required: true, message: "请输入网址" },
          {
            checkUrl: checkUrl,
            message: "请输入正确的网络地址",
            trigger: "blur,change"
          }
        ]
      },
      langs: [],
      //搜索选框测试数据
      formInline: {
        user: "",
        region: ""
      }
    };
  },
  created() {
    this.initList();
  },
  mounted() {
    //  获取语言列表
    this.getlangs();
  },
  methods: {
    // 过滤转化语言ID
    filterLanguage(row) {
      let status = "";
      switch (parseInt(row.languageId)) {
        case 1:
          status = "英语";
          break;
        case 2:
          status = "中文简体";
          break;
        case 3:
          status = "中文繁體";
          break;
        case 4:
          status = "日語";
          break;
      }
      return status;
    },
    //没做格式化,直接截取了,后期可能要根据时间戳做格式化
    dateFormat(row) {
      return row.databaseData.slice(0, 10);
    },
    //表头搜索提交按钮
    onSubmit(formName) {
      // console.log( this.formInline)
    },
    //表头搜索重置按钮
    onReset(formName) {
      // console.log(this.$refs[formName]);
      this.$refs[formName].resetFields();
    },

    searchFilter() {},
    resetDateFilter() {
      this.$refs.filterTable.clearFilter("date");
    },
    clearFilter() {
      this.$refs.filterTable.clearFilter();
    },
    startFilter() {},
    formatter(row, column) {
      return row.address;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },
    showEditDialog() {},
    //获取语言选框
    getlangs() {
      getLanguage({}).then(res => {
        this.langs = res;
      });
    },
    // 初始化表格数据
    initList() {
      this.loading = true;
      getPublicdatabase({
        // params: {
        //   query: this.query,
        //   pagenum: this.pagenum,
        //   pagesize: this.pagesize
        // }
      }).then(res => {
        // console.log(res);
        this.dataBase = res;
        // this.total = res.data.total
        this.loading = false;
      });
    },
    // 添加资料库
    addData(formName) {
      this.$refs[formName].validate(valide => {
        if (valide) {
          // 执行添加用户方法
          addDatabase(this.formDatabase).then(res => {
            // console.log(res);
            if (res.rtnCode === 1) {
              this.$message({
                type: "success",
                message: res.rtnMsg
              });
            }
            this.addDialogFormVisible = false;
            this.initList();
          });
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
  }
  .mm_table {
    margin-top: 10px;
  }
  .tt.el-input-group__prepend {
    padding: 0, 5px;
  }
}
</style>
