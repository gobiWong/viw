<template>
  <div class="document">
    <!-- <el-dropdown @command="handleCommand">
      <span class="el-dropdown-link">
        {{command}}
        <i class="el-icon-arrow-down el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="简体中文">简体中文</el-dropdown-item>
        <el-dropdown-item command="中文繁體">中文繁體</el-dropdown-item>
        <el-dropdown-item command="English">English</el-dropdown-item>
        <el-dropdown-item command="日本語">日本語</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>-->

    <div class="doc_table">
      <el-table
        :data="documentList"
        ref="singleTable"
        border
        selection
        style="width: 100%"
        :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'center',
     }"
        :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    'height':'35px'
    }"
      >
        <!-- <el-table-column prop="documentId" label="文件"></el-table-column>

        <el-table-column prop="userId" label="用户"></el-table-column>-->
        <el-table-column prop="documentType" label="种类" width="120px"></el-table-column>
        <el-table-column prop="documentDetail" label="细节" width="180px"></el-table-column>

        <el-table-column prop="documentData" label="时间" :formatter="dateFormat"></el-table-column>
        <el-table-column prop="documentUrl" label="文件名" width="340px"></el-table-column>

        <el-table-column fixed="right" label="操作">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small">下载</el-button>
            <!-- <el-button type="text" size="small">编辑</el-button> -->
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 上传个人文件 -->
    <el-button
      type="success"
      size="small"
      icon="el-icon-plus"
      @click="addDialogFormVisible = true"
      style="margin-top:10px"
    >上传个人文件</el-button>
    <!-- 上传个人文件弹出框 -->

    <el-dialog title="上传个人文件" :visible.sync="addDialogFormVisible">
      <el-form
        label-width="auto"
        :rules="rules"
        ref="addDocumentForm"
        size="mini"
        :model="formDocument"
      >
        <el-form-item label="种类" :label-width="formLabelWidth" prop="documentType">
          <el-select v-model="formDocument.documentType" placeholder="请选择类别">
            <el-option label="资讯" value="资讯"></el-option>
            <el-option label="工具与指南" value="工具与指南"></el-option>
            <el-option label="目录" value="目录"></el-option>
            <el-option label="时事通讯" value="时事通讯"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="细节" :label-width="formLabelWidth" prop="documentDetail">
          <el-input v-model="formDocument.documentDetail" autocomplete="off" style="width:195px"></el-input>
        </el-form-item>
        <el-form-item label="文件" :label-width="formLabelWidth" prop="documentUrl">
          <!-- <input type="file" value="" id="file" @change="uploadConfig" placeholder="上传文件" name="documentUrl"> -->

          <el-upload
            v-model="formDocument.documentUrl"
            ref="upload"
            :action="doUpload"
            :before-upload="beforeUpload"
            multiple
            :on-success="handleFileSuccess"
            :auto-upload="false"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm('addDocumentForm')" size="small">取 消</el-button>
        <el-button type="primary" @click="submitUpload" size="small">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import axios from "axios";
import { getDocument, addDocument, downloadDocument, baseURL } from "@/api";

export default {
  data() {
    return {
      doUpload: "",
      fd: null,
      datas: {
        userID: 1,
        documentType: "测试",
        documentDetail: "A"
      },
      command: "简体中文",
      addDialogFormVisible: false,
      formLabelWidth: "",
      rules: {
        documentType: [
          { required: true, message: "请选文件类型", trigger: "change" }
        ],
        documentDetail: [
          { required: true, message: "请填写文件细节", trigger: "blur" }
        ],
        documentUrl: [
          {
            type: "date",
            required: true,
            message: "请选择文件",
            trigger: "change"
          }
        ]
      },//表单验证
      documentList: [
        {
          documentId: 1, //文件
          userId: 1, //用户
          documentType: "3", //种类
          documentDetail: "c", //细节
          documentData: "2019-06-01T16:00:00.000+0000", //时间
          documentUrl: "b45b6d6c-f5b8-4340-bdce-2e2f09b92a27.xlsx" //文件名
        }
      ],
      formDocument: {
        userID: "",
        documentType: "",
        documentDetail: "",
        documentUrl: ""
      },
      userID: ""
    };
  },
  mounted() {
    //  获取语言列表
    this.getdocumentList();
  },
  methods: {
    //没做格式化,直接截取了,后期可能要根据时间戳做格式化
    dateFormat(row) {
      /**
       * 将"2018-05-19T08:04:52.000+0000"这种格式的时间转化为正常格式
       *
       */

      var d = new Date(row.documentData);

      var year = d.getFullYear(); //年
      var month = d.getMonth() + 1; //月
      var day = d.getDate(); //日

      var hh = d.getHours(); //时
      var mm = d.getMinutes(); //分
      var ss = d.getSeconds(); //秒

      var clock = year + "/";

      if (month < 10) clock += "0";

      clock += month + "/";

      if (day < 10) clock += "0";

      clock += day + " ";

      if (hh < 10) clock += "0";

      clock += hh + ":";
      if (mm < 10) clock += "0";
      clock += mm + ":";

      if (ss < 10) clock += "0";
      clock += ss;
      return clock;
    },

    //上传前
    beforeUpload(file) {
      let fd = new FormData();
      fd.append("documentUrl", file); //传文件
      fd.append("documentType", this.formDocument.documentType); //传其他参数
      fd.append("userID", parseInt(this.$store.getters.userId));
      fd.append("documentDetail", this.formDocument.documentDetail);
      this.fd = fd;

      axios.post(`${baseURL}/document/addDocument`, this.fd).then(res => {
        // console.log(res);

        this.getdocumentList();
        this.$message({
          type: "success",
          message: "操作成功！"
        });
      });
    },

    //提交上传
    submitUpload() {
      this.$refs.upload.submit();
      console.log("123");
      this.addDialogFormVisible = false;
    },

    //上传文件成功回调
    handleFileSuccess(res, file) {
      this.formDocument.documentUrl = URL.createObjectURL(file.raw);
      // console.log(file);
    },

    handleCommand(command) {
      this.command = command;
      if (command === "English") {
        this.$i18n.locale = "en";
      } else if (command === "简体中文") {
        this.$i18n.locale = "zh";
      } else if (command === "中文繁體") {
        this.$i18n.locale = "hk";
      } else {
        this.$i18n.locale = "ja";
      }
    },
    //下载文件
    handleClick(row) {
      console.log(row.documentUrl);
      // downloadDocument(row.documentUrl).then(res => {
      //   // console.log(res)
      // });
      // console.log(row);
    },
    // 获取文件数据
    getdocumentList() {
      this.userID = parseInt(this.$store.getters.userId);

      getDocument({ userID: this.userID }).then(res => {
        // console.log(res);
        this.documentList = res;
      });
    },
    //上传个人文件
    uploadDocumen(formName) {
      // console.log("111");
      this.$refs[formName].validate(valide => {
        if (valide) {
          // 执行添加用户方法
          addDocument({
            ...this.datas,
            ...this.formDocument,
            userID: parseInt(this.$store.getters.userId)
          }).then(res => {
            // console.log(res);
            if (res.rtnCode === 1) {
              this.$message({
                type: "success",
                message: res.rtnMsg
              });
            }
            this.addDialogFormVisible = false;
            this.getdocumentList();
          });
        }
      });
    },
    //重置上传文件
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
};
</script>
<style>
.el-dropdown-link {
  cursor: pointer;
  color: #409eff;
}
.el-icon-arrow-down {
  font-size: 12px;
}
</style>
