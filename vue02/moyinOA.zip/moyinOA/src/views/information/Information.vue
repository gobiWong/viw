<template>
  <div class="information">
    <el-row :gutter="20">
      <!-- // 每一个 tab 绑定了一个点击事件，传入的参数对应着 tab 下的组件名 -->

      <el-col :span="12">
        <div
          class="tab"
          :class="{colorChange:currentTab=='personInfo'?true:false}"
          @click="toggleTab('personInfo')"
        >
          <a>个人资讯</a>
        </div>
        <div class="line" v-if="showline" style="background-color:#b3c0d1"></div>
      </el-col>
      <el-col :span="12">
        <div
          class="tab"
          @click="toggleTab('teamInfo')"
          :class="{colorChange:currentTab=='teamInfo'?true:false}"
        >
          <a>组织资讯</a>
        </div>
        <div class="line" v-if="!showline" style="background-color:#b3c0d1"></div>
      </el-col>
    </el-row>
    <div class="div1">
      <transition enter-active-class="animated fadeInLeft">
        <person-info :is="currentTab" keep-alive></person-info>
      </transition>
    </div>

    <!-- // 子组件，显示不同的 tab
// is 特性动态绑定子组件
    // keep-alive 将切换出去的组件保留在内存中-->
  </div>
</template>
<script>
// 引入子组件
import personInfo from "./informationtabs/personInfo";
import teamInfo from "./informationtabs/teamInfo";
export default {
  name: "app",
  data() {
    return {
      loading: false,
      showline: true,
      currentTab: "personInfo" // currentTab 用于标识当前触发的子组件
    };
  },
  components: {
    // 声明子组件
    personInfo,
    teamInfo
  },
  methods: {
    toggleTab: function(tab) {
      const loading = this.$loading({
        lock: true,
        text: "Loading",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)",
        target: document.querySelector(".div1")
      });
      setTimeout(() => {
        loading.close();
      }, 200);
      this.currentTab = tab; // tab 为当前触发标签页的组件名
      this.showline = !this.showline;
    }
  }
};
</script>



<style lang="less" scoped>
.information {
  .tab {
    text-align: center;
    height: 40px;
    line-height: 40px;
    cursor: pointer;
  }
  .line {
    height: 1px;
    width: 100%;
    margin-top: 5px;
    background-color: #b3c0d1;
  }
}
.colorChange {
  background-color: rgb(179, 189, 209);
}
</style>