<template>
  <div class="person">
    <div id="echarts" :style="{width: '400px', height: '400px'}"></div>
    <el-table :data="tableData" border style="width: 100%">
      <el-table-column sortable prop="proSeries" label="产品系列" width="180"></el-table-column>
      <el-table-column sortable prop="currency" label="货币" width="180"></el-table-column>
      <el-table-column sortable prop="plantotal" label="计划案总数"></el-table-column>
      <el-table-column sortable prop="contribution" label="供款"></el-table-column>
      <el-table-column sortable prop="accountValue" label="账户价值"></el-table-column>
    </el-table>
    <!-- 累计点数折叠版 -->
    <div>
      <el-collapse v-model="point" @change="handleChange">
        <el-collapse-item name>
          <template slot="title">
            <i class="header-icon el-icon-s-data"></i>
            <span class="title_name">累计点数</span>
          </template>
          <div>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念；</div>
          <div>在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</div>
        </el-collapse-item>
      </el-collapse>
    </div>
    <!-- 2019全球大会折叠版 -->
    <div>
      <el-collapse v-model="global" @change="handleChange">
        <el-collapse-item name>
          <template slot="title">
            <i class="header-icon el-icon-trophy"></i>
            <span class="title_name">2019年全球大会</span>
          </template>
          <div style="height: 660px; width:100%">
            <el-steps direction="vertical" :active="0">
              <!-- 1 -->
              <el-step>
                <template slot="description">
                  <div class="step-row" :class="setLevel(0)">
                    <div class="step_content">
                      <p class="title">资格状态：尚未符合最低资格条件</p>
                      <div class="line"></div>
                      <p>您已递送：0点数以及0计划案件</p>
                      <p>您在累积175，000点数与10件计划案件就可以达到级别1-175，000累积点数</p>
                    </div>
                  </div>
                </template>
              </el-step>
              <!-- 2 -->
              <el-step>
                <template slot="description">
                  <div class="step-row" :class="setLevel(1)">
                    <div class="step_content">
                      <p class="title">级别1-175，000累积点数</p>
                      <div class="line"></div>
                      <p>最低资格条件：10计划案件以及175，000点数</p>
                      <p>配套包含：单人邀请| 1张经济舱机票</p>
                    </div>
                  </div>
                </template>
              </el-step>
              <!-- 3 -->
              <el-step>
                <template slot="description">
                  <div class="step-row" :class="setLevel(2)">
                    <div class="step_content">
                      <p class="title">级别2-250，000累积点数</p>
                      <div class="line"></div>
                      <p>最低资格条件：10计划案件以及250，000点数</p>
                      <p>配套包含：双人邀请| 2张经济舱机票</p>
                    </div>
                  </div>
                </template>
              </el-step>
              <!-- 4 -->
              <el-step>
                <template slot="description">
                  <div class="step-row" :class="setLevel(3)">
                    <div class="step_content">
                      <p class="title">级别3-350，000累积点数</p>
                      <div class="line"></div>
                      <p>最低资格条件：10计划案件以及350，000点数</p>
                      <p>配套包含：双人邀请| 2张经济舱机票 | 1，500美金</p>
                    </div>
                  </div>
                </template>
              </el-step>
              <!-- 5 -->
              <el-step>
                <template slot="description">
                  <div class="step-row" :class="setLevel(4)">
                    <div class="step_content">
                      <p class="title">级别4-500，000累积点数</p>
                      <div class="line"></div>
                      <p>最低资格条件：10计划案件以及500，000点数</p>
                      <p>配套包含：双人邀请| 2张经济舱机票 | 3，000美金</p>
                    </div>
                  </div>
                </template>
              </el-step>
              <!-- 6 -->
              <el-step>
                <template slot="description">
                  <div class="step-row" :class="setLevel(5)">
                    <div class="step_content">
                      <p class="title">级别5-750，000累积点数</p>
                      <div class="line"></div>
                      <p>最低资格条件：10计划案件以及750，000点数</p>
                      <p>配套包含：双人邀请| 2张经济舱机票 | 5，000美金</p>
                    </div>
                  </div>
                </template>
              </el-step>
              <!-- end -->
            </el-steps>
          </div>
        </el-collapse-item>
      </el-collapse>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      point: ["1"],
      global: [""],
      level: 1, //级别+++
      tableData: [
        {
          proSeries: "总计",
          currency: "美元",
          plantotal: "3",
          contribution: "12，580.65",
          accountValue: "12，695.23"
        },
        {
          proSeries: "指数保本",
          currency: "美元",
          plantotal: "3",
          contribution: "12，580.65",
          accountValue: "12，695.23"
        }
      ]
    };
  },
  mounted() {
    var dom = document.getElementById("echarts");
    var myChart = this.echarts.init(dom);
    // 绘制图表
    myChart.setOption({
      title: {
        text: "某站点用户访问来源",
        subtext: "纯属虚构",
        x: "center"
      },
      tooltip: {
        trigger: "item",
        formatter: "{a} <br/>{b} : {c} ({d}%)"
      },
      legend: {
        orient: "vertical",
        left: "left",
        data: ["直接访问", "邮件营销", "联盟广告", "视频广告", "搜索引擎"]
      },
      series: [
        {
          name: "访问来源",
          type: "pie",
          radius: "55%",
          center: ["50%", "60%"],
          data: [
            { value: 335, name: "直接访问" },
            { value: 310, name: "邮件营销" },
            { value: 234, name: "联盟广告" },
            { value: 135, name: "视频广告" },
            { value: 1548, name: "搜索引擎" }
          ],
          itemStyle: {
            emphasis: {
              shadowBlur: 20,
              shadowOffsetX: 0,
              shadowColor: "rgba(0, 0, 0, 0.5)"
            }
          }
        }
      ]
    });
  },
  methods: {
    handleChange(val) {
      console.log(val);
    },
    setLevel(level) {
  
      if (this.level == level) return "current border_current";
    }
  }
};
</script>


<style lang="less" scoped>
.person {
  width: 98%;
  height: 600px;
  background-color: #eee;
  margin: 10px auto;
  #echarts {
    margin: 20px 0 0 20px;
  }
}
.title_name {
  font-size: 16px;
}
.step-row {
  background-color: #bbb;
  color: #fff;
  width: 110%;
  height: 100px;
  margin-left: 20px;
  box-sizing: border-box;
  .step_content {
    margin-left: 20px;
    padding-top: 15px;
    line-height: 20px;
    .title {
      font-size: 22px;
      font-weight: 500;
    }
    p {
      font-size: 16px;
    }
    .line {
      width: 110%;
      height: 1px;
      margin: 5px 0 10px 0;
      background-color: #fff;
    }
  }
}
.step-row::after {
  position: absolute;
  top: 10%;
  left: 30px;
  content: "";
  width: 0;
  height: 0;
  border: 12px solid;
  border-color: transparent #bbb transparent transparent;
}
.border_current::after {
  border-color: transparent cornflowerblue transparent transparent;
}
.step-row:nth-last-of-type(1) {
  padding-right: 11%;
}
.current {
  background: cornflowerblue;
}
</style>
