<template>
    <div class="team">
        组织资讯
    </div>
</template>

<style lang="less" scoped>
    .team{
        width: 98%;
        height: 600px;
        background-color: #bbb;
        margin: 10px auto;
    }
</style>