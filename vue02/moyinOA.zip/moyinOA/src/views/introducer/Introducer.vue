<template>
  <div class="introducer">
    <div class="intro_table">
      <el-table
        border
        stripe
         v-loading="loading"
        :header-cell-style="{'background-color': '#DCDFE6', 'height':'30px','text-align':'center', }"
        :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
        style="width: 100%"
      >
        <!-- <el-table-column label="英文名" prop="englishName" width="80px" fixed></el-table-column> -->
        <el-table-column label="英文名" prop="chineseName"  ></el-table-column>
        <el-table-column label="英文姓" prop="englishName" ></el-table-column>

          <el-table-column label="使用者姓名" prop="staffName"></el-table-column>
        <!-- <el-table-column label="出生日期" prop="beneficiaryBirthday" width="100px"></el-table-column>
        <el-table-column label="性别" prop="beneficiarySex" width="50px"></el-table-column>
        <el-table-column label="国籍" prop="countryId"></el-table-column>
        <el-table-column label="语言偏好" prop="languageId" width="80px"></el-table-column> -->

        <!-- <el-table-column label="证件类别" prop="staffCertificateType" width="80px"></el-table-column>
        <el-table-column label="证件号码" prop="staffCertificateNo" width="140px"></el-table-column>
        <el-table-column label="发证国家" prop="countryId" width="80px"></el-table-column>
        <el-table-column label="发证日期" prop="staffFaData" width="100px"></el-table-column>
        <el-table-column label="有效日期" prop="staffOutData"  width="100px"></el-table-column> -->

        <el-table-column label="邮件信箱" prop="staffEmail"></el-table-column>
        <!-- <el-table-column label="确认信箱" prop="staffTrueEmail" width="180px"></el-table-column>
        <el-table-column label="电话种类" prop="staffPhoneType" width="80px"></el-table-column>
        <el-table-column label="国家代码" prop="staffCountryCode" width="80px"></el-table-column>
        <el-table-column label="手机门号" prop="staffMobile" width="80px"></el-table-column> -->
        <!-- <el-table-column label="地方号" prop="staffLandline"></el-table-column> -->

      
          <!-- 编辑删除，备选功能 -->
        <!-- <el-table-column label="操作" width="180px" fixed="right">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column> -->
      </el-table>
    </div>
    <div class="add_intro">
      <el-button
        type="success"
        size="small"
        icon="el-icon-plus"
        @click="addDialogFormVisible = true"
      >新介绍人行政人员</el-button>

      <!-- 添加介绍人行政人员 -->
      <el-dialog :visible.sync="addDialogFormVisible" top="10vh">
        <el-form
          :inline="true"
          :model="addForm"
          label-width="auto"
          :rules="rules"
          ref="addIntroducerForm"
          size="mini"
        >
          <!-- 个人资料分割线 -->
          <el-row style="font-size:16px">
            <el-col :span="24">个人资料</el-col>
            <el-divider></el-divider>
          </el-row>
          <el-form-item label="英文名" prop="englishName">
            <el-input
              v-model="addForm.englishName"
              auto-complete="off"
              prefix-icon="el-icon-user"
              placeholder="英文名"
            ></el-input>
          </el-form-item>
          <el-form-item label="别名" prop="chineseName">
            <el-input v-model="addForm.chineseName" auto-complete="off" prefix-icon="el-icon-user"></el-input>
          </el-form-item>
          <el-form-item label="英文姓" prop="englishName">
            <el-input v-model="addForm.englishName" auto-complete="off" prefix-icon="el-icon-user"></el-input>
          </el-form-item>
          <el-form-item label="出生日期" prop="beneficiaryBirthday">
            <el-date-picker
              style="width:193px"
              type="date"
              placeholder="出生日期"
               value-format="yyyy/MM/dd"
              v-model="addForm.beneficiaryBirthday"
            ></el-date-picker>
          </el-form-item>
          <el-form-item label="性别" prop="beneficiarySex">
            <el-select v-model="addForm.beneficiarySex" placeholder="性别">
              <el-option label="男" value="男"></el-option>
              <el-option label="女" value="女"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="国籍" prop="countryId">
            <el-select v-model="addForm.countryId" placeholder="国籍" prefix-icon="el-icon-user">
             <el-option v-for="(item,index) in countries" :key='index' :label="item.countryName" :value="item.countryId"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="语言偏好" prop="languageId">
            <el-select v-model="addForm.languageId" placeholder="语言偏好" >
              <el-option v-for="(item,index) in langs" :key='index' :label="item.countryName" :value="item.languageId"></el-option>
          
            </el-select>
          </el-form-item>
           <el-form-item label="部门" prop="departmentId">
            <el-select v-model="addForm.departmentId" placeholder="部门">
            <el-option v-for="(item,index) in departments" :key='index' :label="item.departmentName" :value="item.departmentId"></el-option>
            </el-select>
          </el-form-item>
          <!-- 身份证明分割线 -->
          <el-row style="font-size:16px">
            <el-col :span="24">身份证明文件</el-col>
            <el-divider></el-divider>
          </el-row>
          <el-form-item label="证件类别" prop="staffCertificateType">
            <el-select v-model="addForm.staffCertificateType" placeholder="选择身份证明文件类别">
              <el-option label="类别1" value="1"></el-option>
              <el-option label="类别2" value="2"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="证件号码" prop="staffCertificateNo">
            <el-input
              v-model="addForm.staffCertificateNo"
              auto-complete="off"
              prefix-icon="el-icon-s-check"
              placeholder="证件号码"
            ></el-input>
          </el-form-item>
          <el-form-item label="发证国家" prop="countryId">
            <el-select v-model="addForm.countryId" placeholder="发证国家">
             <el-option v-for="(item,index) in countries" :key='index' :label="item.countryName" :value="item.countryId"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="发证日期" prop="staffFaData">
            <el-date-picker
              style="width:193px"
              type="date"
              placeholder="发证日期"
               value-format="yyyy-MM-dd"
              v-model="addForm.staffFaData"
            ></el-date-picker>
          </el-form-item>
          <el-form-item label="有效日期" prop="staffOutData">
            <el-date-picker
              style="width:193px"
              type="date"
              placeholder="有效日期"
              value-format="yyyy-MM-dd"
              v-model="addForm.staffOutData"
            ></el-date-picker>
          </el-form-item>

          <!-- <el-form-item>
            <el-checkbox-group v-model="addForm.type">
              <el-checkbox label="无有效日期" name="type"></el-checkbox>
            </el-checkbox-group>
          </el-form-item> -->
          <!-- 联络资讯 -->
          <el-row style="font-size:16px">
            <el-col :span="24">联络资讯</el-col>
            <el-divider></el-divider>
          </el-row>
          <el-form-item label="邮件信箱" prop="staffEmail">
            <el-input
              v-model="addForm.staffEmail"
              auto-complete="off"
              prefix-icon="el-icon-s-check"
              placeholder="电子邮件地址"
            ></el-input>
          </el-form-item>
          <el-form-item label="确认信箱" prop="staffTrueEmail">
            <el-input
              v-model="addForm.staffTrueEmail"
              auto-complete="off"
              prefix-icon="el-icon-s-check"
              placeholder="确认电子邮件信箱"
            ></el-input>
          </el-form-item>
          <el-form-item label="电话种类" prop="staffPhoneType">
            <el-select v-model="addForm.staffPhoneType" placeholder="电话种类">
              <el-option label="种类1" value="1"></el-option>
              <el-option label="种类2" value="2"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="国家代码" prop="staffCountryCode">
            <el-select v-model="addForm.staffCountryCode" placeholder="国家代码">
              <el-option label="代码1" value="1"></el-option>
              <el-option label="代码2" value="2"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="手机门号" prop="staffMobile">
            <el-input
              v-model="addForm.staffMobile"
              auto-complete="off"
              prefix-icon="el-icon-phone"
              placeholder="局域号码/手机门号"
            ></el-input>
          </el-form-item>
          <el-form-item label="地方号码" prop="staffLandline">
            <el-input
              v-model="addForm.staffLandline"
              auto-complete="off"
              prefix-icon="el-icon-phone-outline"
              placeholder="地方号码"
            ></el-input>
          </el-form-item>
          <!-- 使用者资讯 -->
          <el-row style="font-size:16px">
            <el-col :span="24">使用者资讯</el-col>
            <el-divider></el-divider>
          </el-row>
          <el-form-item label="使用者姓名" prop="staffName">
            <el-input
              v-model="addForm.staffName"
              auto-complete="off"
              prefix-icon="el-icon-user-solid"
              placeholder="使用者姓名"
            ></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="addDialogFormVisible = false" size="small">取 消</el-button>
          <el-button type="primary" @click="addIntroducer('addIntroducerForm')" size="small">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import {
  getUserList,
  getStaffuserList,
  addStaff,
  getLanguage,
  getCountryList,
  getDepartmentList,
  getUserById,
  editUser,
  getRoleList,
  grantUserRole
} from "@/api";
export default {
  data() {
    return {
        loading: true,
      tableData: [
        {
          name: "王小虎",
          sex: "女",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 952718 弄"
        },
        {
          name: "王虎",
          sex: "男",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          name: "王老虎",
          sex: "男",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          name: "啊虎",
          sex: "男",
          age: 28,
          ID: "125485599228446212",
          phone: "13688886666",
          address: "上海市普陀区金沙江路 1518 弄"
        }
      ],
      langs:[],
      departments:[],
      countries:[],
      StaffuserList: [
        {
          staffId: 3,
          languageId: 4,
          countryId: 3,
          departmentId: 2,
          englishName: "李",
          chineseName: "四",
          beneficiaryBirthday: "2014-11-11",
          beneficiarySex: "女",
          staffCertificateType: "身份证",
          staffCertificateNo: "4206251996",
          staffFaData: "2014-11-11",
          staffOutData: "2014-11-11",
          staffEmail: "987654@163.com",
          staffTrueEmail: "987654321@163.com",
          staffPhoneType: "移动电话",
          staffCountryCode: "02777",
          staffMobile: "18627787219",
          staffLandline: "02777117",
          staffName: "李四-尼格拉斯"
        }
      ],
      search: "",
      dialogVisible: false,
      loading: true,
      userList: [],
      query: "",
      total: 0,
      pagesize: 10,
      pagenum: 1,
      addDialogFormVisible: false,
      addForm: {
          languageId:'',
          countryId: '',
          departmentId: '',
          englishName: "",
          chineseName: "",
          beneficiaryBirthday: "",
          beneficiarySex: "",
          staffCertificateType: "",
          staffCertificateNo: "",
          staffFaData: "",
          staffOutData: "",
          staffEmail: "",
          staffTrueEmail: "",
          staffPhoneType: "",
          staffCountryCode: "",
          staffMobile: "",
          staffLandline: "",
          staffName: ""
      },
  
      editDialogFormVisible: false,
      editForm: {
        username: "",
        email: "",
        mobile: "",
        id: 0
      },
      grantDialogFormVisible: false,
      grantForm: {},
      roleList: [],
      roleId: "",
      // 添加用户的表单验证
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" }
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        email: [
          { required: true, message: "请输入邮箱地址", trigger: "blur" },
          {
            type: "email",
            message: "请输入正确的邮箱地址",
            trigger: "blur,change"
          }
        ],
        mobile: [{ required: true, message: "电话不能为空" }]
      }
    };
  },
  created() {
    this.initList();
  },
  mounted(){
    this.getlangs(),
    this.getdepartments(),
    this.getcountries()
  },
  methods: {
    handleEdit(index, row) {
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },

    // 初始化表格数据
    initList() {
      this.loading = true;
      getStaffuserList({
        // params: {
        //   query: this.query,
        //   pagenum: this.pagenum,
        //   pagesize: this.pagesize
        // }
      }).then(res => {
        // console.log(res);
        this.tableData = res
        // this.total = res.data.total
        this.loading = false
      });
    },
    // 添加介绍人行政人员
    addIntroducer(formName) {
      this.$refs[formName].validate(valide => {
        if (valide) {
          // 执行添加用户方法
          addStaff(this.addForm).then(res => {
            console.log(res);
            if (res.rtnCode === 1) {
              this.$message({
                type: "success",
                message: res.rtnMsg
              });
            }
            this.addDialogFormVisible = false;
            this.initList();
          });
        }
      });
    },
    //获取语言选框
    getlangs(){
      getLanguage({}).then(res=>{
     
        this.langs=res
      })
    },

    //获取国家选框
    getcountries(){
      getCountryList({}).then(res=>{
       
        this.countries=res
      
      })
    },

    //获取部门选框
    getdepartments(){
      getDepartmentList({}).then(res=>{
    
          this.departments=res
      })
    },
    // 显示删除对话框
    showDeleteDialog(row) {
      this.$confirm("此操作将永久删除该用户, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // 执行删除用户操作
          deleteUser(row.id).then(res => {
            if (res.meta.status === 200) {
              this.$message({
                type: "success",
                message: "删除成功!"
              });
              this.initList();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>
<style lang="less" scoped>
.introducer {
  .add_intro {
    .el-button {
      margin-top: 12px;
    }
  }
}
</style>
