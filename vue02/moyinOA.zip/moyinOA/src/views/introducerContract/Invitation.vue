<template>
  <div class="invitation">
    <div class="intro_info" v-if="status">
      <!-- 信息输入 -->
      <el-row style="font-size:16px">
        <el-col :span="24">信息输入</el-col>
        <el-divider></el-divider>
      </el-row>
      <el-form
        :inline="true"
        :model="introducer_infoFrom"
        label-width="auto"
        :rules="rules"
        ref="introducer_info"
        size="small"
      >
        <el-form-item label="名字" prop="name">
          <el-input
            v-model="introducer_infoFrom.name"
            auto-complete="off"
            prefix-icon="el-icon-user"
            placeholder="英文名"
          ></el-input>
        </el-form-item>
        <el-form-item label="电子邮件信箱" prop="beneficiaryEmail">
          <el-input
            v-model="introducer_infoFrom.beneficiaryEmail"
            auto-complete="off"
            prefix-icon="el-icon-user"
          ></el-input>
        </el-form-item>
        <el-form-item label="语言" prop="languageId">
          <el-select v-model="introducer_infoFrom.languageId" placeholder="语言">
            <el-option
              v-for="(item,index) in langs"
              :key="index"
              :label="item.countryName"
              :value="item.languageId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="国家代码" prop="countryId">
          <el-select v-model="introducer_infoFrom.countryId" placeholder="国家代码">
            <el-option
              v-for="(item,index) in countries"
              :key="index"
              :label="item.countryName"
              :value="item.countryId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="电话门号与号码" prop="phone">
          <el-input
            v-model="introducer_infoFrom.phone"
            auto-complete="off"
            prefix-icon="el-icon-user"
          ></el-input>
        </el-form-item>
        <el-form-item label="直属主管">
          <el-input
            readonly
            v-model="introducer_infoFrom.directManagerName"
            auto-complete="off"
            prefix-icon="el-icon-user"
          ></el-input>
        </el-form-item>
        <el-form-item label="合约种类" prop="typeContracts">
          <el-select v-model="introducer_infoFrom.typeContracts" placeholder="合约种类">
            <el-option label="合约种类1" value="合约种类1"></el-option>
            <el-option label="合约种类2" value="合约种类2"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="阶级" prop="level">
          <el-select v-model="introducer_infoFrom.level" placeholder="阶级">
            <el-option label="阶级1" value="阶级1"></el-option>
            <el-option label="阶级2" value="阶级2"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div class="code">
        <h3>邀请验证码:</h3>
        <h3>开启电子邀请链接后,受邀人需要确认行动电话号码才能获取验证码以完成协议/申请书</h3>
        <div class="btn">
          <el-button
            style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
            size="small"
            @click="nextPage('introducer_info')"
          >下一页</el-button>
        </div>
      </div>
    </div>

    <div class="check" v-if="!status">
      <!-- 邀请审查 -->
      <el-row style="font-size:16px">
        <el-col :span="24">邀请审查</el-col>
        <el-divider></el-divider>
      </el-row>
      <el-card class="box-card check_item">
        <el-row :gutter="20" style="margin: 15px;line-height:20px">
          <el-col :span="6">
            <h3>名字</h3>
            <p>{{introducer_infoFrom.name}}</p>
          </el-col>
          <el-col :span="6">
            <h3>电子邮件信箱</h3>
            <p>{{introducer_infoFrom.beneficiaryEmail}}</p>
          </el-col>
          <el-col :span="6">
            <h3>语言</h3>
            <p>{{introducer_infoFrom.languageId | capitalize}}</p>
          </el-col>
        </el-row>
        <el-row :gutter="24" style="margin: 15px;line-height:20px">
          <el-col :span="6">
            <h3>行动电话号码</h3>
            <p>{{introducer_infoFrom.phone}}</p>
          </el-col>
          <el-col :span="6">
            <h3>直属主管</h3>
            <p>{{introducer_infoFrom.directManagerName}}</p>
          </el-col>
          <el-col :span="6">
            <h3>合约种类</h3>
            <p>{{introducer_infoFrom.typeContracts}}</p>
          </el-col>
          <el-col :span="6">
            <h3>阶级</h3>
            <p>{{introducer_infoFrom.level}}</p>
          </el-col>
        </el-row>
      </el-card>

      <el-divider></el-divider>
      <el-row style="font-size:16px">
        <el-col :span="24">合约职级表</el-col>
        <el-divider></el-divider>
      </el-row>

      <el-table :data="introducer_table" style="width: 100%">
        <el-table-column prop="date" label="计划种类" width="180"></el-table-column>
        <el-table-column prop="name" label="计划年限" width="180">
          <el-table-column prop="address" label="第一年"></el-table-column>
          <el-table-column prop="address" label="第二年"></el-table-column>
          <el-table-column prop="address" label="第三年"></el-table-column>
          <el-table-column prop="address" label="第四年"></el-table-column>
          <el-table-column prop="address" label="第五年"></el-table-column>
        </el-table-column>
      </el-table>

      <el-row class="check_footer">
        <el-col :span="24">
          <el-button type="info" size="small" @click="Cancel">取消</el-button>
          <el-button type="primary" size="small" @click="checkInvitation('introducer_info')">确定</el-button>
        </el-col>
      </el-row>

      <el-dialog :visible.sync="dialogVisible" width="50%">
        <div class="result" v-loading="loading">
          <el-row style="font-size:16px">
            <el-col :span="24">结果</el-col>
            <el-divider></el-divider>
          </el-row>
          <el-row>
            <el-col :span="24">邀请已发出</el-col>
          </el-row>
          <el-row style="font-size:16px">
            <el-col :span="24">登入码</el-col>
            <el-divider></el-divider>
          </el-row>
          <el-row>
            <el-col :span="12">
              <h4>登入码</h4>
              <p>{{result.total}}</p>
            </el-col>
            <el-col :span="12">
              <h4>邀请到期日期</h4>
              <p>{{result.endDate}}</p>
            </el-col>
          </el-row>
        </div>

        <span slot="footer" class="dialog-footer">
          <el-button size="small" @click="dialogVisible = false">取 消</el-button>
          <el-button size="small" type="primary" @click="dialogVisible = false">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import {
  addIntroducerUser, //邀请功能接口,添加表单，发出邀请
  getLanguage,
  getCountryList
} from "@/api";
export default {
  data() {
    return {
      status: true,
      dialogVisible: false,
      loading: true,
      langs: [], //语言列表
      countries: [], //国家列表
      directManagerId: "",
      rules: {
        name: [
          { required: true, message: "请输入名字", trigger: "blur" },
          { min: 1, max: 5, message: "长度在 3 到 5 个字符", trigger: "blur" }
        ],
        beneficiaryEmail: [
          { required: true, message: "请输入邮箱", trigger: "blur" },
          { type: "email", message: "请输入正确的邮箱地址", trigger: "blur" }
        ]
      },
      introducer_infoFrom: {
        name: "", //名字
        beneficiaryEmail: "", //电子邮件信箱
        languageId: "", //语言
        countryId: "", //国家代码
        phone: "", //电话门号与号码
        directManagerName: "", //直属主管
        typeContracts: "", //合约种类
        level: "", //阶级
        status: "" //状态 1.已发送 2.进行中 3.已重新发送 4.等待审核中 5.已取消 6.已完成
      },
      result: {
        total: "",
        endDate: ""
      }, //登入码
      obj: {},
      introducer_table: []
    };
  },
  created() {
    //获取语言列表
    getLanguage({}).then(res => {
      this.langs = res;
    });
    //设置直属主管名字为当前的用户
    this.introducer_infoFrom.directManagerName = window.localStorage.getItem(
      "userName"
    );
    //获取国家列表
    getCountryList({}).then(res => {
      this.countries = res;
    });
  },
  filters: {
    //回显内容语言过滤器
    capitalize: function(value) {
      let status = "";
      switch (parseInt(value)) {
        case 1:
          status = "英语";
          break;
        case 2:
          status = "中文简体";
          break;
        case 3:
          status = "中文繁体";
          break;
        case 4:
          status = "日语";
          break;
      }
      return status;
    }
  },
  methods: {
    //下一页切换回显内容
    nextPage(formName) {
      this.$refs[formName].validate(valide => {
        if (valide) {
          if (
            this.introducer_infoFrom.name &&
            this.introducer_infoFrom.beneficiaryEmail &&
            this.introducer_infoFrom.languageId &&
            this.introducer_infoFrom.countryId &&
            this.introducer_infoFrom.phone &&
            this.introducer_infoFrom.typeContracts &&
            this.introducer_infoFrom.level
          ) {
            this.status = !this.status;
          } else {
            this.$message("请填写完整信息");
          }
        }
      });
    },

    Cancel() {
      this.status = !this.status;
    },
    checkInvitation() {
      // 切换模拟加载效果
      const loading = this.$loading({
        lock: true,
        text: "Loading",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.3)",
        target: document.querySelector(".check")
      });

      //执行添加用户方法;
      console.log(this.$store.getters.userId);
      addIntroducerUser({
        ...this.introducer_infoFrom,
        status: "1",
        directManager: parseInt(window.localStorage.getItem("IntroducerId"))
      }).then(res => {
        if (res.success) {
          this.result.total = res.total;
          this.result.endDate = res.data;
          // 如果成功要跳转至首页, 将验证码total保存到vuex的state中
          this.$store.commit("setTotal", res.total);
          loading.close();
          this.loading = false;
          this.dialogVisible = true;
        }
         this.$message({
            type: "success",
            message: res.message
          });
      });
    },
  }
};
</script>
<style lang="less" scoped>
.code {
  margin-top: 20px;
  text-indent: 2em;
  h3 {
    display: block;
    width: 100%;
    height: 30px;
  }
  .btn {
    margin-top: 20px;
  }
}
.check_footer {
  margin-top: 15px;
  margin-left: 5px;
}
.check_item {
  h3 {
    font-weight: 600;
    font-size: 14px;
  }
  p{
    color: dimgray
  }
}
</style>
