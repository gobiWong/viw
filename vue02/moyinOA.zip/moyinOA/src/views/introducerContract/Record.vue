<template>
  <div class="service_online">
    <!-- 搜素表头 -->
    <div class="mm_button">
      <el-form
        :inline="true"
        :model="formInline"
        ref="serviceForm"
        class="demo-form-inline"
        size="small"
      >
        <el-form-item label=" 邀请日期：" prop="start_value">
          <el-col :span="8">
            <el-date-picker v-model="formInline.start_value" type="date" placeholder="开始日期"></el-date-picker>
          </el-col>
        </el-form-item>
        <el-form-item prop="end_value">
          <el-col :span="10">
            <el-date-picker v-model="formInline.end_value" type="date" placeholder="终止日期"></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item prop="name">
          <el-input v-model="formInline.name" placeholder="邀请人"></el-input>
        </el-form-item>
        <el-form-item prop="introducer">
          <el-input v-model="formInline.introducer" placeholder="受邀人"></el-input>
        </el-form-item>
        <el-form-item prop="doc_type">
          <el-select v-model="formInline.doc_type" placeholder="状态">
            <el-option label="已发送" value="已发送"></el-option>
            <el-option label="被弃用" value="被弃用"></el-option>
            <el-option label="已提交" value="已提交"></el-option>
            <el-option label="期限已满" value="期限已满"></el-option>
          </el-select>
        </el-form-item>
        <!-- <el-form-item label=" 最后更新" prop="start_update">
          <el-col :span="8">
            <el-date-picker v-model="formInline.start_update" type="date" placeholder="开始日期"></el-date-picker>
          </el-col>
        </el-form-item>
        <el-form-item prop="end_update">
          <el-col :span="10">
            <el-date-picker v-model="formInline.end_update" type="date" placeholder="终止日期"></el-date-picker>
          </el-col>
        </el-form-item>-->

        <el-form-item prop="status">
          <el-input v-model="formInline.status" placeholder="最后更新者"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button
            style="backgroundColor:#06A6F6;color:#fff;border-radius:8px;"
            icon="el-icon-search"
            @click="onSubmit('serviceForm')"
            plain
            size="small"
          >搜索</el-button>
          <el-button
            style="backgroundColor: #656FE7;color:#fff;border-radius:8px;"
            icon="el-icon-delete"
            @click="onReset('serviceForm')"
            plain
            size="small"
          >重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 记录表格 -->
    <div class="mm_table">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="{
        'background-color': '#DCDFE6',
        'height':'40px',
		    'text-align':'center',
         }"
        :cell-style="{'text-align':'center',}"
      >
        <el-table-column prop="createTime" label="邀请日期" width="180" sortable></el-table-column>
        <el-table-column prop="directManager" label="邀请人" width="120"></el-table-column>
        <el-table-column prop="name" label="受邀人"></el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <el-tag plain>{{scope.row.status|RECORD}}</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="expirationTime" sortable label="最后更新时间"></el-table-column>
        <el-table-column prop="directManager" label="最后更新人"></el-table-column>
        <el-table-column prop="unread_msg" label="审查">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="primary"
              plain
              icon="el-icon-edit"
              @click="showEditDialog(scope.row)"
            >审查</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页工具 -->
      <div class="page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="1"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="10"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </div>
    </div>

    <!-- 介绍人合约记录详细弹框 -->
    <el-dialog
      title="介绍人合约/记录"
      :visible.sync="dialogVisible"
      width="70%"
      top="4vh"
      :before-close="handleClose"
    >
      <el-collapse v-model="activeNames" @change="handleChange">
        <!--  审查-->
        <el-collapse-item title=" 审查(已提交)" name="1">
          <template slot="title">
            <i class="header-icon el-icon-zoom-in"></i>
            审查(已提交)
          </template>
          <el-row class="intro_news top">
            <el-col :span="8">
              <div class="grid-content bg-purple">
                <h4>名字：</h4>
                <p>{{detailList.name?detailList.name:'未填写'}}</p>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple-light">
                <h4>电子邮件信箱：</h4>
                <p>{{detailList.beneficiaryEmail?detailList.beneficiaryEmail:'未填写'}}</p>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple">
                <h4>语言：</h4>
                <p>{{detailList.languageId | LANGUAGE}}</p>
              </div>
            </el-col>
          </el-row>
          <el-row class="intro_news">
            <el-col :span="8">
              <div class="grid-content bg-purple">
                <h4>行动电话号码：</h4>
                <p>{{detailList.phone}}</p>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple-light">
                <h4>介绍人代码：</h4>
                <p>565363</p>
              </div>
            </el-col>
          </el-row>
          <el-row class="intro_news">
            <el-col :span="8">
              <div class="grid-content bg-purple">
                <h4>直属主管：</h4>
                <p>{{detailList.directManagerName?detailList.directManagerName:'未填写'}}</p>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple-light">
                <h4>合约总类：</h4>
                <p>{{detailList.typeContracts}}</p>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple">
                <h4>阶级：</h4>
                <p>{{detailList.level}}</p>
              </div>
            </el-col>
          </el-row>
          <el-divider></el-divider>

          <div>
            <el-row style="background-color:rgb(225, 243, 216)">
              <el-col :span="12">
                <h4>登入码</h4>
                <p>{{detailList.loginCode?detailList.loginCode:'123456'}}</p>
              </el-col>
              <el-col :span="12">
                <h4>邀请到期日</h4>
                <p>{{detailList.expirationTime}}</p>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <!-- name 介绍人资讯-->
        <el-collapse-item title="介绍人资讯" name="2">
          <template slot="title">
            <i class="header-icon el-icon-user"></i>
            介绍人资讯
          </template>
          <el-row class="intro_news">
            <el-col :span="6">
              <h3>名字</h3>
              <p>{{detailList.name?detailList.name:'未填写'}}</p>
            </el-col>
            <el-col :span="6">
              <h3>性别</h3>
              <p>{{detailList.beneficiarySex}}</p>
            </el-col>
            <el-col :span="6">
              <h3>职业</h3>
              <p>{{detailList.profession}}</p>
            </el-col>
            <el-col :span="6">
              <h3>在金融行业服务的经验年限</h3>
              <p>{{detailList.workingYears}}</p>
            </el-col>
          </el-row>
          <!-- <el-row class="intro_news">
            <el-col :span="6">
              <h3>身份证明文件</h3>
              <p>HONGBO FU(付宏博)</p>
            </el-col>
            <el-col :span="6">
              <h3>发证国家</h3>
              <p>HONGBO FU(付宏博)</p>
            </el-col>
            <el-col :span="6">
              <h3>证件的发放日期</h3>
              <p>HONGBO FU(付宏博)</p>
            </el-col>
            <el-col :span="6">
              <h3>证件有效日期</h3>
              <p>HONGBO FU(付宏博)</p>
            </el-col>
          </el-row>-->
          <el-row class="intro_news">
            <el-col :span="6">
              <h3>出生日期</h3>
              <p>{{detailList.beneficiaryBirthday}}</p>
            </el-col>
            <el-col :span="6">
              <h3>出生国家</h3>
              <p>{{detailList.countryId | COUNTRY}}</p>
            </el-col>
            <el-col :span="6">
              <h3>国籍</h3>
              <p>{{detailList.countryId | COUNTRY}}</p>
            </el-col>
            <el-col :span="6">
              <h3>电子邮件</h3>
              <p>{{detailList.beneficiaryEmail}}</p>
            </el-col>
          </el-row>
          <el-row class="intro_news">
            <el-col :span="6">
              <h3>电话号码</h3>
              <p>{{detailList.phone}}</p>
            </el-col>
            <el-col :span="6">
              <h3>住家地址</h3>
              <p>{{detailList.homeAddress?detailList.homeAddress:'未填写'}}</p>
            </el-col>
          </el-row>
          <el-row>
            <div class="line"></div>
            <el-col :span="24" class="other_news">
              <h3>其他人资讯</h3>
              <p>请问您目前或是否曾被政府、国家、或国际组织的相关机构委任某些重要的公职，如国家元首或政府首脑、资深或具有影响力的政治家、政府高级人员、司法或军事官员、或国有企业的高级管理人员？</p>
              <p>或者您是否与此类的政治敏感身份者拥有密切的关系或是其直系亲属？</p>
            </el-col>
          </el-row>
        </el-collapse-item>
        <!-- 合约总览 -->
        <el-collapse-item title="合约总览" name="3">
          <template slot="title">
            <i class="header-icon el-icon-postcard"></i>
            合约总览
          </template>

          <P style="font-weight: 600;">地区·</P>
          <span>中国</span>
          <div>
            <p style="font-weight: 600;">网路使用者</p>
            <ul>
              <li>1.在完成此协议/申请书后，介绍人将自行注册并设立其网络使用者帐户。</li>
              <li>2. 此介绍人要求MEME为其设立网络使用者帐号。</li>
              <li>3.此介绍人要求MEME以顾问代码为其设立网路使用者帐号。</li>
            </ul>
            <p style="font-weight: 600;">洗钱防制与侦查证明</p>
            <p>签署此协议/申请书代表介绍人已收到 MEME 的洗钱防制与侦查手册，并了解介绍人应熟悉该手册内容。介绍人进一步声明并保证：</p>
            <ul>
              <li>介绍人已详阅 MEME 的洗钱防制与侦查规定与指南。</li>
              <li>介绍人了解他/她/其对于洗钱防制的责任，此责任与其维持与 MEME 的关系有关。</li>
              <li>介绍人已通知公司其所有对于洗钱防制与侦查的疑虑。</li>
              <li>介绍人同意他/她得到足够的相关资讯。</li>
              <li>若介绍人对提供于他/她/它本人的培训及指导程度感到不满意，介绍人将立即通知公司。</li>
            </ul>
            <h3>所有介绍人应得的佣金将会保留至此协议/申请书经由 MEME 核准且介绍人于线上提交洗钱防制与侦查测验后，将会自动发放。</h3>
            <el-row class="intro_news">
              <el-col :span="24">
                <h3>直属主管</h3>
                <p>{{detailList.directManagerName?detailList.directManagerName:'未填写'}}</p>
                <h3>介绍人办事处</h3>
                <p>{{detailList.introducerWorkAddress?detailList.introducerWorkAddress:'未填写'}}</p>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <!--  佣金发放资讯-->
        <el-collapse-item title="佣金发放资讯" name="4">
          <template slot="title">
            <i class="header-icon el-icon-tickets"></i>
            佣金发放资讯
          </template>
          <el-row class="intro_news">
            <el-col :span="6">
              <h3>频率：</h3>
              <p>{{detailList.period | PERIOD}}</p>
            </el-col>
            <el-col :span="6">
              <h3>币别：</h3>
              <p>{{detailList.period | CURRENCY}}</p>
            </el-col>
            <el-col :span="6">
              <h3>最低金额：</h3>
              <p>{{detailList.minimumAmount?detailList.minimumAmount:'未填写'}}</p>
            </el-col>
            <el-col :span="6">
              <h3>类型：</h3>
              <p>{{detailList.grantType?detailList.grantType:'未填写'}}</p>
            </el-col>
          </el-row>

          <div class="grant">
            <p>
              <i>受款人帐户名称：</i>
              <span>FUHONGBO</span>
            </p>

            <p>
              <i>受款银行名称:</i>
              <span>Standard Chartered Bank Limited</span>
            </p>
            <p>
              <i>受款人帐户号码：</i>
              <span>*******4921</span>
            </p>

            <p>
              <i>受款银行ABA代码：</i>
              <span>SCBLHKHHXXX</span>
            </p>
            <p>
              <i>受款银行地址：</i>
              <span>4 DES VOEUX ROAD CENTRAL HONGKONG . HONGKONG , HONGKONG , 中国, 999077</span>
            </p>
            <p>电汇汇款将会收取美金/欧元/英镑50的费用并将从应支付的佣金里扣取。</p>
          </div>
        </el-collapse-item>
        <el-collapse-item title="文件上传" name="5">
          <template slot="title">
            <i class="header-icon el-icon-folder-add"></i>
            文件上传
          </template>
          <el-row>
            <el-col
              :span="24"
            >一旦公司收到您的协议/申请书，所有的资讯及相关文件将会被审核。公司会与您的办事处及直属主管以要求任何缺少、不完整或额外（若需要）、以及需要更正的资讯或文件。</el-col>
          </el-row>
          <div class="intro_news">
            <h3>身份证明文件</h3>
            <ul>
              <li v-for="(item,index) in idFiles" :key="index">{{item}}</li>
              <!-- <li>护照首页.PDF</li>
              <li>护照首页.PDF</li>-->
            </ul>
          </div>
          <div class="intro_news">
            <h3>住址证明文件</h3>
            <ul>
              <li>身份证付（1）.PDF</li>
              <li>身份证付（2）.PDF</li>
              <li>身份证付（3）.PDF</li>
            </ul>
          </div>
          <div class="intro_news">
            <h3>在金融行业的经历证明</h3>
            <ul>
              <li>XXX.jpg</li>
              <li>♂.jpg</li>
              <li>(￣▽￣)"".jpg</li>
            </ul>
          </div>
        </el-collapse-item>
        <el-collapse-item title="佣金阶级表" name="6">
          <template slot="title">
            <i class="header-icon el-icon-document"></i>
            佣金阶级表
          </template>
          <div class="intro_news">
            <h3>业绩标准与佣金阶级</h3>
            <p>MEME 履行此佣金阶级表的义务限于介绍人及其所管理之下阶介绍人总计达到以下最低业绩标准:</p>
            <p>
              <i style=" font-weight: 600;">合约年度标准:</i>
              <span>年度化业绩点数</span>
            </p>
            <p>此外，介绍人需确保其个人及其所管理之下阶介绍人，均达到MEME的续缴率标准。</p>
          </div>
          <div>
            <el-table
              :data="tableData"
              style="width: 100%"
              :default-sort="{prop: 'date', order: 'descending'}"
            >
              <el-table-column prop="date" label="计划种类" sortable width="180"></el-table-column>
              <el-table-column label="计划年期" width="180">
                <el-table-column prop="address" label="第一年" sortable :formatter="formatter"></el-table-column>
                <el-table-column prop="address" label="第二年" sortable :formatter="formatter"></el-table-column>
                <el-table-column prop="address" label="第三年" sortable :formatter="formatter"></el-table-column>
                <el-table-column prop="address" label="第四年" sortable :formatter="formatter"></el-table-column>
                <el-table-column prop="address" label="第五年" sortable :formatter="formatter"></el-table-column>
              </el-table-column>
            </el-table>
          </div>
        </el-collapse-item>
        <el-collapse-item title="历史记录" name="7">
          <template slot="title">
            <i class="header-icon el-icon-reading"></i>
            历史记录
          </template>
          <div>
            <el-table
              border
              :data="historyRecord"
              stripe
              style="width: 100%"
              :header-cell-style="{
              'background-color': '#DCDFE6',
              'height':'40px',
              'text-align':'center',
              }"
              :cell-style="{'text-align':'center',}"
            >
              <el-table-column prop="status" label="状态" width="180"></el-table-column>
              <el-table-column prop="detail" label="细节" width="180"></el-table-column>
              <el-table-column prop="data" label="日期及时间"></el-table-column>
              <el-table-column prop="user" label="使用者"></el-table-column>
            </el-table>
          </div>
        </el-collapse-item>
      </el-collapse>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="dialogVisible = false">取 消</el-button>
        <el-button size="small" type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getIntroducerUserList, getIntroducerUserDeatil } from "@/api";
export default {
  data() {
    return {
      activeNames: ["1"],
      dialogVisible: false,
      pageSize: 10, //每页显示数量
      pageNum: 1, //页数
      total: 0, //总条数
      tableData: [
        //邀请记录
        {
          ref_num: "2019-06-19", //邀请日期
          name: "ConWen（9527）", //邀请人
          introducer: "王杰", //受邀人
          doc_type: "已发送", //状态
          last_update: "2019-06-19 21:18", //最后更新时间
          status: "ConWen（9527）" //最后更新人
          // unread_msg: "未读消息"
        },
        {
          ref_num: "2019-06-20",
          name: "ConWen（9527）",
          introducer: "王楠",
          doc_type: "已发送",
          last_update: "2019-06-20 20:18",
          status: "ConWen（9527）"
          // unread_msg: "未读消息"
        }
      ],
      historyRecord: [
        //操作记录
        {
          status: "已建立", //状态 已建立 已发送 已开启 进行中 等待核准中 已提交
          detail: "邀请已建立", //细节
          data: "2019-08-08", //日期及时间
          user: "Shi Liu（564695）" //使用者
        }
      ],
      idFiles: ["护照首页.PDF", "港澳首页.PDF", "身份证首页.PDF"], //身份证明文件
      addressFlies: [], //住址证明文件
      bankFiles: [], //金融行业的经验证明文件
      //搜索选框测试数据
      formInline: {
        start_value: "", //邀请开始日期
        end_value: "", //终止日期
        name: "", //邀请人
        introducer: "", //受邀人
        status: "", //最后更新人
        start_update: "", //最后更新时间
        end_update: "", //最后更新时间
        doc_type: "" //状态
      },
      detailList: {} //每一条数据详情列表
    };
  },
  created() {
    this.initList();
  },
  methods: {
    //表头搜索提交按钮
    onSubmit(formName) {},
    //表头搜索重置按钮
    onReset(formName) {
      this.$refs[formName].resetFields();
    },
    //分页每页显示
    handleSizeChange(val) {
      // console.log(`每页 ${val} 条`);
      this.pageSize = val;
      // this.pageNum = 1;
      this.initList();
    },
    //分页显示当前页
    handleCurrentChange(val) {
      // console.log(`当前页: ${val}`);
      this.pageNum = val;
      this.initList();
    },
    // 初始化表格数据
    initList() {
      this.loading = true;
      getIntroducerUserList({
        params: {
          // id: 1,//传直属主管id
          directManager: parseInt(window.localStorage.getItem("IntroducerId")),
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      }).then(res => {
        this.tableData = res.dataList;
        this.pageSize = res.myPageInfo.pageSize; //每页显示数量
        this.pageNum = res.myPageInfo.currentPage; //页数
        this.total = res.myPageInfo.total; //总条数
        this.loading = false;
      });
    },
    //点击折叠版
    handleChange(val) {
      // console.log(val);
    },
    //表格数据过滤（备用）
    formatter(row, column) {
      return row.address;
    },
    //查看详细
    showEditDialog(row) {
      getIntroducerUserDeatil({
        params: {
          id: row.introducerId
        }
      }).then(res => {
        this.detailList = res.data;
      });
      this.dialogVisible = true;
    },
    //关闭弹框
    handleClose() {
      this.dialogVisible = false;
    }
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    .demo-form-inline {
      .el-form-item {
        .el-input {
          width: 160px;
        }
      }
    }
  }
  .mm_table {
    margin-top: 10px;
  }
}
.el-row {
  margin-bottom: 5px;
  &:last-child {
    margin-bottom: 0;
  }
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
.line {
  width: 99%;
  height: 1px;
  background-color: #ccc;
}
.other_news {
  font-weight: 600;
}
.intro_news {
  h3,
  h4 {
    font-weight: 600;
  }
}
.grant > p > i {
  font-weight: 600;
}
</style>
