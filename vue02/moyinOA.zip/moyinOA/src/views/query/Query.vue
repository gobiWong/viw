<template>
  <div class="query">
    <p>请选择查询:</p>
    <el-select v-model="querySelectValue" placeholder="请选择" size="small" @change="test">
      <el-option label="代理人" value="代理人"></el-option>
      <el-option label="计划" value="计划"></el-option>
      <el-option label="帐户" value="帐户"></el-option>
    </el-select>
    <!-- <el-button @click="test">查询</el-button> -->
    <p>结果</p>
    <div class="query_result">
      <div v-if="agent" class="result_item">
        <h3>代理人结果</h3>
        <el-table
          :data="agentResult"
          stripe
          style="width: 100%"
          border
          :header-cell-style="{'background-color': '#DCDFE6', 'height':'40px','text-align':'center', }"
          :cell-style="{	'text-align': 'center',}"
        >
          <el-table-column prop="date" label="代理人代码" width="120"></el-table-column>
          <el-table-column prop="money" label="代理人姓名" width="120"></el-table-column>
          <el-table-column prop="last_balance" label="状态"></el-table-column>
          <el-table-column prop="quota" label="核准日期" width="180"></el-table-column>
          <el-table-column prop="adjust" label="终止日期" width="180"></el-table-column>
          <el-table-column prop="summary" label="直属主管代码"></el-table-column>
          <el-table-column prop="current_balance" label="直属主管姓名"></el-table-column>
        </el-table>
      </div>
      <div v-if="plan" class="result_item">
        <h3>计划结果</h3>
        <el-table
          :data="planResult"
          stripe
          style="width: 100%"
          border
          :header-cell-style="{'background-color': '#DCDFE6', 'height':'40px','text-align':'center', }"
          :cell-style="{	'text-align': 'center',}"
        >
          <el-table-column prop="date" label="计划号码" width="180"></el-table-column>
          <el-table-column prop="money" label="次数" width="120"></el-table-column>
          <el-table-column prop="last_balance" label="保单持有人姓名"></el-table-column>
          <el-table-column prop="quota" label="状态" width="120"></el-table-column>
          <el-table-column prop="adjust" label="产品" width="180"></el-table-column>
          <el-table-column prop="summary" label="生效日期"></el-table-column>
          <el-table-column prop="summary" label="目前供款日期至"></el-table-column>
          <el-table-column prop="current_balance" label="已供款金额"></el-table-column>
          <el-table-column prop="current_balance" label="账户价值"></el-table-column>
        </el-table>
      </div>
      <div v-if="account" class="result_item">
        <h3>账户结果</h3>
        <el-table
          :data="accountResult"
          stripe
          style="width: 100%"
          border
          :header-cell-style="{'background-color': '#DCDFE6', 'height':'40px','text-align':'center', }"
          :cell-style="{	'text-align': 'center',}"
        >
          <el-table-column prop="date" label="代理人代码" width="120"></el-table-column>
          <el-table-column prop="money" label="代理人名字" width="120"></el-table-column>
          <el-table-column prop="last_balance" label="账户号码"></el-table-column>
          <el-table-column prop="quota" label="账户持有人姓名" width="180"></el-table-column>
          <el-table-column prop="adjust" label="状态" width="180"></el-table-column>
          <el-table-column prop="summary" label="产品"></el-table-column>
          <el-table-column prop="current_balance" label="生效日期"></el-table-column>
          <el-table-column prop="current_balance" label="关闭日期"></el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      querySelectValue: "",
      agent: false,
      plan: false,
      account: false,
      agentResult: [
        {
          date: "ADC258",
          money: "王花花",
          last_balance: "执行中",
          quota: "2016-05-02",
          adjust: "2016-05-02",
          summary: "WJN54852",
          current_balance: "ChrisNan",
          status: "打开"
        },
        {
          date: "Top147",
          money: "张小兵",
          last_balance: "审核中",
          quota: "2016-05-02",
          adjust: "2017-05-02",
          summary: "YWY250c",
          current_balance: "Wuyang",
          status: "关闭"
        }
      ], //代理人结果数据
      planResult: [
        {
          date: "9527ACML",
          money: "主计划",
          last_balance: "德贤",
          quota: "执行中",
          adjust: "德马西亚投资组合",
          summary: "2020-02-02",
          current_balance: "998.00",
          status: "打开"
        },

        {
          date: "GC007WX",
          money: "附加计划",
          last_balance: "张标",
          quota: "审核中",
          adjust: "弗雷尔卓德单品",
          summary: "2020-02-02",
          current_balance: "666.00",
          status: "关闭"
        }
      ], //计划结果数据
      accountResult: [
        {
          date: "ADC258",
          money: "王花花",
          last_balance: "ADWD25523265565656",
          quota: "HUAHUA",
          adjust: "关闭/生效/审核中",
          summary: "艾欧尼亚哦组合",
          current_balance: "2019-09-09",
          status: "打开"
        },

        {
          date: "Top147",
          money: "张小兵",
          last_balance: "ZXB25648745652656",
          quota: "xiaobing",
          adjust: "关闭/生效/审核中",
          summary: "洛克萨斯双线组合",
          current_balance: "2018-08-08",
          status: "关闭"
        }
      ] //账户结果数据
    };
  },
  methods: {
    test() {
      if (this.querySelectValue === "") {
        this.agent = false;
        this.plan = false;
        this.account = false;
        return;
      }

      if (this.querySelectValue === "代理人") {
        this.agent = true;
        this.plan = false;
        this.account = false;
        this.querySelectValue === "";
      } else if (this.querySelectValue === "计划") {
        this.plan = true;
        this.agent = false;
        this.account = false;
        this.querySelectValue === "";
      } else {
        this.account = true;
        this.agent = false;
        this.plan = false;
        this.querySelectValue === "";
      }
    }
  }
};
</script>
<style lang="less" scoped>
.query {
  p {
    margin-left: 10px;
    line-height: 30px;
  }
  .query_result {
    width: 99%;
    height: 600px;
    background-color: #fff;
    padding: 8px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    border: 1px solid #ebeef5;
    .result_item {
      h3 {
        color: dimgray;
        margin: 20px;
      }
    }
  }
}
</style>
