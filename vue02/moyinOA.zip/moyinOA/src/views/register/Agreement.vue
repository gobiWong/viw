
<template>
  <el-card class="box-card loginCode">
    <div slot="header" class="clearfix">
      <span>MEME系统</span>
    </div>
    <div class="loginCode_con">
      <h3>欢迎您</h3>
      <p>您已收到申请成为模因介绍人的邀请</p>
      <p>请选择获取登入码的方式，以便让您可登入电子协议/申请书并开始注册程序</p>
    </div>
    <hr class="split-line">
    <div  class="loginCode_sub">
      <el-form :model="loginCodeForm" class="demo-ruleForm">
        <!-- <el-checkbox label="同意遵守申请条款与须知，并进入电子协议/申请书"></el-checkbox> -->
        <el-radio v-model="radio" label="2" disabled>发送登入码至我的行动电话</el-radio>
        <br>
        <el-radio v-model="radio" label="1">我有登入码</el-radio>
        <el-form-item>
          <el-button type="primary" size="small" @click="onSubmit">提交</el-button>
          <el-button type="info" plain size="small">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-card>
</template>
<script>
export default {
  data() {
    return {
      radio: "1",
      loginCodeForm: {}
    };
  },
  methods: {
    onSubmit() {
      console.log("submit!");
   
      // console.log(this.$route.query.id)

      this.$router.push({
        name: "GetCode",
        params: {
          id: this.$route.query.id
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.loginCode{
    .loginCode_con{
        height: 320px;
        text-align: center;
        h3{
          font-size: 28px;
        }
        p{
          font-size: 18px;
          line-height:30px;
        }
    }
    .loginCode_sub{
        height: 200px;
    }
}
</style>
