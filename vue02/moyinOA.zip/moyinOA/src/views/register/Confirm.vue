<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix" id="confirm">
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="介绍人类别" name="first">介绍人类别</el-tab-pane>
        <el-tab-pane label="受益人" name="second">受益人</el-tab-pane>
        <el-tab-pane label="合约总览" name="third">合约总览</el-tab-pane>
        <el-tab-pane label="佣金发放资讯" name="fourth">佣金发放资讯</el-tab-pane>
        <el-tab-pane label="介绍人资讯" name="fifth">介绍人资讯</el-tab-pane>
        <el-tab-pane label="上传文件" name="sixth">上传文件</el-tab-pane>
        <el-tab-pane label="结果" name="seventh">结果</el-tab-pane>
      </el-tabs>
    </div>
    <div class="confirm_view">
      <router-view></router-view>
    </div>
  </el-card>
</template>

<script>
export default {
  data() {
    return {
      activeName: ""
    };
  },
  watch: {
    $route(to, from) {
     
      if (to.name === "Introtype") {
        this.activeName = "first";
      } else if (to.name === "RegBeneficiary") {
        this.activeName = "second";
      } else if (to.name === "Contracts") {
        this.activeName = "third";
      } else if (to.name === "GrantInfo") {
        this.activeName = "fourth";
      } else if (to.name === "IntroInfo") {
        this.activeName = "fifth";
      } else if (to.name === "UploadFile") {
        this.activeName = "sixth";
      } else if (to.name === "Infosure") {
        this.activeName = "seventh";
      }
    },
    $route: {
      handler(newRouter) {
        if (newRouter.name === "Introtype") {
          this.activeName = "first";
        } else if (newRouter.name === "RegBeneficiary") {
          this.activeName = "second";
        } else if (newRouter.name === "Contracts") {
          this.activeName = "third";
        } else if (newRouter.name === "GrantInfo") {
          this.activeName = "fourth";
        } else if (newRouter.name === "IntroInfo") {
          this.activeName = "fifth";
        } else if (newRouter.name === "UploadFile") {
          this.activeName = "sixth";
        } else if (newRouter.name === "Infosure") {
          this.activeName = "seventh";
        }
      },
      immediate: true
    }
  },
  computed: {
    // breadNav () {
    //   return this.$route.meta.title
    // }
  },

  methods: {
    handleClick(tab, event) {
      if (tab.name === "first") {
        this.$router.push({
          name: "Introtype",
          params: {
            id: this.$route.params.id
          }
        });
      } else if (tab.name === "second") {
        this.$router.push({
          name: "RegBeneficiary",
          params: {
            id: this.$route.params.id
          }
        });
      } else if (tab.name === "third") {
        this.$router.push({
          name: "Contracts",
          params: {
            id: this.$route.params.id
          }
        });
      } else if (tab.name === "fourth") {
        this.$router.push({
          name: "GrantInfo",
          params: {
            id: this.$route.params.id
          }
        });
      } else if (tab.name === "fifth") {
        this.$router.push({
          name: "IntroInfo",
          params: {
            id: this.$route.params.id
          }
        });
      } else if (tab.name === "sixth") {
        this.$router.push({
          name: "UploadFile",
          params: {
            id: this.$route.params.id
          }
        });
      } else if (tab.name === "seventh") {
        this.$router.push({
          name: "Infosure",
          params: {
            id: this.$route.params.id
          }
        });
      }
    }
  }
};
</script>
<style lang="less" scoped>
.box-card {
  .el-card__body {
    padding: 5px;
  }
  #confirm {
    //  background-color: #ccc;
    .el-breadcrumb {
      font-size: 20px;
    }
  }
  .confirm_view {
    height: 700px;
    overflow: auto;
  }
}
</style>
