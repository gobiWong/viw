<template>
  <el-card class="box-card getCode">
    <div slot="header" class="clearfix">
      <span></span>
    </div>
    <div class="getCode_con">
      <p>行动电话号码验证</p>
      <p>请输入在邀请邮件内所提供的行动电话后四码，视您的电信业者而定，您可能需要支付这则简讯的费用/申请书并开始注册程序</p>
      <div class="tel">
        <!-- <span class="code-box">
          <input type="text" :autoFocus="true" v-model="inputList.val1" maxlength="1" />
          <input type="text" :autoFocus="true" v-model="inputList.val2" maxlength="1" />
          <input type="text" :autoFocus="false" v-model="inputList.val3" maxlength="1" />
          <input type="text" :autoFocus="false" v-model="inputList.val4" maxlength="1" />
          <input type="text" :autoFocus="false" v-model="inputList.val5" maxlength="1" />
          <input type="text" :autoFocus="false" v-model="inputList.val6" maxlength="1" />
        </span>-->
        <div class="code-input-main">
          <span class="code-input-main-item">{{code[0]}}</span>
          <div class="line1 line"></div>
          <div class="line2 line"></div>
          <div class="line3 line"></div>
          <div class="line4 line"></div>
          <div class="line5 line"></div>
          <div class="line6 line"></div>
          <span class="code-input-main-item">{{code[1]}}</span>
          <span class="code-input-main-item">{{code[2]}}</span>
          <span class="code-input-main-item">{{code[3]}}</span>
          <span class="code-input-main-item">{{code[4]}}</span>
          <span class="code-input-main-item">{{code[5]}}</span>
        </div>

        <input
          :autoFocus="focus"
          class="code-input-input"
          v-model="code"
          maxlength="6"
          oninput="value=value.replace(/[^\d]/g,'')"
          @keydown.enter="onSubmit()"
        />
      </div>
    </div>
    <hr class="split-line" />
    <div class="getCode_sub">
      <el-form :model="getCodeForm" class="demo-ruleForm">
        <el-form-item>
          <el-button type="primary" size="small" @click="onSubmit">提交</el-button>
          <el-button type="info" plain size="small" @click="onCanel">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-card>
</template>
<script>
import { checkCode } from "@/api";

export default {
  data() {
    return {
      radio: "1",
      inputList: {
        val1: "",
        val2: "",
        val3: "",
        val4: "",
        val5: "",
        val6: ""
      },
      value: "",
      code: [],
      focus: true,
      getCodeForm: {}
    };
  },
  watch: {
    $route(to, from) {
      console.log(to, "2123");
      // if (from.path === "/welcome") {
      //   this.$message({
      //     message: "请先通过测评！",
      //     type: "warning",
      //     duration: 2000
      //   });
      //   this.$router.push({ path: "/welcome" });
      //   if (from.path === "/welcome" && to.path === "/success") {
      //     this.$message({
      //       message: "测评已通过，欢迎回来！",
      //       type: "success",
      //       offset: 4.5
      //     });
      //     this.$router.push({ path: "/success" });
      //   }
      // }
    }
    // if(from.path==='/success/:status'){
    // // this.$message({
    // //       message: '请先通过测评！',
    // //       type: 'warning'
    // //     });
    // this.$router.push({ path:'/success/:status' });
    // }
  },
  directives: {
    autoFocus: {
      // 钩子函数，被绑定元素插入父节点时调用 (父节点存在即可调用，不必存在于 document 中)。
      inserted(el) {
        el.focus();
      }
    }
  },

  methods: {
    onSubmit() {
      console.log(this.code);
      if (this.code.length != 6) {
        this.$message({
          type: "info",
          message: "请填写验证码"
        });
        return;
      }

      // var total = { ...this.inputList, val1: this.inputList.val1 };

      // var codeStr = "";
      // for (let i in total) {
      //   var codeStr = (total[i] += codeStr);
      //   var code = codeStr
      //     .split("")
      //     .reverse()
      //     .join("");
      // }

      // if (code.length != 6) {
      //   this.$message({
      //     type: "info",
      //     message: "请填写验证码"
      //   });
      //   return;
      // }


      checkCode({
        params: { id: parseInt(this.$route.params.id), code:this.code}
      }).then(res => {
        if (res.success) {
          this.$message({
            type: "success",
            message: res.message
          });
          this.$router.push({
            name: "LoginCode",
            params: {
              id: this.$route.params.id,
              code: this.code
            }
          });
        } else {
          this.$message({
            type: "warning",
            message: res.message
          });
        }
      });
    },
    onCanel() {
      this.$router.push({
        name: "register",
        params: {
          id: this.$route.params.id
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.getCode {
  .getCode_con {
    text-align: center;
    padding: 70px 0;
    color: #333;
    .tel {
      position: relative;
      padding: 60px 0;
      font-size: 18px;
      .code-box > input {
        width: 50px;
        height: 24px;
        margin: 10px 6px;
        border: none;
        border-bottom: 1px solid #ccc;
        text-align: center;
      }
    }
  }
  .code-input-main {
    position: relative;
    .code-input-main-item {
      display: inline-block;
      width: 40px;
      opacity: 0;
      box-sizing: border-box;
      // border-bottom: 1px solid #ccc;
    }
    .line {
      position: absolute;
      width: 33px;
      height: 2px;
      top: 20px;

      background-color: #ccc;
    }
    .line1 {
      left: 430px;
    }
    .line2 {
      left: 480px;
    }
    .line3 {
      left: 530px;
    }
    .line4 {
      left: 580px;
    }
    .line5 {
      left: 630px;
    }
    .line6 {
      left: 680px;
    }
    span::after {
      display: block;
      position: absolute;
      width: 21px;
      height: 1px;

      top: 80px;
      background-color: aqua;
      content: "";
    }
  }
  // .input_div{
  //    width: 300px;
  //     position: absolute;
  //   box-sizing: border-box;
  //   top: 50px;
  //   left: 430px;
  //   overflow: hidden;

  //   height: 30px;
  // }
  .code-input-input {
    position: absolute;
    box-sizing: border-box;
    top: 50px;
    left: 430px;
    width: 330px;
    height: 30px;
    caret-color: rgb(146, 150, 155);
    // opacity: 0;;
    padding-left: 15px;
    font-size: 30px;
    letter-spacing: 31px;
    //  text-indent: -1em;
    border: none;

    background: none;
    outline: none;
    border: 0px;
  }
  .getCode_sub {
    height: 200px;
  }
}
</style>
