<template>
  <div class="contracts">
    <div>
      <el-row>
        <el-col :span="24">
          <h2>地区</h2>
          <p>请填写介绍人计划发展业务的区域（输入一个或多个国家）</p>
        </el-col>
      </el-row>
    </div>
    <el-form>
      <el-form-item label="请输入" prop="staffTrueEmail">
        <el-select v-model="value1" multiple placeholder="请选择" style="width:600px">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
    </el-form>

    <el-row>
      <el-col :span="24">
        <h2>直属主管</h2>
        <p>{{totalName}}</p>
        <div v-if="totalAddress">
          <h2>介绍人办事处</h2>
        <p>{{totalAddress}}</p>
        </div>
        
      </el-col>
    </el-row>
    <el-button type="info" size="small" @click="$router.push({name:'RegBeneficiary'})">上一步</el-button>
    <el-button type="primary" size="small" @click="onSubmit">下一步</el-button>
  </div>
</template>

<script>
import {queryAddress,getIntroducerUserDeatil} from '@/api'
export default {
  data() {
    return {
      radio: "1",
      activeName: "1",
      options: [
        {
          value: "中国",
          label: "中国"
        },
        {
          value: "美国",
          label: "美国"
        },
        {
          value: "俄罗斯",
          label: "俄罗斯"
        },
        {
          value: "印度",
          label: "印度"
        },
        {
          value: "日本",
          label: "日本"
        }
      ],
      value1: [],
      value2: [],
      totalName:'',
      totalAddress:''
    };
  },
  mounted(){
    // queryAddress({params:{id:this.$route.params.id}}).then(res => {
    //   console.log(res)
    //    if(res.success){
    //      this.totalName=res.total
    //     //  this.totalAddress=res.data.addressCountry+res.data.addressProvince+res.data.addressCity+res.data.addressDistrict+res.data.addressDetailed
    //    }
    //   });
        getIntroducerUserDeatil({
        params: { id: this.$route.params.id }
      }).then(res => {
        console.log(res);
        if (res.success) {
          this.totalName = res.data.directManager
          // this.loading = false;
        }
      });
  },

  methods: {
    onSubmit() {
     
      if(this.value1.length==0){
         this.$message({
          message: '请填写完整信息',
          type: 'warning'
        });
      }else{
        //发请求保存数据，跳转路由
          this.$router.push({
        name: "GrantInfo",
        params: {
         id: this.$route.params.id
        }
      });
      }

    
    }
  }
};
</script>

<style lang="less" scoped>
.contracts {
  font-size: 18px;
  // text-align: center;
  line-height: 38px;
}
</style>
