<template>
  <div class="grantInfo" v-loading="loading">
    <el-form
      :model="addForm"
      label-width="auto"
      :rules="rules"
      ref="addIntroducerForm"
      size="small"
    >
      <span>佣金发放频率</span>
      <el-form-item label-width="0" prop="period" style="width:300px">
        <el-select v-model="addForm.period" placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <span>佣金发放币别</span>
      <el-form-item label-width="0" prop="currency" style="width:300px">
        <el-select v-model="addForm.currency" placeholder="请选择">
          <el-option
            v-for="item in options1"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <span>佣金发放方式</span>
      <el-form-item label-width="0" prop="grantType" style="width:300px">
        <el-select v-model="addForm.grantType" placeholder="请选择">
          <el-option
            v-for="item in options2"
            :key="item.value"
            :label="item.label"
            :value="item.value"
            :disabled="item.disabled"
          ></el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <!-- 佣金转让弹框 -->
    <el-dialog :visible.sync="commissionTransfer" width="80%" top="5vh">
      <el-form :model="commissionTransferForm" :inline="true">
        <p>佣金装让资讯</p>
        <el-form-item label="受让人的介绍人代码" :label-width="formLabelWidth">
          <el-input
            size="small"
            v-model="commissionTransferForm.transferIntroducer"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="受让人的介绍人姓名" :label-width="formLabelWidth">
          <el-input
            size="small"
            v-model="commissionTransferForm.transferIntroducerName"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <div>
          <p>佣金转让的一般资讯</p>
          <ul>
            <li>介绍人在此事吗以下事项：</li>
            <li>1.介绍人在//////////////</li>
            <li>2.介绍人在此授权/////////////</li>
            <li>3.终止此协议/////////////</li>
            <li>4.此协议对介绍人及其继承人////////</li>
            <li>5.此协议在MEME////////</li>
            <li>6.介绍人同意此//////////////////////////////////////</li>
            <li>7.介绍人与受人之间的///////////////</li>
          </ul>
        </div>
        <p>佣金发放最低金额</p>
        <el-form-item :label-width="formLabelWidth">
          <el-input
            size="small"
            v-model.number="commissionTransferForm.minimumAmount"
            autocomplete="off"
            placeholder="￥0.00"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="commissionTransfer = false">取 消</el-button>
        <el-button size="small" type="primary" @click="commissionTransferConfirm">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 电汇资讯 -->
    <el-dialog :visible.sync="wireTransfer" width="80%" top="5vh">
      <el-form :model="wireTransferForm" :inline="true">
        <p>电汇资讯</p>
        <el-form-item label="受人人的介绍人代码" :label-width="formLabelWidth">
          <el-input size="small" v-model="wireTransferForm.transferIntroducer" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="受让人的介绍人姓名" :label-width="formLabelWidth">
          <el-input size="small" v-model="wireTransferForm.transferIntroducerName" autocomplete="off"></el-input>
        </el-form-item>
        <div>
          <p>佣金转让的一般资讯</p>
          <ul>
            <li>介绍人在此事吗以下事项：</li>
            <li>1.介绍人在//////////////</li>
            <li>2.介绍人在此授权/////////////</li>
          </ul>
        </div>
        <p>佣金发放最低金额</p>
        <el-form-item :label-width="formLabelWidth">
          <el-input
            size="small"
            v-model.number="wireTransferForm.minimumAmount"
            autocomplete="off"
            placeholder="￥0.00"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="wireTransfer = false">取 消</el-button>
        <el-button size="small" type="primary" @click="wireTransferConfirm">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 银行自动转账 -->
    <el-dialog :visible.sync="bankAutopay" width="80%" top="5vh">
      <el-form :model="bankAutopayForm" :inline="true">
        <p>银行自动转账</p>
        <el-form-item label="银行类别" :label-width="formLabelWidth">
          <el-select v-model="bankAutopayForm.grantType" placeholder="类别">
            <el-option
              v-for="item in bankTypes"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="账户号码" :label-width="formLabelWidth">
          <el-input size="small" v-model="bankAutopayForm.bankNumber" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="美国境内银行ABA号码" :label-width="formLabelWidth">
          <el-input size="small" v-model="bankAutopayForm.bankAba" autocomplete="off"></el-input>
        </el-form-item>
        <div>
          <p>一般资讯</p>
          <ul>
            <li>除非另有书面同意已被MEME核准，佣金仅会根据</li>
            <li>1.介绍人在//////////////</li>
          
          </ul>
        </div>
        <p>佣金发放最低金额</p>
        <el-form-item :label-width="formLabelWidth">
          <el-input
            size="small"
            v-model.number="bankAutopayForm.bankMinimumAmount"
            autocomplete="off"
            placeholder="￥0.00"
          ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="bankAutopay = false">取 消</el-button>
        <el-button size="small" type="primary" @click="bankAutopayConfirm">确 定</el-button>
      </div>
    </el-dialog>

    <el-button type="info" size="small" @click="$router.push({name:'Contracts'})">上一步</el-button>
    <el-button type="primary" size="small" @click="onSubmit">下一步</el-button>
  </div>
</template>

<script>
import {
  addCommissionTransfer, //添加佣金转让接口
  addBankAutopay, //添加银行自动转账接口
  addWireTransfer, //添加电汇转账接口
  getDeatilByIntroducerId, //通过介绍人id查询佣金转让信息接口
  UpdateIntroducerUser //更新修改并保存数据接口
} from "@/api";

export default {
  data() {
    return {
      radio: "1",
      activeName: "1",
      loading: false,
      rules: {},
      commissionTransfer: false, //佣金转让弹框开关
      wireTransfer: false, //电汇弹框开关
      bankAutopay: false, //银行自动转账开关
      commissionTransferForm: {
        transferIntroducer: "", //受让人的介绍人代码
        transferIntroducerName: "", //受让人的介绍人姓名
        minimumAmount: "" //佣金发放最低金额
      }, //佣金转让表单数据

      wireTransferForm: {
        accountHolderName: "", //账户持有人姓名
        recipientBankName: "", //收款银行名称
        recipientBankNumber: "", //收款人账户号码
        recipientBankAba: "", //收款银行ABA码
        recipientBankSwift: "", //收款银行SWIFT码
        recipientBankIban: "", //收款银行IBAN码
        recipientBankCode: "", //收款银行银行区号
        recipientBankAddressone: "", //收款银行地址第一行
        recipientBankAddresstwo: "", //收款银行地址第二行
        recipientBankCity: "", //收款银行地址市
        recipientBankProvince: "", //收款银行地址省
        recipientBankCountry: "", //收款银行地址国家
        recipientBankPostal: "", //收款银行邮政编码
        recipientBankRemark: "", //收款银行备注
        minimumAmount: "" //佣金最低发放金额
      }, //电汇表单数据

      bankAutopayForm: {
        bankType: "", //银行类别
        bankNumber: "", //账户号码
        bankAba: "", //美国境内银行ABA号码
        bankMinimumAmount: "" //佣金发放最低金额
      }, //银行自动转账表单数据

      introducerId: "", //介绍人id
      formLabelWidth: "140px",

      addForm: {
        period: "", //周期
        currency: "", //币种
        grantType: "" //佣金发放方式
      },
      options: [
        {
          value: 1,
          label: "每周"
        },
        {
          value: 2,
          label: "每两周"
        },
        {
          value: 3,
          label: "每月"
        },
        {
          value: 4,
          label: "每季"
        },
          {
          value: 5,
          label: "每半年"
        },
        {
          value: 6,
          label: "每年"
        }
      ], //周期选框
      options1: [
        {
          value: 1,
          label: "人民币"
        },
        {
          value: 2,
          label: "美元"
        },
        {
          value: 3,
          label: "日元"
        }
      ], //币种选框
      options2: [
        {
          value: 1,
          label: "佣金转让"
        },
        {
          value: 2,
          label: "电汇",
          disabled: true
        },
        {
          value: 3,
          label: "银行自动转帐存入美国境内银行帐户",
          disabled: true
        }
      ], //佣金发放方式选框
      bankTypes: [
        {
          value: "支票账户",
          label: "支票账户"
        },
        {
          value: "储蓄账户",
          label: "储蓄账户",
          disabled: true
        },
        {
          value: "信用卡账户",
          label: "信用卡账户",
          disabled: true
        }
      ] //银行类别
    };
  },
  // created() {
  //   this.initList();
  // },
  methods: {
    // 初始化表格数据
    // initList() {
    //   this.loading = true;
    //   getDeatilByIntroducerId({
    //     params: {
    //       id: this.$route.params.id
    //       //   pagenum: this.pagenum,
    //       //   pagesize: this.pagesize
    //     }
    //   }).then(res => {
    //     console.log(res);
    //     // this.dataBase = res;
    //     // this.total = res.data.total
    //     this.loading = false;
    //   });
    // },

    onSubmit() {
      // this.$router.push({
      //   name: "IntroInfo",
      //   params: {
      //     //  id: this.$route.params.id
      //   }
      // });
      if (
        this.addForm.period == "" ||
        this.addForm.currency == "" ||
        this.addForm.grantType == ""
      ) {
        this.$message({
          message: "请填写完整信息",
          type: "warning"
        });
        return;
      }
      //调用更新接口保存数据
      UpdateIntroducerUser({
        ...this.addForm,
        introducerId: this.$route.params.id
      }).then(res => {
        console.log(res);
      });

      console.log(this.addForm);

      if (this.addForm.grantType == 1) {
        this.commissionTransfer = true;
      } else if (this.addForm.grantType == 2) {
        // console.log("弹出电汇资料框");
        this.wireTransfer = true;
      } else if (this.addForm.grantType == 3) {
        // console.log("弹出银行自动转帐存入美国境内银行帐户资料框");
        this.bankAutopay = true;
      }
    },
    //佣金转让确定
    commissionTransferConfirm() {
      // console.log({
      //   ...this.addForm,
      //   ...this.form,
      //   introducerId: this.$route.params.id
      // });

      if (
        this.commissionTransferForm.transferIntroducer == "" ||
        this.commissionTransferForm.transferIntroducerName == "" ||
        this.commissionTransferForm.minimumAmount == ""
      ) {
        this.$message({
          message: "请填写完整信息",
          type: "warning"
        });
      } else {
        //发请求保存数据，并跳转下一页
        addCommissionTransfer({
          ...this.commissionTransferForm,
          introducerId: this.$route.params.id
        }).then(res => {
          console.log(res);
          if (res.success) {
            this.$message({
              message: res.message,
              type: "success"
            });
            this.$router.push({
              name: "IntroInfo",
              params: {
                //  id: this.$route.params.id
              }
            });
          }
          this.commissionTransfer = false;
          // console.log(res)
        });
      }
    },
    //电汇确定
    wireTransferConfirm() {
      // console.log({
      //   ...this.addForm,
      //   ...this.form,
      //   introducerId: this.$route.params.id
      // });

      if (
        this.wireTransferForm.transferIntroducer == "" ||
        this.wireTransferForm.transferIntroducerName == "" ||
        this.wireTransferForm.minimumAmount == ""
      ) {
        this.$message({
          message: "请填写完整信息",
          type: "warning"
        });
      } else {
        //发请求保存数据，并跳转下一页
        addWireTransfer({
          ...this.wireTransferForm,
          introducerId: this.$route.params.id
        }).then(res => {
          console.log(res);
          if (res.success) {
            this.$message({
              message: res.message,
              type: "success"
            });
            this.$router.push({
              name: "IntroInfo",
              params: {
                //  id: this.$route.params.id
              }
            });
          }
          this.commissionTransfer = false;
          // console.log(res)
        });
      }
    },

    //银行自动转账确定
    bankAutopayConfirm() {
      // console.log({
      //   ...this.addForm,
      //   ...this.form,
      //   introducerId: this.$route.params.id
      // });

      if (
         this.bankAutopayForm.bankType == "" ||
        this.bankAutopayForm.bankNumber == "" ||
        this.bankAutopayForm.bankAba == "" ||
        this.bankAutopayForm.bankMinimumAmount == ""
      ) {
        this.$message({
          message: "请填写完整信息",
          type: "warning"
        });
      } else {
        //发请求保存数据，并跳转下一页
        addBankAutopay({
          ...this.bankAutopayForm,
          introducerId: this.$route.params.id
        }).then(res => {
          console.log(res);
          if (res.success) {
            this.$message({
              message: res.message,
              type: "success"
            });
            this.$router.push({
              name: "IntroInfo",
              params: {
                //  id: this.$route.params.id
              }
            });
          }
          this.commissionTransfer = false;
          // console.log(res)
        });
      }
    }
  }
};
</script>
<style lang="less" scoped>
.grantInfo {
  font-size: 18px;
  // text-align: center;
  line-height: 48px;
}
</style>
