<template>
  <el-card class="box-card" style="width:96%" v-loading="loading">
    <div v-if="flag" class="info_content">
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>姓名</h3>
            <p>{{this.dataList.name}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple-light">
            <h3>性别</h3>
            <p>{{this.dataList.beneficiarySex}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>出生日期</h3>
            <p>{{this.dataList.beneficiaryBirthday}}</p>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>邮箱</h3>
            <p>{{this.dataList.beneficiaryEmail}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple-light">
            <h3>身份证</h3>
            <p>{{this.dataList.certificateNumber}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>电话</h3>
            <p>{{this.dataList.phone}}</p>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>国籍</h3>
            <p>{{this.dataList.countryId | COUNTRY}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple-light">
            <h3>行业</h3>
            <p>{{this.dataList.profession}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>职位</h3>
            <p>{{this.dataList.job}}</p>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>直属主管</h3>
            <p>{{this.dataList.directManagerName}}</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple-light">
            <h3>职位工作年限</h3>
            <p>{{this.dataList.workingYears}}年</p>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <h3>阶级</h3>
            <p>{{this.dataList.level}}</p>
          </div>
        </el-col>
      </el-row>

      <el-button type="info" size="small" @click="$router.push({name:'UploadFile'})">上一步</el-button>
      <el-button type="primary" size="small" @click="confirmSubmit">确认</el-button>
    </div>
    <div v-if="!flag" class="info_tips">
      <p>您的系统账号和初始密码已发至邮箱,请妥善保管,登入系统可以修改您的安全密码！</p>
      <div>
        <el-button type="success" round plain size="mini" @click="gotoLogin">确认登入管理系统</el-button>
      </div>
    </div>
  </el-card>
</template>
 <script>
import { getIntroducerUserList, createUser, queryAddress,getIntroducerUserDeatil } from "@/api";
export default {
  data() {
    return {
      loading: true,
      id: "",
      flag: true,
      dataList: [], //个人信息
      totalName: "" //直属主管
    };
  },
  created() {
    queryAddress({ params: { id: this.$route.params.id } }).then(res => {
      if (res.success) {
        console.log(res)
        this.totalName = res.total;
      }
    });
  },
  mounted() {
    this.initList();
  },

  methods: {
    // 初始化表格数据
    initList() {
      this.loading = true;
      getIntroducerUserDeatil({
        params: { id: this.$route.params.id }
      }).then(res => {
        console.log(res);
        if (res.success) {
          this.dataList = res.data
          this.loading = false;
        }
      });
    },
    confirmSubmit() {
      console.log(this.dataList);
      if (
        this.dataList.name == "" ||
        this.dataList.beneficiarySex == "" ||
        this.dataList.beneficiaryBirthday == "" ||

        this.dataList.beneficiaryEmail == "" ||
        this.dataList.certificateNumber == "" ||
        this.dataList.countryId == "" ||

        this.dataList.profession == "" ||
        this.dataList.job == "" ||
        this.dataList.directManagerName  == "" ||

        this.dataList.workingYears == "" ||
        this.dataList.level == "" ||
        this.dataList.phone == ""
      ) {
        this.$message({
              type: "info",
              message: "请先填写完整信息！"
            });
            return
      }
      this.$confirm("请确认信息无误", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        callback: action => {
          if (action === "confirm") {
            this.$message({
              type: "success",
              message: "保存成功!"
            });
            this.flag = false;
            createUser({
              params: { id: this.$route.params.id }
            }).then(res => {});
          } else {
            this.$message({
              type: "info",
              message: "已取消！"
            });
          }
        }
      });
    },
    gotoLogin() {
      setTimeout(() => {
        this.$router.replace({ path: "/Login" });
      }, 3000);
    }
  }
};
</script>

 <style lang="less" scoped>
.text {
  font-size: 14px;
}

.item {
  padding: 18px 0;
}

.box-card {
  margin-top: 10px;
  width: 480px;
  .info_content {
    margin-top: 10px;
  }
}
.el-row {
  margin-bottom: 20px;
  &:last-child {
    margin-bottom: 0;
  }
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
  h3 {
    line-height: 20px;
    height: 20px;
    padding: 10px 0;
  }
}
.bg-purple {
  background: #d3dce6;
  h3 {
    line-height: 20px;
    padding: 10px 0;
    height: 20px;
  }
}
.bg-purple-light {
  background: #e5e9f2;
  h3 {
    line-height: 20px;
    padding: 10px 0;
    height: 20px;
  }
}
.grid-content {
  border-radius: 4px;
  padding: 10px 0;
  text-indent: 1em;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
.info_tips {
  height: 426px;
  p {
    margin-top: 10px;
    height: 30px;
    width: 90%;
    background-color: #d3dce6;
    display: block;
    text-align: center;
    line-height: 30px;
  }
  div {
    text-align: center;
    margin-top: 20px;
  }
}
</style>