<template>
  <div class="introInfo">
    <div style="margin:20px">
      <p>电子签名及同意声明</p>
      <p>本人在此声明的快捷方式看的肌肤上课的肌肤是打开肌肤是离开的肌肤顺利打开肌肤收到了几口饭顺利打开肌肤顺利完全属实</p>
    </div>

    <el-form
      :inline="true"
      :model="addForm"
      label-width="200px"
      :rules="rules"
      ref="addForm"
      size="mini"
    >
      <!-- 个人资料 -->
      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item name="1">
          <template slot="title">
            个人资料
            <i class="header-icon el-icon-info"></i>
          </template>
          <el-form-item label="中文姓名" prop="name">
            <el-input
              v-model="addForm.name"
              auto-complete="off"
              prefix-icon="el-icon-user"
              placeholder="英文名"
            ></el-input>
          </el-form-item>
          <el-form-item label="英文名" prop="chineseName">
            <el-input v-model="addForm.chineseName" auto-complete="off" prefix-icon="el-icon-user"></el-input>
          </el-form-item>
          <el-form-item label="英文姓" prop="englishName">
            <el-input v-model="addForm.englishName" auto-complete="off" prefix-icon="el-icon-user"></el-input>
          </el-form-item>
          <el-form-item label="出生日期" prop="beneficiaryBirthday">
            <el-date-picker
              style="width:193px"
              type="date"
              placeholder="出生日期"
              value-format="yyyy/MM/dd"
              v-model="addForm.beneficiaryBirthday"
            ></el-date-picker>
          </el-form-item>
          <el-form-item label="性别" prop="beneficiarySex">
            <el-select v-model="addForm.beneficiarySex" placeholder="性别">
              <el-option label="男" value="男"></el-option>
              <el-option label="女" value="女"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="出生的国家" prop="borthCountry">
            <el-select v-model="addForm.borthCountry" placeholder="发证国家">
              <el-option
                v-for="(item,index) in countries"
                :key="index"
                :label="item.countryName"
                :value="item.countryId"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="国籍" prop="countryId">
            <el-select v-model="addForm.countryId" placeholder="发证国家">
              <el-option
                v-for="(item,index) in countries"
                :key="index"
                :label="item.countryName"
                :value="item.countryId"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="职业-行业" prop="profession">
            <el-select v-model="addForm.profession" placeholder="职业-行业">
              <el-option label="技术" value="技术"></el-option>
              <el-option label="金融" value="金融"></el-option>
              <el-option label="建筑" value="建筑"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="职业-职位" prop="job">
            <el-select v-model="addForm.job" placeholder="职业-职位">
              <el-option label="总经理" value="总经理"></el-option>
              <el-option label="技术总监" value="技术总监"></el-option>
              <el-option label="技术员" value="技术员"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="在金融服务行业的经验年期" prop="workingYears">
            <el-input
              v-model="addForm.workingYears"
              auto-complete="off"
              prefix-icon="el-icon-user"
              placeholder="周年"
            ></el-input>
          </el-form-item>
        </el-collapse-item>
      </el-collapse>

      <div style="margin:20px">
        <p>其他个人资料</p>
        <p>请问您是否或曾为美国国家之外的高级军事、政府、政治官员或是与这类官员关系密切或是其直系家属？</p>
        <el-radio v-model="radio" label="2" disabled>是</el-radio>
        <el-radio v-model="radio" label="1">否</el-radio>
      </div>
      <!-- 身份证明文件 -->
      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item>
          <template slot="title">
            身份证明文件
            <i class="header-icon el-icon-info"></i>
          </template>
          <el-form-item label="证件类别" prop="certificateType">
            <el-select v-model="addForm.certificateType" placeholder="选择身份证明文件类别">
              <el-option label="身份证" value="1"></el-option>
              <el-option label="护照" value="2"></el-option>
              <el-option label="港澳通行证" value="3"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="证件号码" prop="certificateNumber">
            <el-input
              v-model="addForm.certificateNumber"
              auto-complete="off"
              prefix-icon="el-icon-s-check"
              placeholder="证件号码"
            ></el-input>
          </el-form-item>
          <el-form-item label="发证国家" prop="certificateCountry">
            <el-select v-model="addForm.certificateCountry" placeholder="发证国家">
              <el-option
                v-for="(item,index) in countries"
                :key="index"
                :label="item.countryName"
                :value="item.countryId"
              ></el-option>
            </el-select>
          </el-form-item>
          <!-- <el-form-item label="发证日期" prop="certificateDate">
            <el-date-picker
              style="width:193px"
              type="date"
              placeholder="发证日期"
              value-format="yyyy-MM-dd"
              v-model="addForm.certificateDate"
            ></el-date-picker>
          </el-form-item> -->
          <!-- <el-form-item label="有效日期" prop="certificateEffectiveDate">
            <el-date-picker
              style="width:193px"
              type="date"
              placeholder="有效日期"
              value-format="yyyy-MM-dd"
              v-model="addForm.certificateEffectiveDate"
            ></el-date-picker>
          </el-form-item> -->

          <!-- <el-form-item>
            <el-checkbox-group v-model="addForm.type">
              <el-checkbox label="无有效日期" name="type"></el-checkbox>
            </el-checkbox-group>
          </el-form-item>-->
        </el-collapse-item>
      </el-collapse>

      <!-- 联络资讯 -->
      <div style="font-size:16px; margin:20px">联络资讯</div>

      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item>
          <template slot="title">
            联络资讯
            <i class="header-icon el-icon-info"></i>
          </template>

          <el-form-item label="邮件信箱" prop="beneficiaryEmail">
            <el-input
              v-model="addForm.beneficiaryEmail"
              auto-complete="off"
              prefix-icon="el-icon-s-check"
              placeholder="电子邮件地址"
            ></el-input>
          </el-form-item>
          <el-form-item label="确认信箱" prop="confirmEmail">
            <el-input
              v-model="addForm.confirmEmail"
              auto-complete="off"
              prefix-icon="el-icon-s-check"
              placeholder="确认电子邮件信箱"
            ></el-input>
          </el-form-item>

          <el-form-item label="电话号码" prop="phone">
            <el-input
              v-model="addForm.phone"
              auto-complete="off"
              prefix-icon="el-icon-phone-outline"
              placeholder="电话号码"
            ></el-input>
          </el-form-item>
        </el-collapse-item>
      </el-collapse>

      <!-- 住址资料 -->
      <div style="font-size:16px; margin:20px">住址资料</div>

      <el-collapse v-model="activeNames" @change="handleChange">
        <el-collapse-item>
          <template slot="title">
            住家地址
            <i class="header-icon el-icon-info"></i>
          </template>
          <el-form-item label="详细地址" prop="addressDetailed">
            <el-input
              v-model="addForm.addressDetailed"
              auto-complete="off"
              prefix-icon="el-icon-user-solid"
              placeholder="详细地址"
            ></el-input>
          </el-form-item>

          <el-form-item label="县/市" prop="addressCity">
            <el-input
              v-model="addForm.addressCity"
              auto-complete="off"
              prefix-icon="el-icon-phone-outline"
              placeholder="县/市"
            ></el-input>
          </el-form-item>
          <el-form-item label="州/省(若适用)" prop="addressProvince">
            <el-input
              v-model="addForm.addressProvince"
              auto-complete="off"
              prefix-icon="el-icon-phone-outline"
              placeholder="州/省(若适用)"
            ></el-input>
          </el-form-item>
          <el-form-item label="国家" prop="addressCountry">
            <el-select v-model="addForm.addressCountry" placeholder="发证国家">
              <el-option
                v-for="(item,index) in countries"
                :key="index"
                :label="item.countryName"
                :value="item.countryId"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="邮编" prop="addressAipcode">
            <el-input
              v-model="addForm.addressAipcode"
              auto-complete="off"
              prefix-icon="el-icon-phone-outline"
              placeholder="邮编"
            ></el-input>
          </el-form-item>

          <!-- 新增公司地址 -->
          <!-- <p>
            <el-button type="text" @click="AddressVisible = true">新增公司地址</el-button>
          </p>

          <el-dialog title="提示" :visible.sync="AddressVisible" width="55%">
            <span>这是一段信息</span>
            <span slot="footer" class="dialog-footer">
              <el-button @click="AddressVisible = false">取 消</el-button>
              <el-button type="primary" @click="AddressVisible = false">确 定</el-button>
            </span>
          </el-dialog>-->
        </el-collapse-item>
      </el-collapse>
    </el-form>

    <div style="font-size:16px; margin:60px 20px 30px 0">
      <el-button type="info" size="small" @click="$router.push({name:'GrantInfo'})">上一步</el-button>
      <el-button type="primary" size="small" @click="onSubmit">下一步</el-button>
    </div>
  </div>
</template>

<script>
import { updateIntroducerUser, getCountryList } from "@/api";
export default {
  data() {
    var checkAge = (rule, value, callback) => {
      if (!value) {
        return callback(new Error("年龄不能为空"));
      }
      setTimeout(() => {
        if (!Number) {
          callback(new Error("请输入数字值"));
        } else {
          if (value < 18) {
            callback(new Error("必须年满18岁"));
          } else {
            callback();
          }
        }
      }, 1000);
    };
    var validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else {
        if (this.addForm.confirmEmail !== "") {
          this.$refs.addForm.validateField("confirmEmail");
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.addForm.beneficiaryEmail) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      radio: "1",
      AddressVisible: false,
      countries: [], //发证国家数组
      activeNames: ["1"],

      rules: {
        beneficiaryEmail: [{ validator: validatePass, trigger: "blur" }],
        confirmEmail: [{ validator: validatePass2, trigger: "blur" }],
        phone: [{ validator: checkAge, trigger: "blur" }]
      },
      introducerId: "", //介绍人id，必填
      addForm: {
        name: "", //中文姓名
        countryId: "", //国籍id
        borthCountry: "", //出生国家
        englishName: "", //英文姓
        chineseName: "", //英文名
        beneficiaryBirthday: "", //出生日期
        beneficiarySex: "", //性别
        profession: "", //职业-行业
        job: "", //职位
        workingYears: "", //在金融行业工作年限

        certificateType: "", //证件类型
        certificateNumber: "", //证件号码
        certificateCountry: "", //发证国家
        // certificateDate: "", //证件发证日期
        // certificateEffectiveDate: "", //证件有效日期

        beneficiaryEmail: "", //邮件信箱
        confirmEmail: "", //确认邮件信箱
        // phoneType: "", //电话种类
        // countryCode: "", //国家代码
        // areaCode: "", //区域号码/门号
        phone: "", //电话号码

        addressDetailed: "", //详细地址
        addressCity: "", //县/市
        addressProvince: "", //省
        addressCountry: "", //国家
        addressAipcode: "" //邮编
      },
      options: [
        {
          value: "中国",
          label: "中国"
        },
        {
          value: "美国",
          label: "美国"
        },
        {
          value: "日本",
          label: "日本"
        }
      ],
      options1: [
        {
          value: "中国",
          label: "中国"
        },
        {
          value: "美国",
          label: "美国"
        },
        {
          value: "日本",
          label: "日本"
        }
      ]
    };
  },
  created() {
    // this.getlangs(),
    // this.getdepartments(),
    this.getcountries();
  },
  methods: {
    //获取国家选框
    getcountries() {
      getCountryList({}).then(res => {
        this.countries = res;
      });
    },
    //提交个人资料
    onSubmit() {
      console.log(this.addForm);
      if (Object.values(this.addForm).includes("")) {
        this.$message({
          message: "请填写全部信息",
          type: "warning"
        });
        return;
      }
      updateIntroducerUser({
        ...this.addForm,
        introducerId: this.$route.params.id
      }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
          this.$router.push({
            name: "UploadFile",
            params: {
              id: this.$route.params.id
            }
          });
        } else {
          this.$message({
            message: res.message,
            type: "error"
          });
        }
      });
    },
    handleChange() {
      console.log("点击折叠版");
    }
  }
};
</script>

<style lang="less" scoped>
.el-card__body {
  padding: 0 !important;
}
</style>
