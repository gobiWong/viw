<template>
  <div class="introtype">
    <div>请选择介绍人为个人或企业团体</div>
    <div>
      <el-radio v-model="radio" label="1">个人</el-radio>
      <el-radio v-model="radio" label="2" disabled>团体</el-radio>
    </div>

    <el-button type="primary" size="small" @click="onSubmit">下一步</el-button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      radio: "1",
      activeName: "1",
      addForm: {
        languageId: "",
        countryId: "",
        departmentId: "",
        englishName: "",
        chineseName: "",
        beneficiaryBirthday: "",
        beneficiarySex: "",
        staffCertificateType: "",
        staffCertificateNo: "",
        staffFaData: "",
        staffOutData: "",
        staffEmail: "",
        staffTrueEmail: "",
        staffPhoneType: "",
        staffCountryCode: "",
        staffMobile: "",
        staffLandline: "",
        staffName: ""
      }
    };
  },
  methods: {
    onSubmit() {
     
      if(this.radio==='1'){
         console.log("我是个人!");
         this.$router.push({
        name: "RegBeneficiary",
        params: {
          id: this.$route.params.id
        }
      });
      }else{
        console.log('我是团体')
      }
      // this.$router.push({
      //   name: "RegBeneficiary",
      //   params: {
      //     id: this.$route.params.id
      //   }
      // });
    }
  }
};
</script>

<style lang="less" scoped>
.introtype {
    font-size: 18px;
  // text-align: center;
  line-height: 38px;
}
</style>
