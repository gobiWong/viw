<template>
  <div class="regBeneficiary">
    <el-row>
      <el-col :span="24">
        <h3>若以个人形式经营的介绍人身故后，则介绍人账户内的佣金余额将由指定受益人（们）获得</h3>
        <p>主要受益人</p>
        <div>
          您要新增受益人吗？
          <el-radio v-model="radio" label="1" disabled>是</el-radio>
          <el-radio v-model="radio" label="2">否</el-radio>
        </div>
        <div v-if="this.radio==='1'?true:false">
          <el-form
            :inline="true"
            :model="addForm"
            label-width="auto"
            :rules="rules"
            ref="addIntroducerForm"
            size="mini"
          >
            <el-form-item label="中文姓名" prop="staffEmail">
              <el-input
                v-model="addForm.staffEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="中文姓名"
              ></el-input>
            </el-form-item>
            <el-form-item label="英文名" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="名"
              ></el-input>
            </el-form-item>
            <el-form-item label="英文姓" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="姓"
              ></el-input>
            </el-form-item>
            <el-form-item label="出生日期" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="出生日期"
              ></el-input>
            </el-form-item>
            <el-form-item label="与参与者关系" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="与参与者关系"
              ></el-input>
            </el-form-item>
            <el-form-item label="百分比" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="百分比"
              ></el-input>
            </el-form-item>
            <el-form-item label="证件类别" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="证件类别"
              ></el-input>
            </el-form-item>
            <el-form-item label="证件号码" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="证件号码"
              ></el-input>
            </el-form-item>
            <el-form-item label="发证国家" prop="staffTrueEmail">
              <el-input
                v-model="addForm.staffTrueEmail"
                auto-complete="off"
                prefix-icon="el-icon-s-check"
                placeholder="发证国家"
              ></el-input>
            </el-form-item>
          </el-form>
        </div>
        <p>附带受益人</p>
        <div>
          您要新增附带受益人吗？
          <el-radio v-model="radio1" label="1" disabled >是</el-radio>
          <el-radio v-model="radio1" label="2">否</el-radio>
        </div>
      </el-col>
    </el-row>
    <el-button type="info" size="small" @click="$router.push({name:'Introtype'})">上一步</el-button>
    <el-button type="primary" size="small" @click="onSubmit">下一步</el-button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      radio: "2",
      radio1: "2",
      activeName: "1",
      rules: {},
      addForm: {
        name: "",//中文姓名
        englishName: "",//姓
        chineseName: "",//名
        beneficiaryBirthday: "",//出生日期
        relationship: "",//与参与者关系
        certificateType: "",//证件类别
        percentage: "",//百分比
        certificateNumber: "",//证件号码
        certificateCountry: "",//发证国家
      },
      introducerId:'',//介绍人id
    };
  },
  methods: {
    onSubmit() {
   
      if(this.radio==='2'){
           console.log("不新增受益人!");
           this.$router.push({
        name: "Contracts",
        params: {
          id: this.$route.params.id
        }
      });
           

      }else{
         console.log("新增收益人!");
         //请求添加接口，成功后跳转
      }
      // this.$router.push({
      //   name: "Contracts",
      //   params: {
      //     id: this.$route.params.id
      //   }
      // });
    }
  }
};
</script>

<style lang="less" scoped>
.regBeneficiary {
   font-size: 18px;
  // text-align: center;
  line-height: 38px;
}

</style>
