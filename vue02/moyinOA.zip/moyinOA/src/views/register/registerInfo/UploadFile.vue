<template>
  <div class="uploadFile">
    <!-- 身份证明文件 -->
    <div class="id_document add_document">
      <el-row>
        <el-col :span="24">
          <h3>身份证明文件</h3>
          <el-table
            v-loading="loading"
            :data="idFileList"
            ref="otherFile"
            border
            style="width: 100%"
            :header-cell-style="headerStyle"
            :cell-style="cellStyle"
          >
            <el-table-column prop="documentType" label="种类" width="120px"></el-table-column>
            <el-table-column prop="fileName" label="文件名" width="340px"></el-table-column>

            <el-table-column fixed="right" label="操作">
              <template slot-scope="scope">
                <el-button @click="handleClick(scope.row)" type="text" size="small">删除</el-button>
                <!-- <el-button type="text" size="small">编辑</el-button> -->
              </template>
            </el-table-column>
          </el-table>
          <div class="fr">
            <el-button type="success" plain size="small" @click="id_btn">新增身份证明文件</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 身份证明文件弹框 -->
    <el-dialog
      title="身份证明文件"
      :visible.sync="idDialogVisible"
      width="40%"
      :before-close="handleClose"
      style="padding:0"
    >
      <el-card class="box-card mt10" style="height:300px">
        <el-form label-width="auto" :rules="rules" ref="uploadFile" size="mini" :model="files">
          <el-form-item label="文件" prop="fileUrl">
            <!-- <input type="file" value="" id="file" @change="uploadConfig" placeholder="上传文件" name="documentUrl"> -->

            <el-upload
              v-model="formFile.fileUrl"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              multiple
              :on-success="idFileSuccess"
              :auto-upload="true"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
      </el-card>

      <span slot="footer" class="dialog-footer">
        <el-button @click="idDialogVisible = false" size="small">取 消</el-button>
        <el-button type="primary" @click="idUpload" size="small">保 存</el-button>
      </span>
    </el-dialog>

    <!-- 住址证明文件 -->
    <div class="address_document add_document">
      <el-row>
        <el-col :span="24">
          <h3>住址证明文件</h3>
          <el-table
            v-loading="loading"
            :data="addressFileList"
            ref="otherFile"
            border
            style="width: 100%"
            :header-cell-style="headerStyle"
            :cell-style="cellStyle"
          >
            <el-table-column prop="documentType" label="种类" width="120px"></el-table-column>
            <el-table-column prop="fileName" label="文件名" width="340px"></el-table-column>

            <el-table-column fixed="right" label="操作">
              <template slot-scope="scope">
                <el-button @click="handleClick(scope.row)" type="text" size="small">删除</el-button>
                <!-- <el-button type="text" size="small">编辑</el-button> -->
              </template>
            </el-table-column>
          </el-table>
          <div class="fr">
            <el-button type="success" plain size="small" @click="address_btn">新增住址文件</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 住址文件弹框 -->
    <el-dialog
      title="住址证明文件"
      :visible.sync="addressDialogVisible"
      width="40%"
      :before-close="handleClose"
      style="padding:0"
    >
      <el-card class="box-card mt10" style="height:300px">
        <el-form label-width="auto" :rules="rules" ref="uploadFile" size="mini" :model="files">
          <el-form-item label="文件" prop="fileUrl">
            <!-- <input type="file" value="" id="file" @change="uploadConfig" placeholder="上传文件" name="documentUrl"> -->

            <el-upload
              v-model="formFile.fileUrl"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              multiple
              :on-success="addressFileSuccess"
              :auto-upload="true"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
      </el-card>

      <span slot="footer" class="dialog-footer">
        <el-button @click="addressDialogVisible = false" size="small">取 消</el-button>
        <el-button type="primary" @click="addressUpload" size="small">保 存</el-button>
      </span>
    </el-dialog>

    <!-- 在金融行业的经历证明 -->
    <div class="bank_document add_document">
      <el-row>
        <el-col :span="24">
          <h3>在金融行业的经历证明</h3>
          <el-table
            v-loading="loading"
            :data="bankFileList"
            ref="otherFile"
            border
            style="width: 100%"
            :header-cell-style="headerStyle"
            :cell-style="cellStyle"
          >
            <el-table-column prop="documentType" label="种类" width="120px"></el-table-column>
            <el-table-column prop="fileName" label="文件名" width="340px"></el-table-column>

            <el-table-column fixed="right" label="操作">
              <template slot-scope="scope">
                <el-button @click="handleClick(scope.row)" type="text" size="small">删除</el-button>
                <!-- <el-button type="text" size="small">编辑</el-button> -->
              </template>
            </el-table-column>
          </el-table>
          <div class="fr">
            <el-button type="success" plain size="small" @click="bank_btn">新增金融行业文件</el-button>
          </div>
        </el-col>
      </el-row>
    </div>



    <!-- 金融证明文件弹框 -->
    <el-dialog
      title="金融行业证明文件"
      :visible.sync="bankDialogVisible"
      width="40%"
      :before-close="handleClose"
      style="padding:0"
    >
      <el-card class="box-card mt10" style="height:300px">
        <el-form label-width="auto" :rules="rules" ref="uploadFile" size="mini" :model="files">
          <el-form-item label="文件" prop="fileUrl">
            <!-- <input type="file" value="" id="file" @change="uploadConfig" placeholder="上传文件" name="documentUrl"> -->

            <el-upload
              v-model="formFile.fileUrl"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              multiple
              :on-success="bankFileSuccess"
              :auto-upload="true"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
      </el-card>

      <span slot="footer" class="dialog-footer">
        <el-button @click="bankDialogVisible = false" size="small">取 消</el-button>
        <el-button type="primary" @click="bankUpload" size="small">保 存</el-button>
      </span>
    </el-dialog>



    <!-- 其他文件 -->
    <div class="other_document add_document">
      <el-row>
        <el-col :span="24">
          <h3>其他</h3>
          <el-table
            v-loading="loading"
            :data="otherFileList"
            ref="otherFile"
            border
            style="width: 100%"
            :header-cell-style="headerStyle"
            :cell-style="cellStyle"
          >
            <el-table-column prop="documentType" label="种类" width="120px"></el-table-column>
            <el-table-column prop="fileName" label="文件名" width="340px"></el-table-column>

            <el-table-column fixed="right" label="操作">
              <template slot-scope="scope">
                <el-button @click="handleClick(scope.row)" type="text" size="small">删除</el-button>
                <!-- <el-button type="text" size="small">编辑</el-button> -->
              </template>
            </el-table-column>
          </el-table>
          <div class="fr">
            <el-button type="success" plain size="small" @click="other_btn">新增其他文件</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 上传其他文件弹框 -->

    <el-dialog
      title="其他文件上传"
      :visible.sync="otherDialogVisible"
      width="40%"
      :before-close="handleClose"
      style="padding:0"
    >
      <el-card class="box-card mt10" style="height:300px">
        <el-form label-width="auto" :rules="rules" ref="uploadFile" size="mini" :model="files">
          <el-form-item label="文件" prop="fileUrl">
            <!-- <input type="file" value="" id="file" @change="uploadConfig" placeholder="上传文件" name="documentUrl"> -->

            <el-upload
              v-model="formFile.fileUrl"
              ref="upload"
              :action="doUpload"
              :before-upload="beforeUpload"
              multiple
              :on-success="otherFileSuccess"
              :auto-upload="true"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
      </el-card>

      <span slot="footer" class="dialog-footer">
        <el-button @click="otherDialogVisible = false" size="small">取 消</el-button>
        <el-button type="primary" @click="otherUpload" size="small">保 存</el-button>
      </span>
    </el-dialog>

    <!-- 下一页并保存 -->
    <el-button type="info" size="small" @click="$router.push({name:'IntroInfo'})">上一步</el-button>
    <el-button size="small" type="primary" @click="nextSave">下一页并保存</el-button>
  </div>
</template>

<script>
import { addFileInformation, getFileList, baseURL } from "@/api";
export default {
  data() {
    return {
      loading: true,
      idDialogVisible: false, //身份证明文件弹框显隐
      addressDialogVisible: false, //住址证明弹框显隐
      bankDialogVisible: false, //金融行业弹框显隐
      otherDialogVisible: false, //其他文件弹框显隐
      doUpload: `${baseURL}/fileInformation/uploadFile`, //上传文件地址
      headerStyle: {
        "background-color": "#DCDFE6",
        height: "20px",
        "text-align": "center"
      }, //表头样式
      cellStyle: {
        "text-align": "center"
      }, //表格样式
      files: {},
      formFile: {
        fileUrl: ""
      },
      rules: {},
      idFiles: { introducerId: this.$route.params.id, fileType: 1 }, //保存身份证明文件提交的数据
      addressFiles: { introducerId: this.$route.params.id, fileType: 2 }, //保存住址证明文件提交的数据
      bankFiles: { introducerId: this.$route.params.id, fileType: 3 }, //保存金融行业文件提交的数据
      otherFiles: { introducerId: this.$route.params.id, fileType: 4 }, //保存其他文件提交的数据

      idFileList: [
        //身份证明文件
      ],
      addressFileList: [
        //地址文件
      ],
      bankFileList: [
        //金融文件
      ],
      otherFileList: [
        //其他文件
      ]
    };
  },
  //数据初始化查询已上传的数据
  created() {
    this.initList();
  },

  methods: {
    // 初始化表格数据
    initList() {
      this.loading = true;
      getFileList({
        params: { introducerId: this.$route.params.id }
      }).then(res => {
        console.log(res);

        var idFileArr = res.dataList.filter(item => item.fileType === 1);
        var addressFileArr = res.dataList.filter(item => item.fileType === 2);
        var bankFileArr = res.dataList.filter(item => item.fileType === 3);
        var otherFileArr = res.dataList.filter(item => item.fileType === 4);
        console.log(otherFileArr);
        this.idFileList =idFileArr;
        this.addressFileList =addressFileArr;
        this.bankFileList =bankFileArr;
        this.otherFileList =otherFileArr;
        // this.total = res.data.total
        this.loading = false;
      });
    },

    //上传前
    beforeUpload(file) {
      console.log(file)
      // let fd = new FormData();
      // fd.append("documentUrl", file); //传文件
      // fd.append("documentType", this.formDocument.documentType); //传其他参数
      // fd.append("userID", parseInt(this.$store.getters.userId));
      // fd.append("documentDetail", this.formDocument.documentDetail);
      // axios
      //   .post("http://192.168.2.142:8087/document/addDocument", fd)
      //   .then(function(res) {
      //     alert("成功");
      //   });
    },
    //身份证明文件上传成功后处理业务（类型1）
    idFileSuccess(res, file) {
      // this.formDocument.documentUrl = URL.createObjectURL(file.raw);
      var fileUrl = res.data.fileURL;
      var fileName = res.data.fileName;
      this.idFiles = { ...this.idFiles, [fileUrl]: fileName };
    },

    //身份证明文件保存上传到服务器（类型1）
    idUpload() {
      addFileInformation({ ...this.idFiles }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
          this.idDialogVisible = false;
          this.initList();
        } else {
          this.$message({
            message: "数据加载异常",
            type: "info"
          });
        }
      });
    },

    //住址文件上传成功后处理业务（类型2）
    addressFileSuccess(res, file) {
      // this.formDocument.documentUrl = URL.createObjectURL(file.raw);
      var fileUrl = res.data.fileURL;
      var fileName = res.data.fileName;
      this.addressFiles = { ...this.addressFiles, [fileUrl]: fileName };
    },

    //住址文件保存上传到服务器（类型2）
    addressUpload() {
      addFileInformation({ ...this.addressFiles }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
          this.addressDialogVisible = false;
          this.initList();
        } else {
          this.$message({
            message: "数据加载异常",
            type: "info"
          });
        }
      });
    },

    //金融文件上传成功后处理业务（类型3）
    bankFileSuccess(res, file) {
      // this.formDocument.documentUrl = URL.createObjectURL(file.raw);
      var fileUrl = res.data.fileURL;
      var fileName = res.data.fileName;
      this.bankFiles = { ...this.bankFiles, [fileUrl]: fileName };
    },

    //金融文件保存上传到服务器（类型3）
    bankUpload() {
        if(Object.keys(this.bankFiles).length==2){
  this.$message({
            message: "请上传1份文件",
            type: "info"
          });
          return
      }
      addFileInformation({ ...this.bankFiles }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
          this.bankDialogVisible = false;
          this.initList();
        } else {
          this.$message({
            message: "数据加载异常",
            type: "info"
          });
        }
      });
    },

    //其他文件上传成功后处理业务（类型4）
    otherFileSuccess(res, file) {
      // this.formDocument.documentUrl = URL.createObjectURL(file.raw);
      var fileUrl = res.data.fileURL;
      var fileName = res.data.fileName;
      this.otherFiles = { ...this.otherFiles, [fileUrl]: fileName };
      // this.otherFiles[fileUrl] = fileName

      //  this.otherFiles.push(res.data);
    },

    //其他文件保存上传到服务器（类型4）
    otherUpload() {
     
      if(Object.keys(this.otherFiles).length==2){
  this.$message({
            message: "请上传1份文件",
            type: "info"
          });
      }else{
            addFileInformation({ ...this.otherFiles }).then(res => {
        if (res.success) {
          this.$message({
            message: res.message,
            type: "success"
          });
          this.otherDialogVisible = false;
          this.initList();
        } else {
          this.$message({
            message: "数据加载异常",
            type: "info"
          });
        }
      });
      }
  
    },

    //下载文件
    handleClick(row) {
      // downloadDocument(row.documentUrl).then(res=>{
      //   console.log(res)
      // })
    },

    //新增身份证明文件弹框按钮
    id_btn() {
      this.idDialogVisible = true;
    },

    //新增住址文件弹框按钮
    address_btn() {
      this.addressDialogVisible = true;
    },

    //新增金融证明文件弹框按钮
    bank_btn() {
      this.bankDialogVisible = true;
    },

    //新增其他文件弹框按钮
    other_btn() {
      this.otherDialogVisible = true;
    },

    //关闭弹框操作
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    //保存页面并下一页按钮
    nextSave() {
      console.log("保存至下一页");
      if (
        this.idFileList.length == 0 ||
        this.addressFileList.length == 0 ||
        this.bankFileList.length == 0 ||
        this.otherFileList.length == 0
      ) {
        this.$message({
          message: "请确定每种类型文件至少上传一份！",
          type: "warning"
        });
        return;
      }
      this.$router.push({
        name: "Infosure",
        params: {
          id: this.$route.params.id
        }
      });
    },

    handleRemove(file, fileList) {},

    handlePreview(file) {},
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    }
  }
};
</script>

<style lang="less" scoped>
.uploadFile {
  .add_document {
    border: 1px solid #ccc;
    margin: 20px;
    line-height: 20px;
    h3 {
      display: block;
      height: 30px;
      padding-left: 20px;
      background-color: #ddd;
    }
    p {
      height: 50px;
      line-height: 50px;
      text-indent: 2em;
    }
  }
}
.upload {
  display: flex;
  justify-content: center;
  align-items: center;
}
.fr {
  float: right;
  margin: 5px;
}
.fl {
  float: left;
  margin-top: 5px;
}
.mt10 {
  margin-top: 10px;
}
.el-dialog__body {
  padding: 0 !important;
}
</style>
