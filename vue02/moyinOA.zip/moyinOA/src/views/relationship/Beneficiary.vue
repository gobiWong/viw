<template>
  <div class="service_online">
    <!-- <div class="mm_button">
      <el-button type="primary" icon="el-icon-search"  @click="searchFilter">搜索</el-button>

      <el-button type="danger" icon="el-icon-delete"  @click="clearFilter">删除</el-button>
      <el-button type="success" icon="el-icon-share"  @click="startFilter">开启</el-button>
    </div>-->
    <div class="mm_table">
      <!-- 介绍人 -->
      <el-row style="font-size:16px">
        <el-col :span="24">介绍人-Shi Liu</el-col>
        <el-divider></el-divider>
      </el-row>

      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'center',
     }"
        :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'center',
    }"
      >
        <!-- <el-table-column
         prop="ref_num" 
         label="参考号码" 
         width="180"
         sortable
        :filters="[{text: '2016-05-01', value: '2016-05-01'}, {text: '2016-05-02', value: '2016-05-02'},]"
        :filter-method="filterHandler"
        >
        </el-table-column>-->
        <el-table-column prop="chineseName" label="名字" width="180"></el-table-column>
        <el-table-column prop="EnglishName" label="英文姓"></el-table-column>
        <el-table-column prop="Birthday" label="出生日期"></el-table-column>

        <el-table-column prop="sex" sortable label="性别"></el-table-column>
        <el-table-column prop="nationality" label="国籍"></el-table-column>
        <el-table-column prop="language" label="语言偏好"></el-table-column>
        <el-table-column prop="email" label="电子邮件信箱"></el-table-column>
      </el-table>
      <!-- 证件号码 -->
      <el-row style="font-size:16px">
        <el-col :span="24">证件号码</el-col>
        <el-divider></el-divider>
      </el-row>

      <el-table
        :data="idcard"
        border
        stripe
        style="width: 100%"
        :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'left',
     }"
        :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'left',
    }"
      >
        <el-table-column prop="id_type" label="证件类别" width="200px"></el-table-column>
        <el-table-column prop="id_num" label="证件号码"></el-table-column>
      </el-table>
      <!-- 电话号码 -->
      <div class="num_coll" style="margin:10px 0">
        <el-collapse v-model="activeName" accordion>
          <el-collapse-item style="padding-top:-12px">
            <!-- 电话号码折叠板标题 -->
            <template slot="title">
              <el-row>
                <el-col :span="24">
                  <i class="el-icon-phone" style="padding:0 5px"></i>电话号码
                </el-col>
              </el-row>
            </template>
            <!-- 折叠板内容 -->
            <div class="line"></div>
            <el-table
              :data="idcard"
              :show-header="false"
              style="width: 100% ;margin:0 20px 10px 20px"
              :header-cell-style="{
    	/* 样式名称 ： 属性 */
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'left',
     }"
              :cell-style="{
		 /* 样式名称 ： 属性 */
		'text-align': 'left',
    }"
            >
              <el-table-column prop="id_type" label="证件类别" width="200px"></el-table-column>
              <el-table-column prop="id_num" label="证件号码"></el-table-column>
            </el-table>
            <el-button
              type="success"
              @click="dialogNumVisible = true"
              icon="el-icon-circle-plus-outline"
              size="small"
            >新增电话号码</el-button>
          </el-collapse-item>
          <!-- 新增电话的弹框 -->
          <el-dialog title="新增号码" :visible.sync="dialogNumVisible">
            <el-form :model="num_form" size="small">
              <el-form-item label="电话类型:" :label-width="formLabelWidth">
                <el-select v-model="num_form.region" placeholder="电话种类">
                  <el-option label="移动电话" value="移动电话"></el-option>
                  <el-option label="固定电话" value="固定电话"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="号码:" :label-width="formLabelWidth">
                <el-input v-model="num_form.name" autocomplete="off"></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogNumVisible = false">取 消</el-button>
              <el-button type="primary" @click="dialogNumVisible = false">确 定</el-button>
            </div>
          </el-dialog>
        </el-collapse>
      </div>

      <!-- 地址 -->
      <div class="address_coll">
        <el-collapse accordion>
          <el-collapse-item>
            <!-- 折叠板表头标题 -->
            <template slot="title">
              <el-row>
                <el-col :span="24">
                  <i class="el-icon-location" style="padding:0 5px"></i>地址
                </el-col>
              </el-row>
            </template>
            <div class="line"></div>
            <el-table
              :data="idcard"
              :show-header="false"
              style="width: 100% ;margin:0 20px 10px 20px"
              :header-cell-style="{
    
        'background-color': '#DCDFE6',
        'height':'40px',
		'text-align':'left',
     }"
              :cell-style="{
	
		'text-align': 'left',
    }"
            >
              <el-table-column prop="id_type" label="证件类别" width="200px"></el-table-column>
              <el-table-column prop="id_num" label="证件号码"></el-table-column>
              <el-table-column label="操作">
                <template slot-scope="scope">
                  <el-button
                    size="mini"
                    type="primary"
                    plain
                    icon="el-icon-edit"
                    @click="showEditDialog(scope.row)"
                  ></el-button>
                  <el-button
                    size="mini"
                    type="danger"
                    plain
                    icon="el-icon-delete"
                    @click="showDeleteDialog(scope.row)"
                  ></el-button>
                  <!-- <el-button size="mini" type="warning" plain icon="el-icon-check" @click="showGrantDialog(scope.row)"></el-button> -->
                </template>
              </el-table-column>
            </el-table>
            <el-button
              type="success"
              @click="dialogAddressVisible = true"
              icon="el-icon-circle-plus-outline"
              size="small"
            >新增地址</el-button>
          </el-collapse-item>
          <!-- 新增地址的弹框 -->
          <el-dialog title="新增地址" :visible.sync="dialogAddressVisible">
            <el-form :model="address_from" size="small" ref="addAddressForm">
              <el-form-item label="选择地址" prop="region" :label-width="formLabelWidth">
                <el-select v-model="address_from.region" placeholder="住家/公司">
                  <el-option label="住家" value="住家"></el-option>
                  <el-option label="公司" value="公司"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="详细地址:" prop="name" :label-width="formLabelWidth">
                <el-input v-model="address_from.name" autocomplete="off"></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogAddressVisible = false" size="small">取 消</el-button>
              <el-button type="primary" @click="addAddressSubmit('addAddressForm')" size="small">确 定</el-button>
            </div>
          </el-dialog>
        </el-collapse>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeName: "1",
      tableData: [
        {
          chineseName: "Shi",
          EnglishName: "Liu",
          Birthday: "1989-09-07",
          sex: "女",
          nationality: "中国",
          language: "中文简体",
          email: "147171888@qq.com"
        }
      ],
      idcard: [
        {
          id_type: "身份证",
          id_num: "420103198909071222"
        },
        {
          id_type: "护照",
          id_num: "E02599882"
        },
        {
          id_type: "税号",
          id_num: "420103198909071222"
        }
      ],
       dialogAddressVisible: false,
       dialogNumVisible:false,
        num_form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
          address_from: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px'
    };
  },
  methods: {
      //新增地址
      addAddressSubmit(formName){
        this.$refs[formName].validate(valide => {
        if (valide) {
            var addObj={}
            addObj.id_type=this.address_from.region
           
              addObj.id_num= this.address_from.name

        

        
             this.$message({
          message: '新增地址成功!',
          type: 'success'
        });
            this.dialogAddressVisible = false
          // 执行添加用户方法
        //   addUser(this.addForm).then(res => {
        //     console.log(res)
        //     if (res.meta.status === 201) {
        //       this.$message({
        //         type: 'success',
        //         message: '创建用户成功'
        //       })
        //     }
        //     this.dialogAddressVisible = false
        //     // 页面初始化数据,更新
        //     // this.initList()
        //   })
        }
      })
      },
      //编辑地址
      showEditDialog(row){
       
      },
      //删除地址
       showDeleteDialog (row) {
      this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
          this.idcard =  this.idcard.filter(i => {
    return i.id_type !==row.id_type
    
})
        // 执行删除用户操作
        // deleteUser(row.id).then(res => {
        //   if (res.meta.status === 200) {
        //     this.$message({
        //       type: 'success',
        //       message: '删除成功!'
        //     })
        //     this.initList()
        //   }
        // })

      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    searchFilter() {},
    resetDateFilter() {
      this.$refs.filterTable.clearFilter("date");
    },
    clearFilter() {
      this.$refs.filterTable.clearFilter();
    },
    startFilter() {},
    formatter(row, column) {
      return row.address;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    }
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    // .el-button{
    //     height: 30px;
    //     text-align: center;
    // }
  }
  .mm_table {
    margin-top: 10px;
  }
}
.el-collapse-item__header {
  background-color: #dcdfe6;
  font-size: 16px;
}
.line {
  display: block;
  height: 1px;
  width: 100%;
  margin: 10px 0 5px 0;
  background-color: #dcdfe6;
  position: relative;
}
</style>
