<template>
  <div class="service_online">
    <!-- 代理人信息 -->
    <div class="comm_info">
      <!-- 介绍人 -->
      <el-row style="font-size:16px">
        <el-col :span="24">代理人1-{{tableData.chineseName}}</el-col>
        <el-divider></el-divider>
      </el-row>
      <el-card class="box-card" v-loading="loading">
        <el-row>
          <el-col :span="8">
            <div class="grid-content">
              <h3>名字</h3>
              <h3>英文</h3>
              <h3>出生日期</h3>
              <h3>性别</h3>
              <h3>国籍</h3>
              <h3>电子邮件信箱</h3>
            </div>
          </el-col>
          <el-col :span="16">
            <div class="grid-content">
              <h4>{{tableData.chineseName}}</h4>
              <h4>{{tableData.englishName}}</h4>
              <h4>{{tableData.beneficiarySex}}</h4>
              <h4>{{tableData.beneficiaryBirthday}}</h4>
              <h4>{{tableData.countryId|COUNTRY}}</h4>
              <h4>{{tableData.beneficiaryEmail}}</h4>
            </div>
          </el-col>
        </el-row>
      </el-card>
    </div>

    <!-- 证件号码 -->
    <div class="comm_info">
      <el-row style="font-size:16px;margin-top:12px">
        <el-col :span="24">证件号码</el-col>
        <el-divider></el-divider>
      </el-row>

      <el-card class="box-card" v-loading="loading">
        <el-row>
          <el-col :span="8">
            <div class="grid-content">
              <p>证件类别</p>
              <h3>身份证</h3>
              <h3>护照</h3>
              <h3>税号</h3>
            </div>
          </el-col>
          <el-col :span="16">
            <div class="grid-content">
              <p>证件号码</p>
              <h4>{{tableData.beneficiaryCar}}</h4>
              <h4>{{tableData.beneficiaryNumber}}</h4>
              <h4>{{tableData.beneficiaryCar}}</h4>
            </div>
          </el-col>
        </el-row>
      </el-card>
    </div>

    <!-- 电话号码 -->
    <div class="comm_info" style="margin:10px 0">
      <el-collapse v-model="activeName" accordion>
        <el-collapse-item style="padding-top:-12px">
          <!-- 电话号码折叠板标题 -->
          <template slot="title">
            <el-row>
              <el-col :span="24">
                <i class="el-icon-phone" style="padding:0 5px"></i>电话号码
              </el-col>
            </el-row>
          </template>
          <!-- 折叠板内容 -->
          <div class="line"></div>

          <el-row>
            <el-col :span="24">
              <el-row class="new_phone">
                <el-col :span="8">
                  <h3>行动电话</h3>
                </el-col>
                <el-col :span="16">
                  <h4>{{tableData.phone}}</h4>
                </el-col>
              </el-row>
            </el-col>
          </el-row>

          <el-button
            type="success"
            class="add_btn"
            @click="dialogNumVisible = true"
            icon="el-icon-circle-plus-outline"
            size="small"
            disabled
          >新增电话</el-button>
        </el-collapse-item>
        <!-- 新增电话的弹框 -->
        <el-dialog title="新增号码" :visible.sync="dialogNumVisible">
          <el-form :model="num_form" size="small">
            <el-form-item label="电话类型:" :label-width="formLabelWidth">
              <el-select v-model="num_form.region" placeholder="电话种类">
                <el-option label="移动电话" value="移动电话"></el-option>
                <el-option label="固定电话" value="固定电话"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="号码:" :label-width="formLabelWidth">
              <el-input v-model="num_form.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogNumVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogNumVisible = false">确 定</el-button>
          </div>
        </el-dialog>
      </el-collapse>
    </div>

    <!-- 地址 -->
    <div class="comm_info">
      <el-collapse accordion>
        <el-collapse-item>
          <!-- 折叠板表头标题 -->
          <template slot="title">
            <el-row>
              <el-col :span="24">
                <i class="el-icon-location" style="padding:0 5px"></i>地址
              </el-col>
            </el-row>
          </template>
          <div class="line"></div>
          <el-row>
            <el-col :span="24">
              <el-row class="new_address">
                <el-col :span="8">
                  <h3>住家</h3>
                </el-col>
                <el-col :span="16">
                  <h4>No. 33, Dongmin Li, Qianjin 4 Road,. Wuhan, Hubei, China, 430000</h4>
                </el-col>
              </el-row>
            </el-col>
          </el-row>
          <el-button
            type="success"
            @click="dialogAddressVisible = true"
            icon="el-icon-circle-plus-outline"
            size="small"
            class="add_btn"
            disabled
          >新增地址</el-button>
        </el-collapse-item>
        <!-- 新增地址的弹框 -->
        <el-dialog title="新增地址" :visible.sync="dialogAddressVisible">
          <el-form :model="address_from" size="small" ref="addAddressForm">
            <el-form-item label="选择地址" prop="region" :label-width="formLabelWidth">
              <el-select v-model="address_from.region" placeholder="住家/公司">
                <el-option label="住家" value="住家"></el-option>
                <el-option label="公司" value="公司"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="详细地址:" prop="name" :label-width="formLabelWidth">
              <el-input v-model="address_from.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogAddressVisible = false" size="small">取 消</el-button>
            <el-button type="primary" @click="addAddressSubmit('addAddressForm')" size="small">确 定</el-button>
          </div>
        </el-dialog>
      </el-collapse>
    </div>
  </div>
</template>

<script>
import { getIntroducerUser } from "@/api";
export default {
  data() {
    return {
      activeName: "1",
      loading: true,
      tableData: [
        {
          chineseName: "Shi",
          EnglishName: "Liu",
          Birthday: "1989-09-07",
          sex: "女",
          nationality: "中国",
          language: "中文简体",
          email: "147171888@qq.com"
        }
      ],
      idcard: [
        {
          id_type: "身份证",
          id_num: "420103198909071222"
        },
        {
          id_type: "护照",
          id_num: "E02599882"
        },
        {
          id_type: "税号",
          id_num: "420103198909071222"
        }
      ],
      dialogAddressVisible: false,
      dialogNumVisible: false,
      num_form: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: ""
      },
      address_from: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: ""
      },
      formLabelWidth: "120px"
    };
  },
  created() {
    this.initList();
  },

  methods: {
    // 初始化表格数据
    initList() {
      this.loading = true;
      getIntroducerUser({
        userID: parseInt(window.localStorage.getItem('userId'))
      }).then(res => {
        // console.log(res);
        this.tableData = res;

        this.loading = false;
      });
    },

    //新增地址
    addAddressSubmit(formName) {
      this.$refs[formName].validate(valide => {
        if (valide) {
          var addObj = {};
          addObj.id_type = this.address_from.region;

          addObj.id_num = this.address_from.name;

          this.$message({
            message: "新增地址成功!",
            type: "success"
          });
          this.dialogAddressVisible = false;
          // 执行添加用户方法
          //   addUser(this.addForm).then(res => {
          //     console.log(res)
          //     if (res.meta.status === 201) {
          //       this.$message({
          //         type: 'success',
          //         message: '创建用户成功'
          //       })
          //     }
          //     this.dialogAddressVisible = false
          //     // 页面初始化数据,更新
          //     // this.initList()
          //   })
        }
      });
    },
    //编辑地址
    showEditDialog(row) {},
    //删除地址
    showDeleteDialog(row) {
      this.$confirm("此操作将永久删除该用户, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.idcard = this.idcard.filter(i => {
            return i.id_type !== row.id_type;
          });
          // 执行删除用户操作
          // deleteUser(row.id).then(res => {
          //   if (res.meta.status === 200) {
          //     this.$message({
          //       type: 'success',
          //       message: '删除成功!'
          //     })
          //     this.initList()
          //   }
          // })
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    searchFilter() {},
    resetDateFilter() {
      this.$refs.filterTable.clearFilter("date");
    },
    clearFilter() {
      this.$refs.filterTable.clearFilter();
    },
    startFilter() {},
    formatter(row, column) {
      return row.address;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    }
  }
};
</script>
<style lang="less" scope>
.service_online {
  .mm_button {
    box-sizing: border-box;
    padding-bottom: 10px;

    border-bottom: 1px solid #dcdfe6;
    text-align: left;
    // .el-button{
    //     height: 30px;
    //     text-align: center;
    // }
  }
  .mm_table {
    margin-top: 10px;
  }
}
.comm_info {
  h3 {
    height: 30px;
    line-height: 30px;
    font-weight: 600;
    border-bottom: 1px solid rgb(214, 211, 211);
  }
  h4 {
    height: 30px;
    line-height: 30px;
    color: dimgray;
    border-bottom: 1px solid rgb(214, 211, 211);
  }
  p {
    height: 30px;
    line-height: 30px;
    font-weight: 600;
  }
}
.el-collapse-item__header {
  background-color: #dcdfe6;
  font-size: 16px;
}
.line {
  display: block;
  height: 1px;
  width: 100%;
  margin: 10px 0 5px 0;
  background-color: #dcdfe6;
  position: relative;
}
.add_btn {
  margin: 10px;
}
.new_phone ,.new_address {
  .el-col {
    h3,h4 {
      text-indent: 1em;
      font-size: 15px
    }
  }
}
</style>
