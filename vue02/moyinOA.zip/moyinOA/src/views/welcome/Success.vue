<template>
  <div class="success">
    <el-card>
      <div>欢迎登入</div>
    </el-card>
  </div>
</template>
<script>


</script>
<style lang="less" scoped>
.success {
  .el-card {
    width: 100%;
    height: 60vh;
  }
}
</style>

