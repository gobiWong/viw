<template>
  <div class="commission_questions">
    <el-card class="box-card">
      <div v-if="toggle" v-loading="loading">
        <el-card class="box-card" v-for="(item,index) in EvaluationList" :key="index">
          <div slot="header" class="clearfix">
            <i>{{index+1}}</i>
            <span>.{{item.evaluationContent}}</span>
          </div>
          <el-form
            :label-position="labelPosition"
            label-width="80px"
            :model="formLabelAlign"
            @submit.prevent="submit"
          >
            <div>
              <ul class="items_ul">
                <li>
                  <el-radio
                    v-model="checkedValue[index]"
                    @change="get_radio_value(index)"
                    label="A"
                    :name="(item.evaluationId).toString()"
                  ></el-radio>
                  {{item.evaluationA}}
                </li>
                <li>
                  <el-radio
                    v-model="checkedValue[index]"
                    @change="get_radio_value(index)"
                    label="B"
                    :name="(item.evaluationId).toString()"
                  ></el-radio>
                  {{item.evaluationB}}
                </li>
                <li>
                  <el-radio
                    v-model="checkedValue[index]"
                    @change="get_radio_value(index)"
                    label="C"
                    :name="(item.evaluationId).toString()"
                  ></el-radio>
                  {{item.evaluationC}}
                </li>
                <li>
                  <el-radio
                    v-model="checkedValue[index]"
                    @change="get_radio_value(index)"
                    label="D"
                    :name="(item.evaluationId).toString()"
                  ></el-radio>
                  {{item.evaluationD}}
                </li>
              </ul>
            </div>
          </el-form>
        </el-card>

        <el-button class="submit" type="info" size="small" @click="onSubmit">提交</el-button>
      </div>
    </el-card>
    <el-dialog title="提示" :visible.sync="dialogVisible" width="35%" :data="data">
      <span>{{msg}}</span>
      <span slot="footer" class="dialog-footer">
        <!-- <el-button @click="dialogVisible = false">取 消</el-button> -->
        <el-button type="primary" @click="confirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { getEvaluationList, submitEvaluation, getUserInfo } from "@/api";

export default {
  data() {
    return {
      loading: true,
      randomSum: 3,
      dialogVisible: false,
      data: "",
      msg: "",
      toggle: true,
      labelPosition: "right",
      formLabelAlign: {
        name: "",
        region: "",
        type: ""
      },
      EvaluationList: [
        {
          evaluationA: "现场检查",
          evaluationAnswer: "C",
          evaluationB: "非现场监管",
          evaluationC: "行政调查",
          evaluationContent:
            "反洗钱行政主管部门和其他依法负有反洗钱监督管理职责的部门、机构履行反洗钱职责获得的客户身份资料和交易信息，只能用于反洗钱( )",
          evaluationD: "案件协查",
          evaluationId: 4
        }
      ],
      evaluationAnswer: [], //22
      all_list: [], //答案数组
      checkedValue: [] // 绑定单选框的值
    };
  },
  created() {
    this.loading = true;
    this.initList();
    getUserInfo({ userID: parseInt(window.localStorage.getItem('userId')) }).then(res => {
       console.log(res)
      if (res) {
        this.loading = false;
      }
      if (res.beneficiaryEvaluation == 1) {
        this.$router.push({
          name: "Success"
          // params: {
          //   status: this.data
          // }
        });
      } else {
        this.$router.push({
          name: "Welcome"
          // params: {
          //   status: this.data
          // }
        });
      }
    });
  },
  mounted() {},
  methods: {
    nextCard() {
      this.toggle = !this.toggle;
      console.log("下一页");
    },
    preCard() {
      console.log("上一页");
    },
    // 随机请求8条数据
    initList() {
      this.loading = true;
      getEvaluationList({ randomSum: this.randomSum }).then(res => {
        this.EvaluationList = res;
        this.evaluationAnswer = res.map((item, index) => {
          return (this.evaluationAnswer[index] = item.evaluationAnswer);
        });
        this.loading = false;
      });
    },
    //获取当前radio值
    get_radio_value: function(index) {
      //获取当前radio当前值
      // console.log(index + 1 + "题" + this.checkedValue[index]);
      // console.log(index + 1 + "题" + this.checkedValue);
      this.all_list[index] = this.checkedValue[index]; //赋值
    },
    //提交答案
    onSubmit() {
      for (var i = 0; i < this.all_list.length; i++) {
        if (this.all_list[i] == "" || typeof this.all_list[i] === "undefined") {
          this.all_list.splice(i, 1);
        }
      }

      if (this.EvaluationList.length !== this.all_list.length) {
        this.$message({
          message: "请完成所有题目先。",
          type: "info"
        });
      } else {
        submitEvaluation({
          userID: parseInt(this.$store.getters.userId),
          evaluationAnswer: this.evaluationAnswer,
          evaluationSelect: this.all_list
        }).then(res => {
          if (res.rtnCode == 1 && res.data === "0") {
            this.msg = res.rtnMsg + "请重新选择正确答案~";
            this.data = res.data;
            this.dialogVisible = true;
            // this.all_list = [];
            // this.checkedValue = [];
            // this.initList();
          } else if (res.rtnCode == 1 && res.data === "1") {
            this.msg = res.rtnMsg;
            this.dialogVisible = true;
            this.data = res.data;
          }
        });
        // 传值给调用页面
        // this.$emit('transfer', this.all_list)
      }
    },
    //处理提示框
    confirm() {
      if (this.data === "0") {
        this.dialogVisible = true;
      } else {
        // console.log(this.$router);

        this.$router.push({
          name: "Success"
          // params: {
          //   status: this.data
          // }
        });
      }
    }
  }
};
</script>
<style lang="less" scoped>
.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}

.box-card {
  width: 100%;
  margin: 10px 0;
}
.el-radio {
  margin-right: 5px;
}
.items_ul > li {
  margin-bottom: 3px;
}
</style>

