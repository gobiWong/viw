<template>
  <el-container>
    <el-aside width="200px" style="overflow-y:auto;">
      <el-row class="tac">
        <el-col :span="24">
          <el-menu default-active="/work" class="el-menu-vertical-demo" background-color="#001529" text-color="#fff" active-text-color="#f1dc1b" router>
            <el-submenu :index="item.name" v-for="item in navList" :key="item.id">
              <template slot="title">
                <span>{{item.name}}</span>
              </template>
              <el-menu-item-group>
                <el-menu-item :index="value.path" v-for="(value,index) in item.children" :key="index">{{value.name}}</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </el-col>
      </el-row>
    </el-aside>
    <el-container>
      <el-header style="backgroundColor:skyblue;">Header</el-header>
      <el-main style="backgroundColor:green;">
        <router-view/>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
export default {
  data() {
    return {
      // 路由匹配规则
      navList: [
        {
          id: 1,
          name: "工作台",
          path: "/work",
          children: [{ id: 14, name: "工作台", path: "/work" }]
        },
        {
          id: 2,
          name: "标准地址管理",
          path: "/addRess",
          children: [{ id: 15, name: "标准地址管理", path: "/addRess" }]
        },
        {
          id: 3,
          name: "城市部件管理",
          path: "/urban",
          children: [{ id: 16, name: "城市部件管理", path: "/urban" }]
        },
        {
          id: 5,
          name: "组织机构管理",
          path: "/organization",
          children: [
            { id: 9, name: "非公有制经济组织管理", path: "/organization" },
            { id: 10, name: "社会组织管理", path: "/Organment" }
          ]
        },
        {
          id: 6,
          name: "实有人口管理",
          path: "/population",
          children: [{ id: 11, name: "实有人口管理", path: "/population" }]
        },
        {
          id: 7,
          name: "房屋管理",
          path: "/house",
          children: [
            { id: 12, name: "房屋管理", path: "/house" },
            { id: 19, name: "建筑物管理", path: "/edifice" }
          ]
        },
        {
          id: 9,
          name: "地体实体管理",
          path: "/quarters",
          children: [{ id: 20, name: "小区管理", path: "/quarters" }]
        }
      ]
    };
  },
  
};
</script>

<style scoped>
/* 将el-container的高度也设置为100% */
.el-container {
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}
.el-menu-item.is-active > .item-label {
  background: pink;
}

</style>
