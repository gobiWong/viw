<template>
    <el-container>
        <el-header>
            <div class="wrap">
                <div class="mian" v-for="(item,index) in routeData" :key="index">
                    <router-link :to="item.fullPath" tag="div" class="contanier">{{item.name}}</router-link>
                    <div class="clear" @click = "clear(item.fullPath)">删除</div>
                </div>
            </div>
        </el-header>
        <el-main>
             <router-view/>
        </el-main>
    </el-container>
</template>

<script>
export default {
    data(){
        return {
            routeData:[]
        }
    },
    methods:{
        clear(data){
            let clear = this.routeData.filter((value,index) => {
                return value.fullPath !== data
            })
            this.routeData = clear
            console.log(this.routeData.length)
            if(this.routeData.length !== 0){
                // 跳转的位置
                let data = this.routeData[this.routeData.length-1].fullPath
                this.$router.push(`${data}`)
            }else{
                 this.$router.push("/Main")
            }

        }
    },
    watch:{
    $route:{
      handler: function (val ,oldVal){
        this.routeData.push(val)
        let obj = {};
        let newDataArry = this.routeData.reduce((cur, next) => {
            obj[next.fullPath]
              ? ""
              : (obj[next.fullPath] = true && cur.push(next));
            return cur;
          }, []);
        this.routeData = newDataArry;
      },
      deep:true
    }
  }
}
</script>


<style>
    .el-container .el-header{
        height: 300px;
        width: 100%;
        background: skyblue;
    }
    .el-container .el-header .wrap{
        width: 100%;
        height: 100%;
        display: flex;
        flex-wrap: nowrap;
        flex-direction: row;
    }
    .el-container .el-header .wrap .mian{
        border-radius: 50px;
        display: flex;
        width:150px;
        margin: 10px;
        background-color: pink;

    }
    .el-container .el-header .wrap .mian .contanier{
        text-align: center;
        flex: 1;
        height: 100%;
        background-color: pink;
        cursor: pointer;
    }
    .el-container .el-header .wrap .mian .clear{
        text-align: center;
        height: 100%;
        width: 50px;
        background-color: blueviolet;
        cursor: pointer;
    }
</style>
