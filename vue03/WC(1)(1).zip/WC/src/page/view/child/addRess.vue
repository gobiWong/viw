<template>
    <div class="must">
        <span>标准地址管理</span>
    </div>
</template>


<style scoped>
.must span{
    font-size: 30px;
    background-color: sandybrown;
}
</style>
