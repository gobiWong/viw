<template>
    <div class="must" >
          <span>实有人口管理</span>
    </div>
</template>

<style scoped>
.must span{
    font-size: 30px;
    background-color:cyan;
}
</style>

