<template>
    <div class="must">
          <span>非公有制解决组织</span>
    </div>
</template>

<style scoped>
.must span{
    font-size: 30px;
    background-color: lightcoral;
}
</style>
