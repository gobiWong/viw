<template>
    <div class="must">
          <span>社会组织管理</span>
    </div>
</template>

<style scoped>
.must span{
    font-size: 30px;
    background-color: violet;
}
</style>
