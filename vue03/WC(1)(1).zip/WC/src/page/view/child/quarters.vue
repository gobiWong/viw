<template>
    <div class="must">
        <span>建筑物管理</span>
    </div>
</template>

<style scoped>
.must span{
    font-size: 30px;
    background-color: darkmagenta;
}
</style>

