<template>
    <div class="must">
          <span>城市部件</span>
    </div>
</template>


<style scoped>
.must span{
    font-size: 30px;
    background-color: peru;
}
</style>
