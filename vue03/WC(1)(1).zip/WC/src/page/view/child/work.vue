<template>
    <div class="must">
        <span>工作台</span>
    </div>
</template>

<style scoped>
.must span{
    font-size: 30px;
    background-color: orange;
}
</style>
