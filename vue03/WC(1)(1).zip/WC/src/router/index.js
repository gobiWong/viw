import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/page/login/login'
import Home from '@/page/view/Home'
import Main from '@/page/view/child/Main'
import work from '@/page/view/child/work'
import addRess from '@/page/view/child/addRess'
import urban from '@/page/view/child/urban'
import organization from '@/page/view/child/organization'
import population from '@/page/view/child/population'
import house from '@/page/view/child/house'
import edifice from '@/page/view/child/edifice'
import quarters from '@/page/view/child/quarters'
import organment from '@/page/view/child/organment'

Vue.use(Router)

export default new Router({
  routes: [
    { path: '/', redirect: "/Main" },
    { path: '/Login', name: 'Login', component: Login },
    {
      path: '/Home', name: 'Home', component: Home,
      children: [
        {
          path: '/Main', name: 'Main', component: Main,
          children: [
            { path: '/work', name: '工作台', component: work },
            { path: '/addRess', name: '标准地址管理', component: addRess },
            { path: '/urban', name: '城市部件', component: urban },
            { path: '/organization', name: '非公有制解决组织', component: organization },
            { path: '/population', name: '社会组织管理', component: population },
            { path: '/house', name: '实有人口管理', component: house },
            { path: '/edifice', name: '房屋管理', component: edifice },
            { path: '/quarters', name: '建筑物管理', component: quarters },
            { path: '/organment', name: '小区管理', component: organment },
          ]
        }
      ]
    }
  ]
})
