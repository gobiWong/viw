import React, { PureComponent, Fragment } from 'react';
import { routerRedux } from 'dva/router';
// import { Table, Button, Input, Select, message, Popconfirm, Divider, Badge } from 'antd';
import { getOperateInfo } from '../../utils/localstorage';

//控制每个页面地址栏输入跳转权限，
export default class ExceptionNoAuth extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      data: props.value,
      loading: false,
    };
  }

  componentDidMount(){
    const { 
      pagedispatch,
      pagelocation
     } = this.props;

    let operateInfo = getOperateInfo();
    operateInfo = JSON.parse(operateInfo);
    // if(!operateInfo[pagelocation.pathname]){
    //   // 跳转到首页
    //   pagedispatch(routerRedux.push('/exception/404'));
    // }
  }

  render() {
    return (
      <Fragment>
      </Fragment>
    );
  }
}
