import { routerRedux } from 'dva/router';
import {
  addEqAttribution,
  fetchEqAttribution,
  editEqAttribution,
  removeEqAttribution,
  fetchEqAttributionByCondition,
} from '../services/equipmentOwen';
import { notification } from 'antd';
import { setEqattributionInfo } from '../utils/localstorage';
import { unauth_code } from '../utils/common';

export default {
  namespace: 'equipmentOwen',

  state: {
    data: {
      list: [],
      pagination: {},
    },
    equipmentAttributionData: [],
  },

  effects: {
    *fetchOwen({ payload }, { call, put }) {
      const response = yield call(fetchEqAttribution, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.attributionInfo.data,
            pagination: {
              total: response.ResponseData.attributionInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEqattributionInfo(JSON.stringify(result.list));
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchOwenByCondition({ payload }, { call, put }) {
      const response = yield call(fetchEqAttributionByCondition, payload);

      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
        } else {
          yield put({
            type: 'saveOwenConditionData',
            payload: response.ResponseData.attributionInfo,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addOwen({ payload, callback }, { call, put }) {
      const response = yield call(addEqAttribution, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.attributionInfo.data,
            pagination: {
              total: response.ResponseData.attributionInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *removeOwen({ payload, callback }, { call, put }) {
      const response = yield call(removeEqAttribution, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.attributionInfo.data,
            pagination: {
              total: response.ResponseData.attributionInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          if (callback) callback(response.ResponseState.toLowerCase());
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editOwen({ payload, callback }, { call, put }) {
      const response = yield call(editEqAttribution, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.attributionInfo.data,
            pagination: {
              total: response.ResponseData.attributionInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          if (callback) callback(response.ResponseState.toLowerCase());
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    saveOwenConditionData(state, action) {
      return {
        ...state,
        equipmentAttributionData: action.payload,
      };
    },
  },
};
