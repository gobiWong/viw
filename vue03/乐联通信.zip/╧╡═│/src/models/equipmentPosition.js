import { routerRedux } from 'dva/router';
import {
  addEqLocation,
  fetchEqLocation,
  removeEqLocation,
  editEqLocation,
  fetchEqLocationByCondition,
} from '../services/equipmentPosition';
import { notification } from 'antd';
import { setEqlocationInfo } from '../utils/localstorage';
import { unauth_code } from '../utils/common';

export default {
  namespace: 'equipmentPosition',

  state: {
    data: {
      list: [],
      pagination: {},
    },
    equipmentLocationData: [],
  },

  effects: {
    *fetchPosition({ payload }, { call, put }) {
      const response = yield call(fetchEqLocation, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.locationInfo.data,
            pagination: {
              total: response.ResponseData.locationInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEqlocationInfo(JSON.stringify(result.list));
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchEqLocationByCondition({ payload }, { call, put }) {
      const response = yield call(fetchEqLocationByCondition, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
        } else {
          yield put({
            type: 'saveLocationConditionData',
            payload: response.ResponseData.locationInfo,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addPosition({ payload, callback }, { call, put }) {
      const response = yield call(addEqLocation, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.locationInfo.data,
            pagination: {
              total: response.ResponseData.locationInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEqlocationInfo(JSON.stringify(result.list));
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *removePosition({ payload, callback }, { call, put }) {
      const response = yield call(removeEqLocation, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.locationInfo.data,
            pagination: {
              total: response.ResponseData.locationInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEqlocationInfo(JSON.stringify(result.list));
          if (callback) callback(response.ResponseState.toLowerCase());
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editPosition({ payload, callback }, { call, put }) {
      const response = yield call(editEqLocation, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.locationInfo.data,
            pagination: {
              total: response.ResponseData.locationInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEqlocationInfo(JSON.stringify(result.list));
          if (callback) callback(response.ResponseState.toLowerCase());
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    saveLocationConditionData(state, action) {
      return {
        ...state,
        equipmentLocationData: action.payload,
      };
    },
  },
};
