import { routerRedux } from 'dva/router';
import {
  addEqType,
  fetchEqType,
  editEqType,
  removeEqType,
  fetchEqTypeByCondition,
} from '../services/equipmentType';
import { notification } from 'antd';
import { setEqtypeInfo } from '../utils/localstorage';
import { unauth_code } from '../utils/common';

export default {
  namespace: 'equipmentType',

  state: {
    data: {
      list: [],
      pagination: {},
    },
    equipmentTypeData: [],
  },

  effects: {
    *fetchType({ payload }, { call, put }) {
      const response = yield call(fetchEqType, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.typeInfo.data,
            pagination: {
              total: response.ResponseData.typeInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEqtypeInfo(JSON.stringify(result.list));
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchEqTypeByCondition({ payload }, { call, put }) {
      const response = yield call(fetchEqTypeByCondition, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
        } else {
          yield put({
            type: 'saveTypeConditionData',
            payload: response.ResponseData.typeInfo,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addType({ payload, callback }, { call, put }) {
      const response = yield call(addEqType, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.typeInfo.data,
            pagination: {
              total: response.ResponseData.typeInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *removeType({ payload, callback }, { call, put }) {
      const response = yield call(removeEqType, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.typeInfo.data,
            pagination: {
              total: response.ResponseData.typeInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          if (callback) callback(response.ResponseState.toLowerCase());
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editType({ payload, callback }, { call, put }) {
      const response = yield call(editEqType, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.typeInfo.data,
            pagination: {
              total: response.ResponseData.typeInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    saveTypeConditionData(state, action) {
      return {
        ...state,
        equipmentTypeData: action.payload,
      };
    },
  },
};
