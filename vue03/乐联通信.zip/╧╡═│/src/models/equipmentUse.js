import { routerRedux } from 'dva/router';
import { stringify } from 'qs';
import { setEquseInfo } from '../utils/localstorage';
import {
  addEqUse,
  fetchEqUse,
  editEqUse,
  removeEqUse,
  fetchEqUseByCondition,
} from '../services/equipmentUse';
import { notification } from 'antd';
import { unauth_code, api_success } from '../utils/common';

export default {
  namespace: 'equipmentUse',

  state: {
    data: {
      list: [],
      pagination: {},
    },
    equipmentUseData: [],
  },

  effects: {
    *fetchUse({ payload }, { call, put }) {
      const response = yield call(fetchEqUse, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.useInfo.data,
            pagination: {
              total: response.ResponseData.useInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          setEquseInfo(JSON.stringify(result.list));
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchEqUseByCondition({ payload }, { call, put }) {
      const response = yield call(fetchEqUseByCondition, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
        } else {
          yield put({
            type: 'saveUseConditionData',
            payload: response.ResponseData.useInfo,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    //新增设备用途
    *addUse({ payload, callback }, { call, put }) {
      const response = yield call(addEqUse, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.useInfo.data,
            pagination: {
              total: response.ResponseData.useInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *removeUse({ payload, callback }, { call, put }) {
      const response = yield call(removeEqUse, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.useInfo.data,
            pagination: {
              total: response.ResponseData.useInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          if (callback) callback();
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editUse({ payload, callback }, { call, put }) {
      const response = yield call(editEqUse, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.useInfo.data,
            pagination: {
              total: response.ResponseData.useInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          if (callback) callback(response.ResponseState.toLowerCase());
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    saveUseConditionData(state, action) {
      return {
        ...state,
        equipmentUseData: action.payload,
      };
    },
  },
};
