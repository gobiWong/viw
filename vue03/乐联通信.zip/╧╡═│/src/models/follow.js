import { routerRedux } from 'dva/router';
import {
  fetchCompanyFollow,
  removeCompanyFollow,
  editCompanyFollow,
  addCompanyFollow,
  fetchCompany,
} from '../services/follow';
import { notification } from 'antd';
import { unauth_code } from '../utils/common';

export default {
  namespace: 'follow',

  state: {
    data: {
      list: [],
      pagination: {},
    },
    companyInfo: [],
  },

  effects: {
    *fetchFollow({ payload }, { call, put }) {
      const response = yield call(fetchCompanyFollow, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.followInfo.data,
            pagination: {
              total: response.ResponseData.followInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addFollow({ payload, callback }, { call, put }) {
      const response = yield call(addCompanyFollow, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          const result = {
            list: response.ResponseData.followInfo.data,
            pagination: {
              total: response.ResponseData.followInfo.total,
            },
          };

          yield put({
            type: 'save',
            payload: result,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editFollow({ payload, callback }, { call, put }) {
      const response = yield call(editCompanyFollow, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          const result = {
            list: response.ResponseData.followInfo.data,
            pagination: {
              total: response.ResponseData.followInfo.total,
            },
          };

          yield put({
            type: 'save',
            payload: result,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *removeFollow({ payload, callback }, { call, put }) {
      const response = yield call(removeCompanyFollow, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          const result = {
            list: response.ResponseData.followInfo.data,
            pagination: {
              total: response.ResponseData.followInfo.total,
            },
          };

          yield put({
            type: 'save',
            payload: result,
          });

          if (callback) callback();
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchCompany({ payload }, { call, put }) {
      const response = yield call(fetchCompany, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          yield put({
            type: 'saveCompanyInfo',
            payload: response.ResponseData.companySelect,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    saveCompanyInfo(state, action) {
      return {
        ...state,
        companyInfo: action.payload,
      };
    },
  },
};
