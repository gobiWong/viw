import { routerRedux } from 'dva/router';
import { stringify } from 'qs';
import { accountLogin, accountLogout, getImgCaptcha } from '../services/login';
import { setAuthority } from '../utils/authority';
import { reloadAuthorized } from '../utils/Authorized';
import { api_success } from '../utils/common';
import { getPageQuery } from '../utils/utils';
import { setUserInfo, setAccessToken, setMenuInfo, setOperateInfo } from '../utils/localstorage';
import { notification } from 'antd';
export default {
  namespace: 'login',

  state: {
    status: undefined,
  },

  //4.登入处理逻辑
  effects: {
    *login({ payload, callback }, { call, put }) {
      const response = yield call(accountLogin, payload);
      if (response.ResponseState.toLowerCase() != api_success) {
        notification['error']({
          message: '操作提示',
          description: response.ResponseMessage,
          duration: 3,
        });
      } else {
        notification['success']({
          message: '操作提示',
          description: response.ResponseMessage,
          duration: 2,
        });
        let result = {
          status: response.ResponseState,
          currentAuthority: response.ResponseData.currentAuthority,
        };

        //授权
        yield put({
          type: 'changeLoginStatus',
          payload: result,
        });
        //将accesstokne和userinfo存入localstorage
        setUserInfo(JSON.stringify(response.ResponseData));
        setAccessToken(response.ResponseData.accessToken);

        setMenuInfo(JSON.stringify(response.ResponseData.permissionInfo.menuInfo));
        setOperateInfo(JSON.stringify(response.ResponseData.permissionInfo.operateInfo));

        reloadAuthorized();
        const urlParams = new URL(window.location.href);
        const params = getPageQuery();
        let { redirect } = params;
        if (redirect) {
          const redirectUrlParams = new URL(redirect);
          if (redirectUrlParams.origin === urlParams.origin) {
            redirect = redirect.substr(urlParams.origin.length);
            if (redirect.startsWith('/#')) {
              redirect = redirect.substr(2);
            }
          } else {
            window.location.href = redirect;
            return;
          }
        }
        yield put(routerRedux.replace(redirect || '/'));
      }
      if (callback) callback(response.ResponseState);
    },

    *logout({ payload, callback }, { call, put }) {
      // const response = yield call(accountLogout, payload);
      localStorage.clear();
      yield put({
        type: 'changeLoginStatus',
        payload: {
          status: false,
          currentAuthority: 'guest',
        },
      });
      reloadAuthorized();
      yield put(
        routerRedux.replace({
          pathname: '/user/login',
          search: stringify({
            redirect: window.location.href,
          }),
        })
      );
    },

    *getImgCaptcha({ payload, callback }, { call, put }) {
      const response = yield call(getImgCaptcha, payload);
      if (response.ResponseState == api_success) {
        if (callback) callback(response.ResponseState, response.ResponseData.captcha);
      }
    },
  },

  reducers: {
    changeLoginStatus(state, { payload }) {
      setAuthority(payload.currentAuthority);
      return {
        ...state,
      };
    },
  },
};
