import { routerRedux } from 'dva/router';
import { fetchCompany, removeCompany,
         addCompany,editCompany, fetchInfo,
         addCallCenter,editCallCenter,removeCallCenter,
         addVos,editVos,removeVos,
         addUnifiedPlatform,editUnifiedPlatform,removeUnifiedPlatform,
         seeCompanyInfo
         } from '../services/manage';
import { notification } from 'antd';
import { unauth_code } from '../utils/common';
// import { setCompanyNeedInfo } from '../utils/localstorage';

export default {
  namespace: 'manage',
  state: {
    data: {
      list: [],
      pagination: {},
    },
    info:[],
    seeDate:[],
    selectedCompanyInfo: []
  },

  effects: {

    *fetchManage({ payload }, { call, put }) {
      const response = yield call(fetchCompany, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
          const result = {
            list: response.ResponseData.companyInfo.data, 
            pagination: {
              total: response.ResponseData.companyInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        
      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
      
    },
    *setSelectedCompanyInfo({ payload, callback }, { put }) {
      yield put({
        type: 'setSelectedCompany',
        payload: payload,
      });
      if(callback) callback(true);
    },
    *seeCompanyInfo({ payload,callback }, { call, put }) {
      const response = yield call(seeCompanyInfo, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
          yield put({
            type: 'saveSeeDate',
            payload: response.ResponseData,
          });
        }
        
      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }

      if (callback) callback(response.ResponseState.toLowerCase(), response.ResponseData);
      
    },

    *fetchInfo({ payload }, { call, put }) {
      const response = yield call(fetchInfo, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
          yield put({
            type: 'saveInfo',
            payload: response.ResponseData.CompanyNeedInfo,
          });
        //  setCompanyNeedInfo(JSON.stringify(response.ResponseData.CompanyNeedInfo));
        }
        
      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addManage({ payload, callback }, { call, put }) {
      const response = yield call(addCompany, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2
          });
  
          const result = {
            list: response.ResponseData.companyInfo.data,
            pagination: {
              total: response.ResponseData.companyInfo.total,
            },
          };
  
          yield put({
            type: 'save',
            payload: result,
          });
  
        }

        if (callback) callback(response.ResponseState.toLowerCase());

      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }

    },

    *editManage({ payload, callback }, { call, put }) {
      const response = yield call(editCompany, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
  
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2
          });
  
          const result = {
            list: response.ResponseData.companyInfo.data,
            pagination: {
              total: response.ResponseData.companyInfo.total,
            },
          };
  
          yield put({
            type: 'save',
            payload: result,
          });
  
        }

        if (callback) callback(response.ResponseState.toLowerCase());

      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }

    },

    *removeManage({ payload, callback }, { call, put }) {
      const response = yield call(removeCompany, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
  
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2
          });
  
          const result = {
            list: response.ResponseData.companyInfo.data,
            pagination: {
              total: response.ResponseData.companyInfo.total,
            },
          };
  
          yield put({
            type: 'save',
            payload: result,
          });
  
          if (callback) callback();
  
        }
      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
      
    },

    //编辑统一平台

    *addUnifiedPlatform({ payload, callback }, { call, put }) {
      const response = yield call(addUnifiedPlatform, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2
          });

  
        }

        if (callback) callback(response.ResponseState.toLowerCase());

      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }

    },

    *editUnifiedPlatform({ payload, callback }, { call, put }) {
      const response = yield call(editUnifiedPlatform, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
  
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2
          });
  
      
        }

        if (callback) callback(response.ResponseState.toLowerCase());

      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }

    },

    *removeUnifiedPlatform({ payload, callback }, { call, put }) {
      const response = yield call(removeUnifiedPlatform, payload);
      if(response.ResponseCode != unauth_code){
        if(response.ResponseState.toLowerCase() != 'success'){
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3
          });
        }else{
  
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2
          });

          
  
          if (callback) callback();
  
        }
      }else{
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
      
    },

        //编辑VOS平台

        *addVos({ payload, callback }, { call, put }) {
          const response = yield call(addVos, payload);
          if(response.ResponseCode != unauth_code){
            if(response.ResponseState.toLowerCase() != 'success'){
              notification['error']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 3
              });
            }else{
              notification['success']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 2
              });
      
      
            }
    
            if (callback) callback(response.ResponseState.toLowerCase());
    
          }else{
            localStorage.clear();
            yield put(routerRedux.push(`/user/login`));
          }
    
        },
    
        *editVos({ payload, callback }, { call, put }) {
          const response = yield call(editVos, payload);
          if(response.ResponseCode != unauth_code){
            if(response.ResponseState.toLowerCase() != 'success'){
              notification['error']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 3
              });
            }else{
      
              notification['success']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 2
              });
    
      
            }
    
            if (callback) callback(response.ResponseState.toLowerCase());
    
          }else{
            localStorage.clear();
            yield put(routerRedux.push(`/user/login`));
          }
    
        },
    
        *removeVos({ payload, callback }, { call, put }) {
          const response = yield call(removeVos, payload);
          if(response.ResponseCode != unauth_code){
            if(response.ResponseState.toLowerCase() != 'success'){
              notification['error']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 3
              });
            }else{
      
              notification['success']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 2
              });
    
              if (callback) callback();
      
            }
          }else{
            localStorage.clear();
            yield put(routerRedux.push(`/user/login`));
          }
          
        },

         //编辑呼叫中心平台

         *addCallCenter({ payload, callback }, { call, put }) {
          const response = yield call(addCallCenter, payload);
          if(response.ResponseCode != unauth_code){
            if(response.ResponseState.toLowerCase() != 'success'){
              notification['error']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 3
              });
            }else{
              notification['success']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 2
              });
    
            }
    
            if (callback) callback(response.ResponseState.toLowerCase());
    
          }else{
            localStorage.clear();
            yield put(routerRedux.push(`/user/login`));
          }
    
        },
    
        *editCallCenter({ payload, callback }, { call, put }) {
          const response = yield call(editCallCenter, payload);
          if(response.ResponseCode != unauth_code){
            if(response.ResponseState.toLowerCase() != 'success'){
              notification['error']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 3
              });
            }else{
      
              notification['success']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 2
              });
      
            }
    
            if (callback) callback(response.ResponseState.toLowerCase());
    
          }else{
            localStorage.clear();
            yield put(routerRedux.push(`/user/login`));
          }
    
        },
    
        *removeCallCenter({ payload, callback }, { call, put }) {
          const response = yield call(removeCallCenter, payload);
          if(response.ResponseCode != unauth_code){
            if(response.ResponseState.toLowerCase() != 'success'){
              notification['error']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 3
              });
            }else{
      
              notification['success']({
                message: '操作提示',
                description: response.ResponseMessage,
                duration: 2
              });
    
      
              if (callback) callback();
      
            }
          }else{
            localStorage.clear();
            yield put(routerRedux.push(`/user/login`));
          }
          
        },
},


reducers: {
  save(state, action) {
    return {
      ...state,
      data: action.payload,
    };
  },
  saveInfo(state, action) {
    return {
      ...state,
      info: action.payload,
    };
  },
  setSelectedCompany(state, action) {
    return {
      ...state,
      selectedCompanyInfo: action.payload,
    };
  },
  saveSeeDate(state, action) {
    return {
      ...state,
      seeDate: action.payload,
    };
  },
},
};
