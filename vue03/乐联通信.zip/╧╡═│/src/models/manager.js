import { routerRedux } from 'dva/router';
import {
  fetchUser,
  addManager,
  editManager,
  removeManager,
  addUserRole,
} from '../services/manager';
import { notification } from 'antd';
import { unauth_code } from '../utils/common';
export default {
  namespace: 'manager',
  state: {
    data: {
      list: [],
      pagination: {},
    },
  },

  effects: {
    *fetchUser({ payload }, { call, put }) {
      const response = yield call(fetchUser, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.userInfo.data,
            pagination: {
              total: response.ResponseData.userInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addManager({ payload, callback }, { call, put }) {
      const response = yield call(addManager, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.userInfo.data,
            pagination: {
              total: response.ResponseData.userInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editManager({ payload, callback }, { call, put }) {
      const response = yield call(editManager, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.userInfo.data,
            pagination: {
              total: response.ResponseData.userInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *remove({ payload, callback }, { call, put }) {
      const response = yield call(removeManager, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
          const result = {
            list: response.ResponseData.userInfo.data,
            pagination: {
              total: response.ResponseData.userInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
          if (callback) callback();
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addUserRole({ payload, callback }, { call, put }) {
      const response = yield call(addUserRole, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            description: '操作成功',
            duration: 2,
          });
          const result = {
            list: response.ResponseData.userInfo.data,
            pagination: {
              total: response.ResponseData.userInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
  },
};
