import { routerRedux } from 'dva/router';
import { fetchOperateByCondition, addOperate, fetchOperatePermission } from '../services/operation';
import { notification } from 'antd';
import { unauth_code, api_success } from '../utils/common';

export default {
  namespace: 'operation',

  state: {
    data: [],
  },

  effects: {
    *fetchOperateByCondition({ payload, callback }, { call, put }) {
      const response = yield call(fetchOperateByCondition, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          yield put({
            type: 'save',
            payload: response.ResponseData.operateInfo,
          });
        }
        if (callback)
          callback(response.ResponseState.toLowerCase(), response.ResponseData.operateInfo);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addOperate({ payload, callback }, { call, put }) {
      const response = yield call(addOperate, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          yield put({
            type: 'save',
            payload: response.ResponseData.operateInfo,
          });
        }

        if (callback)
          callback(response.ResponseState.toLowerCase(), response.ResponseData.operateInfo);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
  },
};
