import { routerRedux } from 'dva/router';
import {
  fetchRole,
  addRole,
  editRole,
  removeRole,
  fetchRoleByCondition,
  fetchPermission,
  addPermission,
  fetchPermissionByRole,
} from '../services/role';
import { notification } from 'antd';

import { unauth_code } from '../utils/common';

export default {
  namespace: 'role',
  state: {
    data: {
      list: [],
      pagination: {},
    },
    roleConditionData: [],
    permissionData: [],
    rolePermissionData: [],
  },

  effects: {
    *fetchRole({ payload }, { call, put }) {
      const response = yield call(fetchRole, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          const result = {
            list: response.ResponseData.roleInfo.data,
            pagination: {
              total: response.ResponseData.roleInfo.total,
            },
          };
          yield put({
            type: 'save',
            payload: result,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchRoleByCondition({ payload }, { call, put }) {
      const response = yield call(fetchRoleByCondition, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
        } else {
          yield put({
            type: 'saveRoleConditionData',
            payload: response.ResponseData.roleInfo,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addRole({ payload, callback }, { call, put }) {
      const response = yield call(addRole, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          const result = {
            list: response.ResponseData.roleInfo.data,
            pagination: {
              total: response.ResponseData.roleInfo.total,
            },
          };

          yield put({
            type: 'save',
            payload: result,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editRole({ payload, callback }, { call, put }) {
      const response = yield call(editRole, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          const result = {
            list: response.ResponseData.roleInfo.data,
            pagination: {
              total: response.ResponseData.roleInfo.total,
            },
          };

          yield put({
            type: 'save',
            payload: result,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *removeRole({ payload, callback }, { call, put }) {
      const response = yield call(removeRole, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });

          const result = {
            list: response.ResponseData.roleInfo.data,
            pagination: {
              total: response.ResponseData.roleInfo.total,
            },
          };

          yield put({
            type: 'save',
            payload: result,
          });

          if (callback) callback();
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchPermission({ payload }, { call, put }) {
      const response = yield call(fetchPermission, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          yield put({
            type: 'savePermissionData',
            payload: response.ResponseData.permissionInfo,
          });
        }
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addPermission({ payload, callback }, { call, put }) {
      const response = yield call(addPermission, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase());
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *fetchPermissionByRole({ payload, callback }, { call, put }) {
      const response = yield call(fetchPermissionByRole, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != 'success') {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          yield put({
            type: 'saveRolePermissionData',
            payload: response.ResponseData,
          });
        }
        if (callback) callback(response.ResponseState.toLowerCase(), response.ResponseData);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    saveRoleConditionData(state, action) {
      return {
        ...state,
        roleConditionData: action.payload,
      };
    },
    savePermissionData(state, action) {
      return {
        ...state,
        permissionData: action.payload,
      };
    },
    saveRolePermissionData(state, action) {
      return {
        ...state,
        rolePermissionData: action.payload,
      };
    },
  },
};
