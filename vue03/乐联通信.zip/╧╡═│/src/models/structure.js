import { routerRedux } from 'dva/router';
import { fetchStructureInfo, addStructure, editStructure, deleteStructure } from '../services/structure';
import { notification } from 'antd';
import { unauth_code, api_success } from '../utils/common';

export default {
  namespace: 'structure',

  state: {},

  effects: {
    *fetchStructureInfo({ payload, callback }, { call, put }) {
      const response = yield call(fetchStructureInfo, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {

        }

        if (callback) callback(response.ResponseState.toLowerCase(), response.ResponseData.structureInfo);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *addStructure({ payload, callback }, { call, put }) {
      const response = yield call(addStructure, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase(), response.ResponseData.structureInfo);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *editStructure({ payload, callback }, { call, put }) {
      const response = yield call(editStructure, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase(), response.ResponseData.structureInfo);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },

    *deleteStructure({ payload, callback }, { call, put }) {
      const response = yield call(deleteStructure, payload);
      if (response.ResponseCode != unauth_code) {
        if (response.ResponseState.toLowerCase() != api_success) {
          notification['error']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 3,
          });
        } else {
          notification['success']({
            message: '操作提示',
            description: response.ResponseMessage,
            duration: 2,
          });
        }

        if (callback) callback(response.ResponseState.toLowerCase(), response.ResponseData.structureInfo);
      } else {
        localStorage.clear();
        yield put(routerRedux.push(`/user/login`));
      }
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
  },
};
