import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Button,
  DatePicker,
  Popconfirm,
  Modal,
  Badge,
  Divider,
} from 'antd';
const { RangePicker } = DatePicker;

import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import {
  common_status,
  common_status_map,
  common_status_option,
  badge_status_map,
} from '../../../utils/status';
import StandardTable from '../../../components/ManagerTable';
import { getOperateInfo } from '../../../utils/localstorage';
import styles from './Index.less';

const FormItem = Form.Item;
const { Option } = Select;

//构造状态option
const statusOptions = common_status_option.map(item => {
  return <Option key={item.key}>{item.name}</Option>;
});

//新增管理员对话框
const CreateManagerForm = Form.create()(props => {
  const {
    addUserModalVisible,
    form,
    handleAddUser,
    handleAddUserModalVisible,
    handleClose,
    formUserAddValues,
    modalTitle,
    passwordRequired,
  } = props;

  const okHandle = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      if (err) return;
      handleAddUser(fieldsValue, form);
    });
  };
  const  cancel = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
     form.resetFields();
     handleClose(fieldsValue, form);
    });
   
  }

  return (
    <Modal
      title={modalTitle}
      visible={addUserModalVisible}
      onOk={okHandle}
      onCancel={() => cancel()}
    >
      <Form>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="管理员名称">
          {form.getFieldDecorator('user_name', {
            initialValue: formUserAddValues.user_name,
            validateFirst: true,
            rules: [{ required: true, whitespace: true, message: '请输入管理员名称' }],
          })(<Input placeholder="请输入" />)}
        </FormItem>

        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="管理员代码">
          {form.getFieldDecorator('user_code', {
            initialValue: formUserAddValues.user_code,
            validateFirst: true,
            rules: [{ required: true, whitespace: true, message: '请输入管理员代码' }],
          })(<Input placeholder="请输入" />)}
        </FormItem>

        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="登录密码">
          {form.getFieldDecorator('password', {
            initialValue: '',
            validateFirst: true,
            rules: [{ required: passwordRequired, whitespace: true, message: '请输入登录密码' }],
          })(<Input type="password" placeholder="请输入" />)}
        </FormItem>

        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="确认密码">
          {form.getFieldDecorator('password_confirmation', {
            initialValue: '',
            validateFirst: true,
            rules: [{ required: passwordRequired, whitespace: true, message: '请输入确认密码' }],
          })(<Input type="password" placeholder="请输入" />)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
          {form.getFieldDecorator('status', {
            initialValue: formUserAddValues.status,
            validateFirst: true,
            rules: [{ required: true, whitespace: true, message: '请选择管理员状态' }],
          })(<Select size="default">{statusOptions}</Select>)}
        </FormItem>
      </Form>
    </Modal>
  );
});

//配置系统角色对话框
const CreateRoleForm = Form.create()(props => {
  const {
    roleModalVisible,
    form,
    handleAddRole,
    handleRoleModalVisible,
    formRoleAddValues,
    modalTitle,
    roleData,
  } = props;

  const okHandle = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      if (err) return;
      handleAddRole(fieldsValue, form);
    });
  };

  return (
    <Modal
      title={modalTitle}
      visible={roleModalVisible}
      onOk={okHandle}
      onCancel={() => handleRoleModalVisible()}
    >
      <Form>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="角色">
          {form.getFieldDecorator('role_id', {
            initialValue: formRoleAddValues.role_id,
            validateFirst: true,
            // rules: [{ required: true, message: '请选择角色' }],
          })(
            <Select
              showSearch
              mode="multiple"
              style={{ width: '100%' }}
              placeholder="请选择"
              optionFilterProp="children"
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {roleData.map(item => {
                return <Option key={item.role_id.toString()}>{item.role_name}</Option>;
              })}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

@connect(({ manager, role, loading }) => ({
  manager,
  role,
  loading: loading.models.manager,
}))
@Form.create()
export default class TableList extends PureComponent {
  state = {
    addUserModalVisible: false,
    modalTitle: '新增管理员',
    selectedRows: [],
    searchText: '',
    filterDropdownVisible: false,

    passwordRequired: true,
    formUserAddValues: {
      status: common_status_map.yes.toString(),
      user_name: '',
      user_code: '',
    },
    formQueryValues: {},

    formRoleAddValues: [],
    roleModalVisible: false,
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'manager/fetchUser',
      payload: {},
    });
    dispatch({
      type: 'role/fetchRoleByCondition',
      payload: {},
    });
  }

  //列表数据改变时
  handleManagerTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formQueryValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      page: pagination.current,
      perPageSize: pagination.pageSize,
      ...formQueryValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'manager/fetchUser',
      payload: params,
    });
  };

  //重置查询数据
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    this.setState({
      formQueryValues: {},
    });
    dispatch({
      type: 'manager/fetchUser',
      payload: {},
    });
  };

  //单个删除
  handleDeleteData = (e, text, data) => {
    const { dispatch } = this.props;

    dispatch({
      type: 'manager/remove',
      payload: {
        user_id: text.user_id,
        filters: this.state.formQueryValues,
      },
      callback: () => {
        this.setState({
          selectedRows: [],
        });
      },
    });
  };

  //编辑
  handleEditUser = (e, text, data) => {
    const formValuesArr = {
      user_id: text.user_id,
      user_name: text.user_name,
      user_code: text.user_code,
      status: text.status.toString(),
    };

    this.setState({
      modalTitle: '编辑管理员',
      passwordRequired: false,
      formUserAddValues: formValuesArr,
      addUserModalVisible: true,
    });
  };

  //配置系统角色
  handleRole = (e, text, data) => {
    let roleIds = [];
    if (text.user_role_has_many.length > 0) {
      text.user_role_has_many.forEach(element => {
        roleIds.push(element.role_id.toString());
      });
    }
    const formValuesArr = {
      user_id: text.user_id,
      role_id: roleIds,
    };

    this.setState({
      modalTitle: '配置系统角色',
      formRoleAddValues: formValuesArr,
      roleModalVisible: true,
    });
  };

  //选择
  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  //查询
  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      this.setState({
        formQueryValues: values,
      });
      dispatch({
        type: 'manager/fetchUser',
        payload: values,
      });
    });
  };
  handleClose = () => {
    this.setState({
      addUserModalVisible:false,
    })
  }

  //管理员对话框显隐
  handleAddUserModalVisible = flag => {
    const formValuesArr = {
      user_name: '',
      user_code: '',
      password: '',
      password_confirmation: '',
      status: common_status_map.yes.toString(),
    };

    this.setState({
      addUserModalVisible: !!flag,
      passwordRequired: true,
      modalTitle: '新增管理员',
      formUserAddValues: formValuesArr,
    });
  };

  //配置系统角色对话框显隐
  handleRoleModalVisible = flag => {
    const formValuesArr = {
      user_id: '',
      role_id: [],
    };

    this.setState({
      roleModalVisible: !!flag,
      formRoleAddValues: formValuesArr,
    });
  };

  //新增数据
  handleAddUser = (fields, form) => {
    const { dispatch } = this.props;
    let params = {
      user_id: this.state.formUserAddValues.user_id,
      user_name: fields.user_name,
      user_code: fields.user_code,
      password: fields.password,
      password_confirmation: fields.password_confirmation,
      status: fields.status,
      filters: this.state.formQueryValues,
    };

    let url = 'manager/addManager';
    if (this.state.formUserAddValues.user_id) {
      url = 'manager/editManager';
    }

    dispatch({
      type: url,
      payload: params,
      callback: result => {
        if (result == 'success') {
          form.resetFields();
          this.setState({
            addUserModalVisible: false,
          });
        }
      },
    });
  };

  //配置系统角色
  handleAddRole = (fields, form) => {
    const { dispatch } = this.props;

    let params = {
      user_id: this.state.formRoleAddValues.user_id,
      role_id: fields.role_id,
      filters: this.state.formQueryValues,
    };

    dispatch({
      type: 'manager/addUserRole',
      payload: params,
      callback: result => {
        if (result == 'success') {
          form.resetFields();
          this.setState({
            roleModalVisible: false,
          });
        }
      },
    });
  };

  //渲染高级查询
  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem label="管理员名称">
              {getFieldDecorator('query_user_name', {
                initialValue: this.state.formQueryValues.query_user_name,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>

          <Col md={8} sm={24}>
            <FormItem label="状态">
              {getFieldDecorator('query_status', {
                initialValue: this.state.formQueryValues.query_status,
              })(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="">全部</Option>
                  {statusOptions}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={12} sm={24}>
            <FormItem label="创建时间">
              {getFieldDecorator('created_at', {
                initialValue: this.state.formQueryValues.created_at,
              })(
                <RangePicker
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['Start Time', 'End Time']}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="end">
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <span style={{ float: 'right', marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
              </span>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  //渲染查询表单
  renderForm() {
    return this.renderAdvancedForm();
  }

  render() {
    const {
      manager: { data },
      role: { roleConditionData },
      loading,
      location,
    } = this.props;

    const currentOperations = JSON.parse(getOperateInfo());

    const {
      selectedRows,
      addUserModalVisible,
      formUserAddValues,
      modalTitle,
      roleModalVisible,
      formRoleAddValues,
      passwordRequired,
    } = this.state;

    const columns = [
      {
        title: '序号',
        dataIndex: 'sort',
        key: 'sort',
      },
      {
        title: '管理员名称',
        dataIndex: 'user_name',
        key: 'user_name',
      },

      {
        title: '管理员代码',
        dataIndex: 'user_code',
        key: 'user_code',
      },

      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        filters: [
          {
            text: common_status_option[0]['name'],
            value: common_status_option[0]['key'],
          },
          {
            text: common_status_option[1]['name'],
            value: common_status_option[1]['key'],
          },
        ],
        onFilter: (value, record) => record.status.toString() === value,
        render(val) {
          return <Badge status={badge_status_map[val]} text={common_status[val]} />;
        },
      },
      {
        title: '创建时间',
        dataIndex: 'created_at',
        key: 'created_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '更新时间',
        dataIndex: 'updated_at',
        key: 'updated_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '操作',
        key: 'operation',
        fixed: 'right',
        width: 180,
        render: (text, record, index) => (
          <Fragment>
            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].ADDUSERROLE ? (
              <div>
                <a href="javascript:;" onClick={this.handleRole.bind(this, text, record)}>
                  配置角色
                </a>
                <Divider type="vertical" />
              </div>
            ) : (
              ''
            )}

            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].EDITUSER ? (
              <div>
                <a href="javascript:;" onClick={this.handleEditUser.bind(this, text, record)}>
                  编辑
                </a>
                <Divider type="vertical" />
              </div>
            ) : (
              ''
            )}

            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].DELETEUSER ? (
              <Popconfirm
                placement="topRight"
                title="确定删除吗？"
                onConfirm={this.handleDeleteData.bind(this, text, record)}
                okText="Yes"
                cancelText="No"
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
            ) : (
              ''
            )}
          </Fragment>
        ),
      },
    ];

    const parentMethods = {
      handleAddUser: this.handleAddUser,
      handleAddUserModalVisible: this.handleAddUserModalVisible,
      handleClose:this.handleClose
    };

    const parentRoleMethods = {
      handleAddRole: this.handleAddRole,
      handleRoleModalVisible: this.handleRoleModalVisible,
    };
    //注释
    return (
      <PageHeaderLayout>
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>

            <div className={styles.tableListOperator}>
              {currentOperations &&
              currentOperations[location.pathname] &&
              currentOperations[location.pathname].ADDUSER ? (
                <Button
                  icon="plus"
                  type="primary"
                  onClick={() => this.handleAddUserModalVisible(true)}
                >
                  新增管理员
                </Button>
              ) : (
                ''
              )}
            </div>

            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleManagerTableChange}
            />
          </div>
        </Card>
        <CreateManagerForm
          {...parentMethods}
          addUserModalVisible={addUserModalVisible}
          formUserAddValues={formUserAddValues}
          modalTitle={modalTitle}
          passwordRequired={passwordRequired}
        />
        <CreateRoleForm
          {...parentRoleMethods}
          roleModalVisible={roleModalVisible}
          formRoleAddValues={formRoleAddValues}
          modalTitle={modalTitle}
          roleData={roleConditionData}
        />
      </PageHeaderLayout>
    );
  }
}
