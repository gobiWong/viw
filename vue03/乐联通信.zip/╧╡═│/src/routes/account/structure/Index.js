import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { Row, Col, Tree, Cascader, Modal, Button, Input, Form, Radio, Card } from 'antd';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import { api_success } from '../../../utils/common';
// import { getOperateInfo } from '../../../utils/localstorage';

@connect(({ structure, loading }) => ({
  structure,
  loading: loading.models.structure,
}))
@Form.create()
export default class Structure extends PureComponent {
  state = {
    departmentOptions: [],
    loading: false,
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'structure/fetchStructureInfo',
      payload: {},
      callback: (result, data) => {
        if (result == api_success) {
          this.setState({
            departmentOptions: data,
          });

          this.forceUpdate();
        }
      },
    });
  }

  // 新增部门
  onFormAddSubmit = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields(['name', 'value', 'parent'], (err, values) => {
      if (!err) {
        dispatch({
          type: 'structure/addStructure',
          payload: values,
          callback: (result, data) => {
            if (result == api_success) {
              this.setState({
                departmentOptions: data,
              });

              form.resetFields();
            }
          },
        });
      }
    });
  };

  // 删除部门
  onFormDeleteSubmit = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields(['department'], (err, values) => {
      if (!err) {
        dispatch({
          type: 'structure/deleteStructure',
          payload: values,
          callback: (result, data) => {
            if (result == api_success) {
              this.setState({
                departmentOptions: data,
              });

              form.resetFields();
            }
          },
        });
      }
    });
  };

  render() {
    const { loading, departmentOptions } = this.state;
    const { form } = this.props;

    return (
      <PageHeaderLayout>
        <div>
          <Card title="新增部门" bordered={false}>
            <Form onSubmit={this.onFormAddSubmit}>
              <Form.Item labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="">
                {form.getFieldDecorator('name', {
                  initialValue: '',
                  validateFirst: true,
                  rules: [{ required: true, whitespace: true, message: '请输入部门名称' }],
                })(<Input placeholder="请输入部门名称" style={{ width: 300 }} />)}
              </Form.Item>

              <Form.Item labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="">
                {form.getFieldDecorator('value', {
                  initialValue: '',
                  validateFirst: true,
                  rules: [
                    { required: true, whitespace: true, message: '请输入部门代码' },
                    { pattern: '^[0-9a-zA-Z_-]+$', message: '部门代码只能为字母数字和下划线' },
                  ],
                })(
                  <Input
                    placeholder="请输入部门代码"
                    onChange={e => {
                      e.target.value = e.target.value.toUpperCase();
                    }}
                    style={{ width: 300 }}
                  />
                )}
              </Form.Item>

              <Form.Item labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="">
                {form.getFieldDecorator('parent', {
                  initialValue: '',
                  validateFirst: true,
                })(
                  <Cascader
                    changeOnSelect={true}
                    options={departmentOptions}
                    onChange={this.onChangeCascader}
                    placeholder="请选择父级部门"
                    style={{ width: 300 }}
                  />
                )}
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit">
                  新增
                </Button>
              </Form.Item>
            </Form>
          </Card>

          <Card title="删除部门" bordered={false} style={{ marginTop: 10 }}>
            <Form onSubmit={this.onFormDeleteSubmit}>
              <Form.Item labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="">
                {form.getFieldDecorator('department', {
                  initialValue: '',
                  validateFirst: true,
                  rules: [{ required: true, message: '请选择部门' }],
                })(
                  <Cascader
                    changeOnSelect={true}
                    options={departmentOptions}
                    onChange={this.onChangeCascader}
                    placeholder="请选择父级部门"
                    style={{ width: 300 }}
                  />
                )}
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit">
                  删除
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      </PageHeaderLayout>
    );
  }
}
