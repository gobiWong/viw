import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import moment from 'moment';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Tooltip,
  Button,
  DatePicker,
  Popconfirm,
  Modal,
  message,
  Table,
  Badge,
  Divider,
  Cascader,
  Tabs,
  InputNumber,
} from 'antd';
const { RangePicker } = DatePicker;
import {
  record_type,
  companys_status_map,
  record_type_map,
  send_msg_map,
} from '../../../utils/status';
import ExceptionNoAuth from 'components/ExceptionNoAuth';
import Send from './sendMessage';
import TableForm from './TableForm';
import UnifiedForm from './UnifiedForm';
import ServerForm from './ServerForm';
import MessageForm from './MessageForm';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import {
  companys_status,
  companys_status_option,
  send_msg_status,
  send_msg_status_option,
  badge_status_map,
  balance_notice_way_type,
  balance_notice_waye_option
} from '../../../utils/status';
import { api_success } from '../../../utils/common';
import { getOperateInfo } from '../../../utils/localstorage';
import { CopyToClipboard } from 'react-copy-to-clipboard';

import styles from './Index.less';
import { random } from 'gl-matrix/src/gl-matrix/vec3';

const { TextArea } = Input;
const TabPane = Tabs.TabPane;
const FormItem = Form.Item;
const { Option } = Select;

// 构造状态option
const statusOptions = companys_status_option.map(item => {
  return <Option key={item.key}>{item.name}</Option>;
});

const sendMsgStatusOptions = send_msg_status_option.map(item => {
  return <Option key={item.key}>{item.name}</Option>;
});

const CreateSeeForm = Form.create()(props => {
  const {
    modalSeeVisible,
    form,
    handleChange,
    handleClick,
    onCopy,
    handleSee,
    handleSeeModalVisible,
    EquipmentInfo,
    companyFollowInfo,
    companyServerInfo,
    goPage,
    goPage2,
    // managerValues,
    // accountValues,
  } = props;

  let ccWebAddress = [];
  let companyName = companyServerInfo[0] ? companyServerInfo[0].company_name : '';
  let managerName = [];
  let managerPassword = [];
  let operatorName = [];
  let operatorPassword = [];
  let startExtension = [];
  let endExtension = [];
  let extensionPassword = [];
  let seatsName = [];
  let seatsPassword = [];
  let ccServerName = [];
  let ccSipPort = [];
  let vosAccount = [];
  let vosTelephonePassword = [];
  let vosWebPassword = [];
  let vosServerAddress = [];
  let vosSipPort = [];
  let registerTime = '注册间隔时间：60';

  if (companyServerInfo[0]) {
    if (companyServerInfo[0].call_center_has_many.length > 0) {
      for (var p in companyServerInfo[0].call_center_has_many) {
        //遍历json数组时，这么写p为索引
        managerName.push(companyServerInfo[0].call_center_has_many[p].manager_name);
        managerPassword.push(companyServerInfo[0].call_center_has_many[p].manager_password);
        operatorName.push(companyServerInfo[0].call_center_has_many[p].operator_name);
        operatorPassword.push(companyServerInfo[0].call_center_has_many[p].operator_password);
        seatsName.push(companyServerInfo[0].call_center_has_many[p].seats_name);
        seatsPassword.push(companyServerInfo[0].call_center_has_many[p].seats_password);
        ccServerName.push(companyServerInfo[0].call_center_has_many[p].call_center_server_has_one.server_api);

        startExtension.push(companyServerInfo[0].call_center_has_many[p].start_extension);
        endExtension.push(companyServerInfo[0].call_center_has_many[p].end_extension);
        extensionPassword.push(companyServerInfo[0].call_center_has_many[p].extension_password);
      }
    }
  }

  if (companyServerInfo[0]) {
    if (companyServerInfo[0].call_center_has_many.length > 0) {
      for (var p in companyServerInfo[0].call_center_has_many) {
        //遍历json数组时，这么写p为索引
        ccWebAddress.push(
          companyServerInfo[0].call_center_has_many[p].call_center_server_has_one.server_web
        );
        ccSipPort.push(
          companyServerInfo[0].call_center_has_many[p].call_center_server_has_one.sip_port
        );
      }
    }
  }

  if (companyServerInfo[0]) {
    if (companyServerInfo[0].vos_has_many.length > 0) {
      for (var p in companyServerInfo[0].vos_has_many) {
        //遍历json数组时，这么写p为索引
        vosAccount.push(companyServerInfo[0].vos_has_many[p].vos_account);
        vosTelephonePassword.push(companyServerInfo[0].vos_has_many[p].vos_telephone_password);
        vosWebPassword.push(companyServerInfo[0].vos_has_many[p].vos_web_password);
      }
    }
  }

  if (companyServerInfo[0]) {
    if (companyServerInfo[0].vos_has_many.length > 0) {
      for (var p in companyServerInfo[0].vos_has_many) {
        //遍历json数组时，这么写p为索引
        vosServerAddress.push(
          companyServerInfo[0].vos_has_many[p].vos_server_has_one.server_web
        );
        vosSipPort.push(companyServerInfo[0].vos_has_many[p].vos_server_has_one.sip_port);
      }
    }
  }

  const ccWebAddressValues = ccWebAddress.map(item => {
    return item;
  });

  const managerNameValues = managerName.map(item => {
    return item;
  });
  const managerPasswordValues = managerPassword.map(item => {
    return item;
  });
  const operatorNameValues = operatorName.map(item => {
    return item;
  });
  const operatorPasswordValues = operatorPassword.map(item => {
    return item;
  });
  const startExtensionValues = startExtension.map(item => {
    return item;
  });
  const endExtensionValues = endExtension.map(item => {
    return item;
  });
  const extensionPasswordValues = extensionPassword.map(item => {
    return item;
  });
  const seatsNameValues = seatsName.map(item => {
    return item;
  });
  const seatsPasswordsValues = seatsPassword.map(item => {
    return item;
  });
  const ccServerNameValues = ccServerName.map(item => {
    return item;
  });
  // console.log(ccServerNameValues,55555555)
  const ccSipPortValues = ccSipPort.map(item => {
    return item;
  });
  const vosAccountValues = vosAccount.map(item => {
    return item;
  });
  const vosWebPasswordValues = vosWebPassword.map(item => {
    return item;
  });
  const vosTelephonePasswordValues = vosTelephonePassword.map(item => {
    return item;
  });

  const vosServerAddressValues = vosServerAddress.map(item => {
    return item;
  });

  const vosSipPortValues = vosSipPort.map(item => {
    return item;
  });

  const managerValues =
    '平台登录地址：' +
    '\n' +
    ccWebAddressValues +
    '\n' +
    '\n' +
    '【管理员登录信息】' +
    '\n' +
    '公司名称：' +
    companyName +
    '\n' +
    '用户名:' +
    managerNameValues +
    '\n' +
    '密码：' +
    managerPasswordValues +
    '\n' +
    '\n' +
    '【坐席主管登录信息】' +
    '\n' +
    '公司名称：' +
    companyName +
    '\n' +
    '用户名:' +
    operatorNameValues +
    '\n' +
    '密码：' +
    operatorPasswordValues +
    '\n' +
    '\n' +
    '【普通坐席登录信息】' +
    '\n' +
    '公司名称：' +
    companyName +
    '\n' +
    '用户名:' +
    seatsNameValues +
    '\n' +
    '密码：' +
    seatsPasswordsValues +
    '\n' +
    '\n' +
    '【SIP账号注册信息】' +
    '\n' +
    '注册服务器：' +
    ccServerNameValues +
    '\n' +
    'sip端口号：' +
    ccSipPortValues +
    '\n' +
    registerTime +
    '\n' +
    'sip分机账号：' +
    startExtensionValues +
    '到' +
    endExtensionValues +
    '\n' +
    'sip密码：' +
    extensionPasswordValues +
    '\n' +
    '\n' +
    '【VOS注册信息】' +
    '\n' +
    '公网IP：' +
    vosServerAddressValues +
    '\n' +
    '端口：' +
    vosSipPortValues +
    '\n' +
    'sip账号：' +
    vosAccountValues +
    '\n' +
    'sip密码：' +
    vosTelephonePasswordValues +
    '\n' +
    '\n' +
    '【话费查询平台】' +
    '\n' +
    '平台登录地址：' +
    '\n' +
    vosServerAddressValues +
    '\n' +
    '类型：话机' +
    '\n' +
    '号码：' +
    vosAccountValues +
    '\n' +
    '密码：' +
    vosWebPasswordValues;

  const accountValues =
    '平台登录地址：' +
    '\n' +
    ccWebAddressValues +
    '\n' +
    '\n' +
    '【坐席主管登录信息】' +
    '\n' +
    '公司名称：' +
    companyName +
    '\n' +
    '用户名:' +
    operatorNameValues +
    '\n' +
    '密码：' +
    operatorPasswordValues +
    '\n' +
    '\n' +
    '【普通坐席登录信息】' +
    '\n' +
    '公司名称：' +
    companyName +
    '\n' +
    '用户名:' +
    seatsNameValues +
    '\n' +
    '密码：' +
    seatsPasswordsValues +
    '\n' +
    '\n' +
    '【话费查询平台】' +
    '\n' +
    '平台登录地址：' +
    '\n' +
    vosServerAddressValues +
    '\n' +
    '类型：话机' +
    '\n' +
    '号码：' +
    vosAccountValues +
    '\n' +
    '密码：' +
    vosWebPasswordValues +
    '\n' +
    '\n' +
    '====【注意事项】====' +
    '\n' +
    '1. 建议使用google浏览器' +
    '\n' +
    '2. 用户手册，请登录平台后在首页的“相关下载”栏目下载。' +
    '\n' +
    '3. 坐席主管登录密码，默认为随机数,如果需要更换密码，请提供一个相对复杂的密码让技术修改。' +
    '\n' +
    '4. 请不要修改坐席主管的用户名，如果要区分不同的坐席，可以修改坐席的姓名';

  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleSee(fieldsValue);
    });
  };

  const columns1 = [
    {
      title: 'MAC地址',
      dataIndex: 'mac_address',
      key: 'mac_address',
    },

    {
      title: '设备类型',
      dataIndex: 'equipment_name',
      key: 'equipment_name',
    },

    {
      title: '设备编码',
      dataIndex: 'equipment_code',
      key: 'equipment_code',
    },

    {
      title: '设备位置',
      dataIndex: 'equipment_location',
      key: 'equipment_location',
    },

    {
      title: '归属企业',
      dataIndex: 'company_name',
      key: 'company_name',
    },

    {
      title: '设备归属类型',
      dataIndex: 'equipment_attribution',
      key: 'equipment_attribution',
    },

    {
      title: '设备用途',
      dataIndex: 'equipment_use',
      key: 'equipment_use',
    },

    {
      title: '公网IP',
      dataIndex: 'public_network_ip',
      key: 'public_network_ip',
    },

    {
      title: 'IP地址',
      dataIndex: 'public_network_ip_area',
      key: 'public_network_ip_area',
    },

    {
      title: '内网IP',
      dataIndex: 'intranet_ip',
      key: 'intranet_ip',
    },

    {
      title: '备注信息',
      dataIndex: 'note',
      key: 'note2',
      fixed: 'right',
      render(text, record) {
        return (
          <Tooltip placement="top" title={text}>
            <span className={styles.note}>{text}</span>
          </Tooltip>
        );
      },
    },
  ];

  const columns = [
    {
      title: '企业名称',
      dataIndex: 'company_name',
      key: 'company_name',
      width: '15%',
    },
    {
      title: '跟进人',
      dataIndex: 'user_name',
      key: 'user_name',
      width: '15%',
    },

    {
      title: '记录类别',
      dataIndex: 'record_from',
      key: 'record_from',
      width: '15%',
      render(val) {
        return <Badge status={record_type_map[val]} text={record_type[val]} />;
      },
    },
    {
      title: '原始内容',
      dataIndex: 'origin_content',
      key: 'origin_content',
      render(text, record) {
        if (record.record_from == 1 && text != '') {
          let originValue = [];
          for (var key in text) {
            originValue.push(text[key]);
          }
          return (
            <Tooltip
              placement="top"
              title={originValue.map(item => {
                return <li key={item}> {item} </li>;
              })}
            >
              <li className={styles.note}>
                {originValue.map(item => {
                  return <span key={item}> {item + '/'} </span>;
                })}
              </li>
            </Tooltip>
          );
        } else {
          return (
            <Tooltip placement="top" title={text}>
              <span className={styles.note}> {text} </span>
            </Tooltip>
          );
        }
      },
    },
    {
      title: '当前内容',
      dataIndex: 'current_content',
      key: 'current_content',
      render(text, record) {
        if (record.record_from == 1 && text != '') {
          let currentValue = [];
          for (var key in text) {
            currentValue.push(text[key]);
          }
          return (
            <Tooltip
              placement="top"
              title={currentValue.map(item => {
                return <li key={item}> {item} </li>;
              })}
            >
              <li className={styles.note}>
                {currentValue.map(item => {
                  return <span key={item}> {item + '/'} </span>;
                })}
              </li>
            </Tooltip>
          );
        } else {
          return (
            <Tooltip placement="top" title={text}>
              <span className={styles.note}> {text} </span>
            </Tooltip>
          );
        }
      },
    },
  ];

  return (
    <Modal
      title="查看信息"
      visible={modalSeeVisible}
      onOk={okHandle}
      onCancel={() => handleSeeModalVisible(false)}
      footer={null}
      width={'33%'}
    >
      <Row gutter={2}>
        <Col xl={10} lg={10} md={10} sm={10} xs={10}>
          <Card
            className={styles.projectList}
            style={{ marginBottom: 24 }}
            title="基本信息"
            bordered={false}
            bodyStyle={{ padding: 0 }}
          >
            <div className={styles.essentialInformation}>
              <ul>
                <li>公司全称: {companyName ? companyName : ''}</li>
                <li>
                  公司简称: {companyServerInfo[0] ? companyServerInfo[0].company_abbreviation : ''}
                </li>
                <li>公司代码: {companyServerInfo[0] ? companyServerInfo[0].company_code : ''}</li>
                <li>联系QQ: {companyServerInfo[0] ? companyServerInfo[0].contact_qq : ''}</li>
                <li>联系邮箱: {companyServerInfo[0] ? companyServerInfo[0].contact_email : ''}</li>
                <li>联系电话: {companyServerInfo[0] ? companyServerInfo[0].contact_mobile : ''}</li>
                <li>
                  公司地址: {companyServerInfo[0] ? companyServerInfo[0].company_address : ''}
                </li>
              </ul>
            </div>
            <div className={styles.remarks}>
              备注信息测试客户名称“{companyName ? companyName : ''}”
            </div>
          </Card>
          <Card
            bodyStyle={{ padding: 0 }}
            bordered={false}
            className={styles.activeCard}
            title={companyName ? companyName + '账户信息' : '账户信息'}
          >
            <Tabs defaultActiveKey="1">
              <TabPane tab="管理员登录信息" key="1">
                <section className="section">
                  <textarea onChange={handleChange} rows={20} cols={48} value={managerValues}  />
                </section>
                <CopyToClipboard onCopy={onCopy} text={managerValues}>
                  <Button style={{ marginBottom: 10 }} onClick={handleClick}>
                    复制
                  </Button>
                </CopyToClipboard>
              </TabPane>
              <TabPane tab="客户信息" key="2">
                <section className="section">
                  <textarea onChange={handleChange} rows={20} cols={48} value={accountValues} />
                </section>
                <CopyToClipboard onCopy={onCopy} text={accountValues}>
                  <Button style={{ marginBottom: 10 }} onClick={handleClick}>
                    复制
                  </Button>
                </CopyToClipboard>
              </TabPane>
            </Tabs>
          </Card>
        </Col>
        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
          <Card
            style={{ marginBottom: 24 }}
            title="跟进记录"
            bodyStyle={{ padding: 0 }}
            // extra={<Link to="./followup">详情</Link>}
            extra={<Button onClick={goPage}>详情</Button>}
          >
            <Table
              rowKey={'company_operate_follow_record_id'}
              columns={columns}
              dataSource={companyFollowInfo.slice(0, 5)}
              pagination={false}
            />
          </Card>
          <Card
            style={{ marginBottom: 24 }}
            title="设备列表"
            extra={<Button onClick={goPage2}>详情</Button>}
          >
            <Table
              rowKey={'equipment_id'}
              columns={columns1}
              dataSource={EquipmentInfo.slice(0, 5)}
              pagination={false}
              scroll={{ x: 1000 }}
            />
          </Card>
        </Col>
      </Row>
    </Modal>
  );
});

const CreateShowNoteForm = Form.create()(props => {
  const { modalShowNoteVisible, currentNote, handleShowContentModalVisible } = props;
  return (
    <Modal
      title="备注信息"
      visible={modalShowNoteVisible}
      onCancel={() => handleShowContentModalVisible()}
      centered={true}
      footer={null}
      width={200}
    >
      <textarea
        value={currentNote}
        readOnly
        style={{ border: 'none', width: '100%', minHeight: 200, overflow: 'hidden' }}
      />
    </Modal>
  );
});

//发短信
const CreateSendShortForm = Form.create()(props => {
  const { modalSendShortVisible, form, handleSendShort, handleSendShortModalVisible } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleSendShort(fieldsValue);
    });
  };

  return (
    <Modal
      title="发送信息"
      visible={modalSendShortVisible}
      onOk={okHandle}
      onCancel={() => handleSendShortModalVisible()}
    >
      <TextArea placeholder="请输入" autosize style={{ marginBottom: 25 }} />
      <Send />
    </Modal>
  );
});

//发微信
// const CreateSendWechatForm = Form.create()(props => {
//   const { modalSendWechatVisible, form, handleSendWechat, handleSendWechatModalVisible } = props;
//   const okHandle = () => {
//     form.validateFields((err, fieldsValue) => {
//       if (err) return;
//       form.resetFields();
//       handleSendWechat(fieldsValue);
//     });
//   };
//   return (
//     <Modal
//       title="发送内容"
//       visible={modalSendWechatVisible}
//       onOk={okHandle}
//       onCancel={() =>handleSendWechatModalVisible()}
//   >
//       <TextArea placeholder="请输入要发送得信息" autosize />
//     </Modal>
//   );
// });

// //解绑微信弹框
// const CreateUntieForm = Form.create()(props => {
//   const { modalUntieVisible, form, handleUntie, handleUntieModalVisible } = props;
//   const okHandle = () => {
//     form.validateFields((err, fieldsValue) => {
//       if (err) return;
//       form.resetFields();
//       handleUntie(fieldsValue);
//     });
//   };
//   return (
//     <Modal
//       title="解除微信绑定"
//       visible={modalUntieVisible}
//       onOk={okHandle}
//       onCancel={() =>handleUntieModalVisible()}
//   >

//       <h2>是否要解除微信绑定？</h2>
//     </Modal>
//   );
// });

//vos
const CreateVosForm = Form.create()(props => {
  const { modalVosVisible, form, handleVos, handleVosModalVisible, vosInfo } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleVos(fieldsValue);
    });
  };
  const columns = [
    {
      title: '服务器',
      dataIndex: 'server_name',
      key: 'server_name',
    },
    {
      title: '账号',
      dataIndex: 'vos_account',
      key: 'vos_account',
    },
    {
      title: '账户余额',
      dataIndex: 'balance',
      key: 'balance',
    },
    {
      title: 'v话机密码',
      dataIndex: 'vos_telephone_password',
      key: 'vos_telephone_password',
    },
    {
      title: '网页密码',
      dataIndex: 'vos_web_password',
      key: 'vos_web_password',
    },
    {
      title: '查询余额',
      dataIndex: 'balance_query',
      key: 'balance_query',
    },
    {
      title: '余额提醒',
      dataIndex: 'balance_remind',
      key: 'balance_remind',
    },
    {
      title: '余额告警阈值',
      dataIndex: 'balance_warning',
      key: 'balance_warning',
    },
    {
      title: '余额提醒次数',
      dataIndex: 'balance_notice_times',
      key: 'balance_notice_times',
    },
    {
      title: '提醒方式',
      dataIndex: 'balance_notice_way',
      key: 'balance_notice_way',
      render(val) {
        return <Badge status={badge_status_map[val]} text={balance_notice_way_type[val]} />;
      },
    },
  ];

  return (
    <Modal
      title="vos信息"
      visible={modalVosVisible}
      onOk={okHandle}
      onCancel={() => handleVosModalVisible()}
      cancelText="返回"
      okText="保存"
      width={'400px'}
    >
      <Table
        rowKey={'vos_server_id'}
        columns={columns}
        dataSource={vosInfo}
        size="small"
        bordered
      />
    </Modal>
  );
});

//cc
const CreateCcForm = Form.create()(props => {
  const { modalCcVisible, form, handleCc, handleCcModalVisible, ccInfo } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleCc(fieldsValue);
    });
  };
  const columns = [
    {
      title: '类型',
      dataIndex: 'server_name',
      key: 'server_name3',
    },

    {
      title: '账户信息',
      dataIndex: 'enterprise_account',
      key: 'enterprise_account',
    },
    {
      title: '起始分机',
      dataIndex: 'start_extension',
      key: 'start_extension3',
    },
    {
      title: '结束分机',
      dataIndex: 'end_extension',
      key: 'end_extension3',
    },
    {
      title: '分机密码',
      dataIndex: 'extension_password',
      key: 'extension_password3',
    },
    {
      title: '坐席数量',
      dataIndex: 'seats_number',
      key: 'seats_number3',
    },
    {
      title: '管理员用户名',
      dataIndex: 'manager_name',
      key: 'manager_name3',
    },
    {
      title: '管理员密码',
      dataIndex: 'manager_password',
      key: 'manager_password3',
    },
    {
      title: '坐席主管',
      dataIndex: 'operator_name',
      key: 'operator_name3',
    },
    {
      title: '坐席主管密码',
      dataIndex: 'operator_password',
      key: 'operator_password3',
    },
    {
      title: '坐席用户名',
      dataIndex: 'seats_name',
      key: 'seats_name3',
    },
    {
      title: '坐席密码',
      dataIndex: 'seats_password',
      key: 'seats_password3',
    },
  ];

  return (
    <Modal
      title="呼叫中心信息"
      visible={modalCcVisible}
      onOk={okHandle}
      onCancel={() => handleCcModalVisible()}
      cancelText="返回"
      okText="保存"
      width={'400px'}
    >
      <Table
        rowKey={'enterprise_account'}
        columns={columns}
        dataSource={ccInfo}
        size="small"
        bordered
      />
    </Modal>
  );
});

//统一平台
const CreateUnifiedForm = Form.create()(props => {
  const {
    modalUnifiedVisible,
    form,
    handleUnified,
    handleUnifiedModalVisible,
    unifiedInfo,
  } = props;

  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleUnified(fieldsValue);
    });
  };
  const columns = [
    {
      title: '管理员用户名',
      dataIndex: 'manager_name',
      key: 'manager_name',
    },
    {
      title: '管理员密码',
      dataIndex: 'manager_password',
      key: 'manager_password4',
    },
    {
      title: '操作员用户名',
      dataIndex: 'operator_name',
      key: 'operator_name4',
    },
    {
      title: '操作员密码',
      dataIndex: 'operator_password',
      key: 'operator_password4',
    },
    {
      title: '坐席起始用户名',
      dataIndex: 'seats_start_name',
      key: 'seats_start_name4',
    },
    {
      title: '坐席结束用户名',
      dataIndex: 'seats_end_name',
      key: 'seats_end_name4',
    },
    {
      title: '坐席密码',
      dataIndex: 'seats_password',
      key: 'seats_password4',
    },
  ];

  return (
    <Modal
      title="统一平台信息"
      visible={modalUnifiedVisible}
      onOk={okHandle}
      onCancel={() => handleUnifiedModalVisible()}
      footer={null}
      width={'400px'}
    >
      <Table
        rowKey={'manager_name'}
        columns={columns}
        dataSource={unifiedInfo}
        size="small"
        bordered
      />
    </Modal>
  );
});



// 新增vos信息表单
const CreateNewvosForm = Form.create()(props => {
  const {
    modalNewvosVisible,
    form,
    handleNewvos,
    isAddCompany,
    handleNewvosModalVisible,
    vosInfo,
    info,
    handleDeleteVosData,
    onRef,
    handleSaveNewVos,
  } = props;
  const { getFieldDecorator } = form;
  const okHandle = () => {
    form.validateFields((err, values) => {
      if (err) return;
      form.resetFields();
      if (isAddCompany) {
        handleNewvos(values);
      } else {
        //将values中is_new为TRUE的数据过滤出来
        const params = values.vos.filter(item => {
          return item.isNew;
        });
        handleSaveNewVos(params);
      }
    });
  };
  return (
    <Modal
      title="管理vos信息"
      visible={modalNewvosVisible}
      onOk={okHandle}
      onCancel={() => handleNewvosModalVisible()}
      cancelText="返回"
      okText="保存"
      width={'400px'}
    >
      <Card>
        {getFieldDecorator('vos', {
          initialValue: vosInfo,
        })(<TableForm onRef={onRef} handleDeleteVosData={handleDeleteVosData} info={info} />)}
      </Card>
    </Modal>
  );
});

// 新增统一平台信息表单
const CreateNewUnifiedForm = Form.create()(props => {
  const {
    modalNewUnifiedVisible,
    form,
    handleNewUnified,
    handleSaveNewUnified,
    handleNewUnifiedModalVisible,
    unifiedInfo,
    info,
    handleDeleteUnifiedPlatformData,
    onRef,
    isAddCompany,
  } = props;
  const { getFieldDecorator } = form;
  const okHandle = () => {
    form.validateFields((err, values) => {
      if (err) return;
      form.resetFields();
      if (isAddCompany) {
        handleNewUnified(values);
      } else {
        //将values中is_new为TRUE的数据过滤出来
        const params = values.unified.filter(item => {
          return item.isNew;
        });
        handleSaveNewUnified(params);
      }
    });
  };
  return (
    <Modal
      title="管理统一平台信息"
      visible={modalNewUnifiedVisible}
      onOk={okHandle}
      onCancel={() => handleNewUnifiedModalVisible()}
      cancelText="返回"
      okText="确定"
      width={'400px'}
    >
      <Card>
        {getFieldDecorator('unified', {
          initialValue: unifiedInfo,
        })(
          <UnifiedForm
            onRef={onRef}
            handleDeleteUnifiedPlatformData={handleDeleteUnifiedPlatformData}
            info={info}
          />
        )}
      </Card>
    </Modal>
  );
});

//新增呼叫中心信息
const CreateServerForm = Form.create()(props => {
  const {
    modalServerVisible,
    form,
    handleServer,
    isAddCompany,
    handleServerModalVisible,
    ccInfo,
    info,
    onRef,
    handleDeleteCallcenterData,
    handleSaveNewCallCenter,
  } = props;
  const { getFieldDecorator } = form;
  const okHandle = () => {
    form.validateFields((err, values) => {
      if (err) return;
      form.resetFields();
      if (isAddCompany) {
        handleServer(values);
      } else {
        //将values中is_new为TRUE的数据过滤出来
        const params = values.cc.filter(item => {
          return item.isNew;
        });
        handleSaveNewCallCenter(params);
      }
    });
  };
  return (
    <Modal
      title="管理cc服务器信息"
      visible={modalServerVisible}
      onOk={okHandle}
      onCancel={() => handleServerModalVisible()}
      cancelText="返回"
      okText="保存"
      width={'400px'}
    >
      <Card>
        {getFieldDecorator('cc', {
          initialValue: ccInfo,
        })(
          <ServerForm
            onRef={onRef}
            handleDeleteCallcenterData={handleDeleteCallcenterData}
            info={info}
          />
        )}
      </Card>
    </Modal>
  );
});

//新增短信平台信息
const CreateNewMessageForm = Form.create()(props => {
  const { modalNewMessageVisible, form, handleNewMessage, handleNewMessageModalVisible } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleNewMessage(fieldsValue);
    });
  };
  return (
    <Modal
      title="管理短信平台"
      visible={modalNewMessageVisible}
      onOk={okHandle}
      onCancel={() => handleNewMessageModalVisible()}
      cancelText="返回"
      okText="保存"
      width={'400px'}
    >
      <MessageForm />
    </Modal>
  );
});

//新建按钮表单
const CreateForm = Form.create()(props => {
  const {
    modalVisible,
    form,
    handleAdd,
    handleClose,
    handleModalVisible,
    formAddValues,
    modalTitle,
    handleNewMessageModalVisible,
    handleNewvosModalVisible,
    handleNewUnifiedModalVisible,
    handleServerModalVisible,
    info,
    departmentOptions,
  } = props;

  const { getFieldDecorator } = form;
  //保存数据发送给后台
  const okHandle = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      if (err) return;
      handleAdd(fieldsValue, form);
    });
  };

  const cancel = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      form.resetFields(), handleClose(fieldsValue, form);
    });
  };

  let traderUser = info.traderUserSelect;
  const addVos = () => {
    handleNewvosModalVisible(true);
  };

  const addUnified = () => {
    handleNewUnifiedModalVisible(true);
  };

  const addServer = () => {
    handleServerModalVisible(true);
  };

  const addMessage = () => {
    handleNewMessageModalVisible(true);
  };

  return (
    <Modal
      title={modalTitle}
      visible={modalVisible}
      cancelText="返回"
      okText="保存"
      onOk={okHandle}
      onCancel={() => cancel()}
      width={'400px'}
    >
      <Row gutter={24}>
        <Col sm={12}>
          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="公司全称">
            {getFieldDecorator('company_name', {
              initialValue: formAddValues.company_name,
              validateFirst: true,
            })(<Input placeholder="公司全称" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="公司简称">
            {getFieldDecorator('company_abbreviation', {
              initialValue: formAddValues.company_abbreviation,
              validateFirst: true,
            })(<Input placeholder="公司简称" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="公司代码">
            {getFieldDecorator('company_code', {
              initialValue: formAddValues.company_code,
              validateFirst: true,
              rules: [{ pattern: /^\d{1,4}$/, message: '公司代码必须是1~4位的数字' }],
            })(<Input placeholder="公司代码" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="归属业务员">
            {getFieldDecorator('trader_user_id', {
              initialValue: formAddValues.trader_user_id,
              validateFirst: true,
            })(
              <Select size="default" style={{ width: '100%' }}>
                {traderUser
                  ? traderUser.map(item => {
                      return (
                        <Option value={item.user_id} key={item.user_id}>
                          {' '}
                          {item.user_name}{' '}
                        </Option>
                      );
                    })
                  : ''}
              </Select>
            )}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="归属技术组">
            {getFieldDecorator('department', {
              initialValue: formAddValues.department,
              validateFirst: true,
            })(
              <Cascader
                options={departmentOptions}
                // onChange={this.onChangeCascader}
                placeholder="请选择归属技术组"
                style={{ width: 300 }}
              />
            )}
          </FormItem>
          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="统一平台">
            {getFieldDecorator('unified', {
              initialValue: formAddValues.unified,
              validateFirst: true,
            })(
              <Button icon="plus" onClick={() => addUnified(true)}>
                管理统一平台数据
              </Button>
            )}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="VOS">
            {getFieldDecorator('vos', {
              initialValue: formAddValues.vos,
              validateFirst: true,
            })(
              <Button icon="plus" onClick={() => addVos(true)}>
                管理VOS数据
              </Button>
            )}
          </FormItem>
          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="备注">
            {getFieldDecorator('note', {
              initialValue: formAddValues.note,
              validateFirst: true,
            })(<TextArea rows={8} />)}
          </FormItem>
        </Col>
        <Col sm={12}>
          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="公司状态">
            {form.getFieldDecorator('company_status', {
              initialValue: formAddValues.company_status,
              validateFirst: true,
            })(
              <Select size="default" style={{ width: '100%' }}>
                {statusOptions}
              </Select>
            )}
          </FormItem>
          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="是否发送消息">
            {form.getFieldDecorator('message_switch', {
              initialValue: formAddValues.message_switch,
              validateFirst: true,
            })(
              <Select size="default" style={{ width: '100%' }}>
                {sendMsgStatusOptions}
              </Select>
            )}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="联系电话">
            {getFieldDecorator('contact_mobile', {
              initialValue: formAddValues.contact_mobile,
              validateFirst: true,
            })(<Input placeholder="联系电话" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="联系QQ">
            {getFieldDecorator('contact_qq', {
              initialValue: formAddValues.contact_qq,
              validateFirst: true,
            })(<Input placeholder="联系QQ" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="公司地址">
            {getFieldDecorator('company_address', {
              initialValue: formAddValues.company_address,
              validateFirst: true,
            })(<Input placeholder="公司地址" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="联系邮箱">
            {getFieldDecorator('contact_email', {
              initialValue: formAddValues.contact_email,
              validateFirst: true,
            })(<Input placeholder="联系邮箱" />)}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="呼叫中心数据">
            {getFieldDecorator('call_center_id', {
              initialValue: formAddValues.call_center_id,
              validateFirst: true,
            })(
              <Button icon="plus" onClick={() => addServer(true)}>
                管理呼叫中心服务器数据
              </Button>
            )}
          </FormItem>

          <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="短信平台">
            {getFieldDecorator('message', {
              initialValue: formAddValues.message,
              validateFirst: true,
            })(
              <Button icon="plus" onClick={() => addMessage(true)}>
                管理短信平台
              </Button>
            )}
          </FormItem>
        </Col>
      </Row>
    </Modal>
  );
});

@connect(({ manage, operation, structure, follow, loading }) => ({
  manage,
  follow,
  operation,
  structure,
  loading: loading.models.manage,
}))
@Form.create()
export default class ManageList extends PureComponent {
  state = {
    modalVisible: false,
    modalCcVisible: false,
    modalSeeVisible: false,
    modalUntieVisible: false,
    modalNewvosVisible: false,
    modalNewMessageVisible: false,
    modalServerVisible: false,
    modalNewUnifiedVisible: false,
    modalSendShortVisible: false,
    modalSendWechatVisible: false,
    modalUnifiedVisible: false,
    modalVosVisible: false,
    modalMessageVisible: false,
    modalShowNoteVisible: false,
    currentNote: '',

    modalTitle: '新建数据',
    expandForm: false,
    selectedRowKeys: [],
    selectedRows: [],
    rowSelection: {},
    searchText: '',
    filterDropdownVisible: false,
    activeIndex: '',
    copied: false,
    record: [],
    vosInfo: [],
    ccInfo: [],
    unifiedInfo: [],
    smsInfo: [],
    companyFollowInfo: [],
    companyServerInfo: [],
    EquipmentInfo: [],
    companyId: '',
    managerValues: '',
    accountValues: '',

    formAddValues: {
      company_id: '',
      company_name: '',
      company_abbreviation: '',
      company_code: '',
      contact_mobile: '',
      company_address: '',
      contact_qq: '',
      contact_email: '',
      note: '',
      message_switch: '关闭',
      trader_user_id: '',
      department: '',
      company_status: '正常',
      department: '',
      vos: [],
      cc: [],
      unified: {},
    },
    formQueryValues: {},
    operations: [],
    departmentOptions: [],
  };

  componentDidMount() {
    const { dispatch } = this.props;

    dispatch({
      type: 'manage/fetchManage',
      payload: {},
    });
    dispatch({
      type: 'manage/fetchInfo',
    });

    // 获取公司数据
    dispatch({
      type: 'follow/fetchCompany',
      payload: {},
    });

    dispatch({
      type: 'structure/fetchStructureInfo',
      payload: {},
      callback: (result, data) => {
        if (result == api_success) {
          this.setState({
            departmentOptions: data,
          });
        }
      },
    });
  }

  onRef = ref => {
    this.child = ref;
  };

  // 统一平台编辑状态中的增删改
  handleDeleteUnifiedPlatformData = fieldId => {
    const { dispatch } = this.props;

    dispatch({
      type: 'manage/removeUnifiedPlatform',
      payload: { unified_platform_id: fieldId },
    });
  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formQueryValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      page: pagination.current,
      perPageSize: pagination.pageSize,
      ...formQueryValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'manage/fetchManage',
      payload: params,
    });
  };

  //编辑统一平台中的新建
  handleSaveNewUnified = params => {
    if (params.length > 0) {
      const { companyId } = this.state;
      let unified = new Array();
      for (let i in params) {
        unified.push(params[i]);
      }
      const { dispatch } = this.props;
      dispatch({
        type: 'manage/addUnifiedPlatform',
        payload: {
          unified: unified,
          company_id: companyId,
        },
        callback: result => {
          if (result == 'success') {
            this.setState({
              modalNewUnifiedVisible: false,
            });
          }
        },
      });
    } else {
      this.setState({
        modalNewUnifiedVisible: false,
      });
    }
  };

  // vos编辑状态下的增删改
  handleDeleteVosData = fieldId => {
    const { dispatch } = this.props;

    dispatch({
      type: 'manage/removeVos',
      payload: { vos_id: fieldId },
    });
  };

  //编辑vos中的新建
  handleSaveNewVos = params => {
    if (params.length > 0) {
      const { companyId } = this.state;
      let vos = new Array();
      for (let i in params) {
        vos.push(params[i]);
      }
      const { dispatch } = this.props;
      dispatch({
        type: 'manage/addVos',
        payload: {
          vos: vos,
          company_id: companyId,
        },
        callback: result => {
          if (result == 'success') {
            this.setState({
              modalNewvosVisible: false,
            });
          }
        },
      });
    } else {
      this.setState({
        modalNewvosVisible: false,
      });
    }
  };

  // 呼叫中心编辑状态下的增删改
  handleDeleteCallcenterData = fieldId => {
    const { dispatch } = this.props;

    dispatch({
      type: 'manage/removeCallCenter',
      payload: { call_center_id: fieldId },
    });
  };

  //编辑呼叫中心平台中的新建
  handleSaveNewCallCenter = params => {
    if (params.length > 0) {
      const { companyId } = this.state;
      let cc = new Array();
      for (let i in params) {
        cc.push(params[i]);
      }
      const { dispatch } = this.props;
      dispatch({
        type: 'manage/addCallCenter',
        payload: {
          cc: cc,
          company_id: companyId,
        },
        callback: result => {
          if (result == 'success') {
            this.setState({
              modalServerVisible: false,
            });
          }
        },
      });
    } else {
      this.setState({
        modalServerVisible: false,
      });
    }
  };

  handleNewvosModalVisible = flag => {
    this.setState({
      modalNewvosVisible: !!flag,
    });
  };

  handleNewMessageModalVisible = flag => {
    this.setState({
      modalNewMessageVisible: !!flag,
    });
  };

  //解绑微信弹框
  // handleUntieModalVisible = (flag) => {
  //   this.setState({
  //     modaUntieVisible: !!flag,
  //   });
  // };

  handleServerModalVisible = flag => {
    this.setState({
      modalServerVisible: !!flag,
    });
  };

  handleNewUnifiedModalVisible = flag => {
    this.setState({
      modalNewUnifiedVisible: !!flag,
    });
  };

  handleVosModalVisible = flag => {
    this.setState({
      modalVosVisible: !!flag,
    });
  };

  handleMessageModalVisible = flag => {
    const data = this.props.manage.data.list;
    this.setState({
      modalMessageVisible: !!flag,
      data: data,
    });
  };

  handleSeeModalVisible = flag => {
    const { dispatch } = this.props;
    const { companyId } = this.state;
    dispatch({
      type: 'manage/seeCompanyInfo',
      payload: { company_id: companyId },
      callback: (result, seeData) => {
        if (result == 'success') {
          this.setState({
            modalSeeVisible: !!flag,
            companyFollowInfo: seeData.companyFollowInfo,
            EquipmentInfo: seeData.EquipmentInfo,
            companyServerInfo: seeData.companyServerInfo,
          });
        } else {
          this.setState({
            companyFollowInfo: [],
            EquipmentInfo: [],
            companyServerInfo: [],
          });
        }
      },
    });
  };

  handleChange = ({ target: { value } }, e) => {};

  handleClick = ({ target: { innerHTML } }) => {
    // console.log(`Clicked on "${innerHTML}"!`); // eslint-disable-line
  };

  onCopy = () => {
    this.setState({ copied: true });
    message.success('复制成功');
  };

  triggerChange = changedValue => {
    // Should provide an event to pass value to Form.
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(Object.assign({}, this.state, changedValue));
    }
  };

  handleCcModalVisible = flag => {
    this.setState({
      modalCcVisible: !!flag,
    });
  };

  handleUnifiedModalVisible = flag => {
    this.setState({
      modalUnifiedVisible: !!flag,
    });
  };

  handleSendShortModalVisible = flag => {
    this.setState({
      modalSendShortVisible: !!flag,
    });
  };

  // //发微信
  // handleSendWechatModalVisible = (flag) => {
  //   this.setState({
  //     modalSendWechatVisible: !!flag,
  //   });
  // };

  //解绑微信

  // handleUntieModalVisible = (flag) => {
  //   this.setState({
  //     modalUntieVisible: !!flag,
  //   });
  // };

  //删除数据
  handleDeleteData = text => {
    const { dispatch } = this.props;
    dispatch({
      company_id: text.company_id,
      filters: this.state.formQueryValues,
    });
  };

  setClassName = (record, index) => {
    //    //record代表表格行的内容，index代表行索引
    //    //判断索引相等时添加行的高亮样式
    return index === this.state.activeIndex ? styles.blue : '';
  };

  handleClickRow(record) {
    const { dispatch } = this.props;
    dispatch({
      type: 'manage/setSelectedCompanyInfo',
      payload: record,
    });
    this.setState({
      selectedRowKeys: [record.sort - 1],
      activeIndex: record.sort - 1,
      vosInfo: record.vos_has_many,
      ccInfo: record.call_center_has_many,
      unifiedInfo: record.unified_platform_has_many,
      companyId: record.company_id,
      // smsInfo:record.vos_has_many,
    });
  }

  //重置查询数据
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    this.setState({
      formQueryValues: {},
    });
    dispatch({
      type: 'manage/fetchManage',
      payload: {},
    });
  };

  //单个删除
  handleDeleteData = (e, text, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'manage/removeManage',
      payload: {
        company_id: text.company_id,
        filters: this.state.formQueryValues,
      },
      callback: () => {
        this.setState({
          selectedRows: [],
        });
      },
    });
  };

  //编辑
  handleEdit = (e, text, data) => {
    const formValuesArr = {
      company_id: text.company_id,
      company_name: text.company_name,
      company_abbreviation: text.company_abbreviation,
      company_code: text.company_code,
      contact_mobile: text.contact_mobile,
      company_address: text.company_address,
      contact_qq: text.contact_qq,
      contact_email: text.contact_email,
      note: text.note,
      message_switch: text.message_switch.toString(),
      trader_user_id: text.trader_user_id,
      department: text.department,
      company_status: text.company_status.toString(),
    };
    this.setState({
      modalTitle: '编辑数据',
      formAddValues: formValuesArr,
      modalVisible: true,
      isAddCompany: false,
    });
  };

  handleVos = () => {
    this.setState({
      modalVosVisible: false,
    });
  };

  handleMessage = () => {
    this.setState({
      modalMessageVisible: false,
    });
  };

  handleCc = () => {
    this.setState({
      modalCcVisible: false,
    });
  };

  //发送短信
  handleSendShort = () => {
    // this.props.dispatch({
    //   type: 'rule/eitd',
    //   payload: {
    //     description: fields.desc,
    //   },
    // });
    message.success('发送成功');
    this.setState({
      modalSendShortVisible: false,
    });
  };

  handleSendWechat = () => {
    message.success('发送成功');
    this.setState({
      modalSendWechatVisible: false,
    });
  };

  handleUntie = () => {
    message.success('解绑成功');
    this.setState({
      modalUntieVisible: false,
    });
  };

  handleRemind = () => {
    message.success('发送成功');
  };

  handleNewvos = values => {
    this.setState({
      modalNewvosVisible: false,
      vos: values,
    });
  };

  handleNewMessage = () => {
    this.setState({
      modalNewMessageVisible: false,
    });
  };

  handleServer = values => {
    this.setState({
      modalServerVisible: false,
      cc: values,
    });
  };

  handleUnified = () => {
    this.setState({
      modalUnifiedVisible: false,
    });
  };

  handleNewUnified = values => {
    this.setState({
      modalNewUnifiedVisible: false,
      unified: values,
    });
  };

  handleSee = () => {
    this.setState({
      modalVisible: false,
      companyFollowInfo: [],
      EquipmentInfo: [],
      companyServerInfo: [],
    });
  };

  handleShowNote = (text, data, event) => {
    console.log(text);
    this.setState({
      modalShowNoteVisible: true,
      currentNote: text,
    });
    // this.forceUpdate();
  };

  handleShowContentModalVisible = () => {
    this.setState({
      modalShowNoteVisible: false,
      currentNote: '',
    });
    // this.forceUpdate();
  };

  // 选择
  // handleSelectRows = rows => {
  //   this.setState({
  //     selectedRows: rows,
  //   });
  // };

  onSelectChange = (selectedRowKeys, record) => {
    this.setState({
      activeIndex: record.sort - 1,
      selectedRowKeys: selectedRowKeys,
    });
  };

  //查询
  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;

      const values = {
        ...fieldsValue,
        //updatedAt: fieldsValue.updatedAt && fieldsValue.updatedAt.valueOf(),
      };

      this.setState({
        formQueryValues: values,
      });

      dispatch({
        type: 'manage/fetchManage',
        payload: values,
      });
    });
  };

  //模态框新增数据
  handleModalVisible = flag => {
    const { form } = this.props;
    const company = {
      company_id: '',
      company_name: '',
      company_abbreviation: '',
      company_code: '',
      contact_mobile: '',
      company_address: '',
      contact_qq: '',
      contact_email: '',
      note: '',
      message_switch: send_msg_map.no.toString(),
      trader_user_id: '',
      department: '',
      company_status: companys_status_map.yes.toString(),
      department: '',
    };

    this.setState({
      modalTitle: '新增数据',
      modalVisible: !!flag,
      formAddValues: company,
      isAddCompany: true,

      selectedRowKeys: [],
      activeIndex: '',
      vosInfo: [],
      ccInfo: [],
      unifiedInfo: [],
      companyId: [],
      // smsInfo:[],
    });
  };
  handleClose = () => {
    this.setState({
      modalVisible: false,
    });
  };

  //新增数据
  handleAdd = (fields, form) => {
    const { unified, vos, cc } = this.state;
    const { dispatch } = this.props;
    let params = {
      company: {
        company_id: this.state.formAddValues.company_id,
        company_name: fields.company_name,
        company_abbreviation: fields.company_abbreviation,
        company_code: fields.company_code,
        contact_mobile: fields.contact_mobile,
        company_address: fields.company_address,
        contact_qq: fields.contact_qq,
        contact_email: fields.contact_email,
        note: fields.note,
        message_switch: fields.message_switch,
        trader_user_id: fields.trader_user_id,
        department: fields.department,
        company_status: fields.company_status,
        department: fields.department,
      },
      ...vos,
      ...cc,
      ...unified,
    };
    let url = 'manage/addManage';
    if (this.state.formAddValues.company_id) {
      url = 'manage/editManage';
      params = {
        company_id: this.state.formAddValues.company_id,
        company_name: fields.company_name,
        company_abbreviation: fields.company_abbreviation,
        company_code: fields.company_code,
        contact_mobile: fields.contact_mobile,
        company_address: fields.company_address,
        contact_qq: fields.contact_qq,
        contact_email: fields.contact_email,
        note: fields.note,
        message_switch: fields.message_switch,
        trader_user_id: fields.trader_user_id,
        department: fields.department,
        company_status: fields.company_status,
        department: fields.department,
      };
    }

    dispatch({
      type: url,
      payload: params,
      callback: result => {
        if (result == 'success') {
          form.resetFields();
          this.setState({
            modalVisible: false,
          });
        }
      },
    });
  };

  goPage = () => {
    this.props.history.push('./followup');
  };

  goPage2 = () => {
    this.props.history.push('../equipment/equipment-list');
  };

  //渲染高级查询
  renderSimpleForm() {
    const {
      form,
      manage: { info },
      follow: { companyInfo },
    } = this.props;
    const { getFieldDecorator } = form;
    let traderUser = info.traderUserSelect;
    let companyData = companyInfo;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="企业名称">
              {form.getFieldDecorator('query_company_id', {
                initialValue: this.state.formQueryValues.query_company_id,
                validateFields: true,
              })(
                <Select
                  showSearch
                  allowClear
                  style={{ width: 200 }}
                  placeholder="请输入"
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {companyData.map((item, index) => {
                    return (
                      <Option key={index} value={item.company_id}>
                        {item.company_name}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="公司状态">
              {getFieldDecorator('query_company_status', {
                initialValue: this.state.formQueryValues.query_company_status,
              })(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="">全部</Option>
                  {statusOptions}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="VOS账号">
              {getFieldDecorator('query_vos_account', {
                initialValue: this.state.formQueryValues.query_vos_account,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="起始分机">
              {getFieldDecorator('query_start_extension', {
                initialValue: this.state.formQueryValues.query_start_extension,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="归属业务员">
              {getFieldDecorator('query_trader_user_id', {
                initialValue: this.state.formQueryValues.query_trader_user_id,
                validateFirst: true,
              })(
                <Select showSearch allowClear size="default" style={{ width: '100%' }}>
                  {traderUser
                    ? traderUser.map(item => {
                        return (
                          <Option value={item.user_id} key={item.user_id}>
                            {' '}
                            {item.user_name}{' '}
                          </Option>
                        );
                      })
                    : ''}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 10 }} label="归属技术组">
              {getFieldDecorator('query_department', {
                initialValue: this.state.formQueryValues.query_department,
                validateFirst: true,
              })(
                <Cascader
                  changeOnSelect={true}
                  options={this.state.departmentOptions}
                  placeholder="请选择归属技术组"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="公司代码">
              {getFieldDecorator('query_company_code', {
                initialValue: this.state.formQueryValues.query_company_code,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={16} sm={24}>
            <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
              <Col md={8} sm={24}>
                <FormItem label="VOS余额">
                  {getFieldDecorator('query_balance_start', {
                    initialValue: this.state.formQueryValues.query_balance_start,
                  })(<InputNumber min={0} step={0.01} style={{ width: 120 }} />)}
                </FormItem>
              </Col>
              ~
              <Col md={8} sm={24}>
                <FormItem>
                  {getFieldDecorator('query_balance_end', {
                    initialValue: this.state.formQueryValues.query_balance_end,
                  })(<InputNumber min={0} step={0.01} style={{ width: 120 }} />)}
                </FormItem>
              </Col>
            </Row>
          </Col>
          <Col md={12} sm={24}>
            <FormItem label="创建时间">
              {getFieldDecorator('query_created_at', {
                initialValue: this.state.formQueryValues.query_created_at,
              })(
                <RangePicker
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['Start Time', 'End Time']}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="end">
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <span style={{ float: 'right', marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
              </span>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  //渲染查询表单
  renderForm() {
    return this.renderSimpleForm();
  }

  render() {
    const {
      manage: { data, info },
      loading,
      location,
    } = this.props;
    const {
      selectedRowKeys,
      modalVisible,
      selectedRows,
      formAddValues,
      modalTitle,
      modalSeeVisible,
      modalSendShortVisible,
      modalMessageVisible,
      modalVosVisible,
      modalCcVisible,
      modalUnifiedVisible,
      modalNewvosVisible,
      modalNewMessageVisible,
      modalNewUnifiedVisible,
      modalServerVisible,
      modalShowNoteVisible,
      currentNote,
      vosInfo,
      ccInfo,
      unifiedInfo,
      departmentOptions,
      companyFollowInfo,
      EquipmentInfo,
      companyServerInfo,
      isAddCompany,
      companyId,
      managerValues,
      accountValues,
    } = this.state;
    const pagination = data ? data.pagination : '';
    const paginationProps = {
      showSizeChanger: true,
      // showQuickJumper: true,
      showTotal: total => {
        return `共 ${total} 条`;
      },
      ...pagination,
    };

    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };

    const currentOperations = JSON.parse(getOperateInfo());

    const hasSelected = selectedRowKeys.length > 0;

    const columns = [
      {
        title: '序号',
        dataIndex: 'sort',
        key: 'sort',
      },

      {
        title: '公司全称',
        dataIndex: 'company_name',
        key: 'company_name',
        render: (text, record) => {
          if (record.company_status == 2) {
            return <span className={styles.red}>{text}</span>;
          }
          return text;
        },
      },
      // {
      //   title: '公司简称',
      //   dataIndex: 'company_abbreviation',
      //   key: 'company_abbreviation',
      // },

      {
        title: '公司代码',
        dataIndex: 'company_code',
        key: 'company_code',
      },

      // {
      //   title: '公司地址',
      //   dataIndex: 'company_address',
      //   key: 'company_address',
      // },
      // {
      //   title: '联系QQ',
      //   dataIndex: 'contact_qq',
      //   key: 'contact_qq',
      // },
      // {
      //   title: '联系微信',
      //   dataIndex: 'wechat',
      //   key: 'wechat6',
      // },
      // {
      //   title: '微信ID',
      //   dataIndex: 'wechat_user_id',
      //   key: 'wechat_user_id',

      // },

      // {
      //   title: '联系邮箱',
      //   dataIndex: 'contact_email',
      //   key: 'contact_email',
      // },
      // {
      //   title: '联系电话',
      //   dataIndex: 'contact_mobile',
      //   key: 'contact_mobile',
      // },
      {
        title: 'VOS服务器',
        dataIndex: 'vos_has_many',
        key: 'vos_server_name',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.server_name}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },
      {
        title: 'VOS账号',
        dataIndex: 'vos_has_many',
        key: 'vos_account',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.vos_account}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },
      {
        title: '账户余额',
        dataIndex: 'vos_has_many',
        key: 'balance',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.balance}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },
      {
        title: 'cc服务器',
        dataIndex: 'call_center_has_many',
        key: 'cc_server_name',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.server_name}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },
      {
        title: 'cc类起始分机',
        dataIndex: 'call_center_has_many',
        key: 'start_extension',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.start_extension}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },
      {
        title: 'cc坐席数量',
        dataIndex: 'call_center_has_many',
        key: 'seats_number',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.seats_number}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },
      {
        title: '统一平台坐席起始用户名',
        dataIndex: 'unified_platform_has_many',
        key: 'seats_start_name',
        render: value => (
          <span>
            {value.map((item, index) => {
              return (
                <table key={index}>
                  <tbody key={item.index}>
                    <tr key={item.index}>
                      <td>{item.seats_start_name}</td>
                    </tr>
                  </tbody>
                </table>
              );
            })}
          </span>
        ),
      },

      {
        title: '创建时间',
        dataIndex: 'created_at',
        key: 'created_at',
      },
      {
        title: '更新时间',
        dataIndex: 'updated_at',
        key: 'updated_at',
      },
      {
        title: '备注信息',
        dataIndex: 'note',
        key: 'note6',
        render: (text, record) => (
          <Fragment>
            {
              <p
                href="javascript:;"
                className={styles.note}
                onClick={this.handleShowNote.bind(this, text, record)}
              >
                {text}
              </p>
            }
          </Fragment>
        ),
      },
      // {
      //   title: '公司状态',
      //   dataIndex: 'company_status',
      //   key: 'company_status',
      //   filters: [
      //     {
      //       text: companys_status_option[0]['name'],
      //       value: companys_status_option[0]['key'],
      //     },
      //     {
      //       text: companys_status_option[1]['name'],
      //       value: companys_status_option[1]['key'],
      //     },
      //   ],
      //   onFilter: (value, record) => record.company_status.toString() === value,

      //   render(val) {
      //     return <Badge status={badge_status_map[val]} text={companys_status[val]} />;
      //   },
      // },

      // {
      //   title: '是否发送消息',
      //   dataIndex: 'message_switch',
      //   key: 'message_switch',
      //   filters: [
      //     {
      //       text: send_msg_status_option[0]['name'],
      //       value: send_msg_status_option[0]['key'],
      //     },
      //     {
      //       text: send_msg_status_option[1]['name'],
      //       value: send_msg_status_option[1]['key'],
      //     },
      //   ],
      //   onFilter: (value, record) => record.message_switch.toString() === value,
      //   render(val) {
      //     return <Badge status={badge_status_map[val]} text={send_msg_status[val]} />;
      //   },
      // },
      {
        title: '归属业务员',
        dataIndex: 'user_name',
        key: 'trader_user_id6',
      },
      {
        title: '归属技术组',
        dataIndex: 'department_name',
        key: 'department_name',
      },
      {
        title: '操作',
        dataIndex: 'operation',
        fixed: 'right',
        key: 'operation6',
        render: (text, record, index) => (
          <Fragment>
            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].EDITCOMPANY ? (
              <div>
                <a href="javascript:;" onClick={this.handleEdit.bind(this, text, record)}>
                  编辑
                </a>
                <Divider type="vertical" />
              </div>
            ) : (
              ''
            )}

            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].DELETECOMPANY ? (
              <Popconfirm
                placement="topRight"
                title="确定删除吗？"
                onConfirm={this.handleDeleteData.bind(this, text, record)}
                okText="Yes"
                cancelText="No"
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
            ) : (
              ''
            )}
          </Fragment>
        ),
      },
    ];

    const parentMethods = {
      handleAdd: this.handleAdd,
      handleClose: this.handleClose,
      handleModalVisible: this.handleModalVisible,
      handleNewvosModalVisible: this.handleNewvosModalVisible,
      handleNewMessageModalVisible: this.handleNewMessageModalVisible,
      handleServerModalVisible: this.handleServerModalVisible,
      handleNewUnifiedModalVisible: this.handleNewUnifiedModalVisible,
    };

    const parentVosMethods = {
      handleVos: this.handleVos,
      handleVosModalVisible: this.handleVosModalVisible,
    };
    const parentMessageMethods = {
      handleMessage: this.handleMessage,
      handleMessageModalVisible: this.handleMessageModalVisible,
    };

    const parentNewvosMethods = {
      handleNewvos: this.handleNewvos,
      handleSaveNewVos: this.handleSaveNewVos,
      handleNewvosModalVisible: this.handleNewvosModalVisible,
      onRef: this.onRef,
      handleDeleteVosData: this.handleDeleteVosData,
    };

    const parentNewMessageMethods = {
      handleNewMessage: this.handleNewMessage,
      handleNewMessageModalVisible: this.handleNewMessageModalVisible,
    };

    const parentServerMethods = {
      handleServer: this.handleServer,
      handleSaveNewCallCenter: this.handleSaveNewCallCenter,
      handleServerModalVisible: this.handleServerModalVisible,
      onRef: this.onRef,
      handleDeleteCallcenterData: this.handleDeleteCallcenterData,
    };

    const parentUnifiedMethods = {
      handleUnified: this.handleUnified,
      handleUnifiedModalVisible: this.handleUnifiedModalVisible,
    };

    const parentCcMethods = {
      handleCc: this.handleCc,
      handleCcModalVisible: this.handleCcModalVisible,
    };

    const parentNewUnifiedMethods = {
      handleNewUnified: this.handleNewUnified,
      handleSaveNewUnified: this.handleSaveNewUnified,
      handleNewUnifiedModalVisible: this.handleNewUnifiedModalVisible,
      onRef: this.onRef,
      handleDeleteUnifiedPlatformData: this.handleDeleteUnifiedPlatformData,
    };
    const parentSeeMethods = {
      handleSee: this.handleSee,
      handleChange: this.handleChange,
      handleClick: this.handleClick,
      onCopy: this.onCopy,
      handleSeeModalVisible: this.handleSeeModalVisible,
      goPage: this.goPage,
      goPage2: this.goPage2,
    };

    // const parentUntieMethods = {
    //   handleUntie: this.handleUntie,
    //   handleUntieModalVisible: this.handleUntieModalVisible,
    // };

    const parentSendShortMethods = {
      handleSendShort: this.handleSendShort,
      handleSendShortModalVisible: this.handleSendShortModalVisible,
    };

    // const parentSendWechatMethods = {
    //   handleSendWechat: this.handleSendWechat,
    //   handleSendWechatModalVisible: this.handleSendWechatModalVisible,
    // };

    const parentShowNoteMethods = {
      handleShowContentModalVisible: this.handleShowContentModalVisible,
    };

    return (
      <PageHeaderLayout>
        <div className={styles.content}>
          <Card bordered={false}>
            <div className={styles.tableList}>
              <div className={styles.tableListForm}>{this.renderForm()}</div>

              <div className={styles.tableListOperator}>
                {currentOperations &&
                currentOperations[location.pathname] &&
                currentOperations[location.pathname].ADDCOMPANY ? (
                  <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                    新建数据
                  </Button>
                ) : (
                  ''
                )}

                <Button type="primary" onClick={() => this.goPage()} disabled={!hasSelected}>
                  跟进记录
                </Button>

                <Button
                  icon="exclamation-circle"
                  type="primary"
                  onClick={() => this.handleRemind(true)}
                  disabled={!hasSelected}
                >
                  余额提醒
                </Button>

                <Button type="primary" onClick={() => this.goPage2()} disabled={!hasSelected}>
                  设备管理
                </Button>

                {currentOperations &&
                currentOperations[location.pathname] &&
                currentOperations[location.pathname].SEECOMPANYINFO ? (
                  <Button
                    icon="eye"
                    type="primary"
                    onClick={() => this.handleSeeModalVisible(true)}
                    disabled={!hasSelected}
                  >
                    查看
                  </Button>
                ) : (
                  ''
                )}

                {/* <Button icon="export" type="primary" onClick={() => this.handleSendWechatModalVisible(true)} disabled={!hasSelected}>
                发微信
              </Button> */}
                <Button
                  icon="export"
                  type="primary"
                  onClick={() => this.handleSendShortModalVisible(true)}
                  disabled={!hasSelected}
                >
                  发短信
                </Button>
                {/* <Button  type="primary" disabled={!hasSelected}>
                跳转CC
              </Button> */}
                {/* <Button  type="primary" onClick={() => this.handleUntieModalVisible(true)}disabled={!hasSelected}>
                解绑微信
              </Button> */}
                <Button
                  type="primary"
                  onClick={() => this.handleVosModalVisible(true)}
                  disabled={!hasSelected}
                >
                  vos
                </Button>
                <Button
                  type="primary"
                  onClick={() => this.handleCcModalVisible(true)}
                  disabled={!hasSelected}
                >
                  呼叫中心
                </Button>
                <Button
                  type="primary"
                  onClick={() => this.handleUnifiedModalVisible(true)}
                  disabled={!hasSelected}
                >
                  统一平台
                </Button>
                {/* <Button  type="primary" onClick={() => this.handleMessageModalVisible(true)} disabled={!hasSelected}>
                短信平台
              </Button>           */}
              </div>
              <Table
                rowKey={'company_id'}
                selectedRows={selectedRows}
                loading={loading}
                scroll={{ x: 2000 }}
                pagination={paginationProps}
                rowSelection={rowSelection}
                dataSource={data.list}
                columns={columns}
                onSelectRow={this.handleSelectRows}
                onChange={this.handleStandardTableChange}
                rowClassName={this.setClassName}
                onRow={record => {
                  //表格行点击事件
                  return {
                    onClick: this.handleClickRow.bind(this, record),
                  };
                }}
                bordered
              />
            </div>
          </Card>
        </div>

        <CreateVosForm {...parentVosMethods} modalVosVisible={modalVosVisible} vosInfo={vosInfo} />
        <CreateCcForm {...parentCcMethods} modalCcVisible={modalCcVisible} ccInfo={ccInfo} />
        <CreateSendShortForm
          {...parentSendShortMethods}
          modalSendShortVisible={modalSendShortVisible}
        />
        {/* <CreateSendWechatForm {...parentSendWechatMethods} modalSendWechatVisible={modalSendWechatVisible} /> */}
        <CreateSeeForm
          {...parentSeeMethods}
          modalSeeVisible={modalSeeVisible}
          companyFollowInfo={companyFollowInfo}
          EquipmentInfo={EquipmentInfo}
          companyServerInfo={companyServerInfo}
          managerValues={managerValues}
          accountValues={accountValues}
        />
        {/* <CreateMessageForm {...parentMessageMethods} modalMessageVisible={modalMessageVisible} record={record}/> */}
        <CreateNewvosForm
          {...parentNewvosMethods}
          modalNewvosVisible={modalNewvosVisible}
          vosInfo={vosInfo}
          info={info}
          isAddCompany={isAddCompany}
        />
        <CreateNewMessageForm
          {...parentNewMessageMethods}
          modalNewMessageVisible={modalNewMessageVisible}
        />
        {/* <CreateUntieForm {...parentUntieMethods} modalUntieVisible={modalUntieVisible} /> */}
        <CreateServerForm
          {...parentServerMethods}
          modalServerVisible={modalServerVisible}
          ccInfo={ccInfo}
          info={info}
          isAddCompany={isAddCompany}
        />
        <CreateNewUnifiedForm
          {...parentNewUnifiedMethods}
          modalNewUnifiedVisible={modalNewUnifiedVisible}
          unifiedInfo={unifiedInfo}
          info={info}
          isAddCompany={isAddCompany}
          companyId={companyId}
        />
        <CreateUnifiedForm
          {...parentUnifiedMethods}
          modalUnifiedVisible={modalUnifiedVisible}
          unifiedInfo={unifiedInfo}
        />
        <CreateForm
          {...parentMethods}
          modalVisible={modalVisible}
          formAddValues={formAddValues}
          modalTitle={modalTitle}
          info={info}
          departmentOptions={departmentOptions}
        />
        <CreateShowNoteForm
          {...parentShowNoteMethods}
          modalShowNoteVisible={modalShowNoteVisible}
          currentNote={currentNote}
        />
      </PageHeaderLayout>
    );
  }
}
