import React, { PureComponent, Fragment } from 'react';
import { Table, Button, Input, Select, message, Popconfirm, Divider } from 'antd';
import styles from './Index.less';
import { regex } from '../../../utils/regex';
import { connect } from 'dva';

const { Option } = Select;
@connect(({ manage, operation, structure, loading }) => ({
  manage,
  operation,
  structure,
  loading: loading.models.manage,
}))
export default class ServerForm extends PureComponent {
  index = 0;

  cacheOriginData = {};

  constructor(props) {
    super(props);
    this.state = {
      data: props.value,
      loading: false,
      call_center_server_info: props.info,
      selectValue: '',
    };
  }

  componentDidMount() {
    this.props.onRef(this);
  }

  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      this.setState({
        data: nextProps.value,
      });
    }
  }

  //获取当前行数据
  getRowByKey(call_center_id, newData) {
    const { data } = this.state;
    return (newData || data).filter(item => item.call_center_id === call_center_id)[0];
  }

  //编辑
  toggleEditable = (e, call_center_id) => {
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(call_center_id, newData);
    if (target) {
      // 进入编辑状态时保存原始数据
      if (!target.editable) {
        this.cacheOriginData[call_center_id] = { ...target };
      }
      target.editable = !target.editable;
      this.setState({ data: newData });
    }
  };

  //添加行
  newMember = () => {
    const { data, selectValue } = this.state;
    const newData = data.map(item => ({ ...item }));
    newData.push({
      call_center_id: `New_CC_ID_${this.index}`,
      call_center_server_id: selectValue,
      server_name: selectValue,
      start_extension: '',
      end_extension: '',
      extension_password: '',
      manager_name: '',
      manager_password: '',
      operator_name: '',
      operator_password: '',
      seats_name: '',
      seats_password: '',
      editable: true,
      isNew: true,
    });
    this.index += 1;
    this.setState({ data: newData });
  };

  //删除行
  remove(call_center_id) {
    const { data } = this.state;
    const currentData = data.filter(item => item.call_center_id == call_center_id);

    if (regex.is_integer.test(call_center_id)) {
      const { handleDeleteCallcenterData } = this.props;
      handleDeleteCallcenterData(currentData[0].call_center_id);
      const { onChange } = this.props;
      const newData = data.filter(item => item.call_center_id !== call_center_id);
      this.setState({ data: newData });
      onChange(newData);
    } else {
      const { onChange } = this.props;
      const newData = data.filter(item => item.call_center_id !== call_center_id);
      this.setState({ data: newData });
      onChange(newData);
    }

    // const { data } = this.state;
    // // const { onChange } = this.props;
    // const newData = data.filter(item => item.call_center_id !== call_center_id);
    // this.setState({ data: newData });
    // // onChange(newData);
  }

  //回车操作
  handleKeyPress(e, call_center_id) {
    if (e.key === 'Enter') {
      this.saveRow(e, call_center_id);
    }
  }

  onSelect = value => {
    this.setState({
      selectValue: value,
    });
  };

  //选择域改变
  handleFieldSelect(value, fieldName, call_center_id) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(call_center_id, newData);
    if (target) {
      target[fieldName] = value.toString();
      this.setState({ data: newData });
    }
  }

  //输入域改变
  handleFieldChange(e, fieldName, call_center_id) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(call_center_id, newData);
    if (target) {
      if (fieldName == 'call_center_server_id') {
        target[fieldName] = e;
      } else {
        target[fieldName] = e.target.value;
      }

      this.setState({ data: newData });
    }
  }

  //保存行信息
  saveRow(e, call_center_id) {
    e.persist();
    this.setState({
      loading: true,
    });
    setTimeout(() => {
      if (this.clickedCancel) {
        this.clickedCancel = false;
        return;
      }
      const target = this.getRowByKey(call_center_id) || {};

      if (!target.call_center_server_id || !target.start_extension) {
        message.error('请填写完整信息。');
        e.target.focus();
        this.setState({
          loading: false,
        });
        return;
      }
      const cc = {
        call_center_id: target.call_center_id,
        call_center_server_id: target.call_center_server_id,
        enterprise_account: target.enterprise_account,
        start_extension: target.start_extension,
        end_extension: target.end_extension,
        extension_password: target.extension_password,
        seats_number: target.seats_number,
        manager_name: target.manager_name,
        manager_password: target.manager_password,
        operator_name: target.operator_name,
        operator_password: target.operator_password,
        seats_name: target.seats_name,
        seats_password: target.seats_password,
      };

      if (!target.isNew) {
        const { dispatch } = this.props;

        dispatch({
          type: 'manage/editCallCenter',
          payload: cc,
        });
      }
      const { data } = this.state;
      const { onChange } = this.props;
      // delete target.isNew;
      delete target.editable;
      this.toggleEditable(e, call_center_id);
      onChange(data);
      this.setState({
        loading: false,
      });
    }, 500);
  }

  //取消编辑
  cancel(e, call_center_id) {
    this.clickedCancel = true;
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(call_center_id, newData);
    if (this.cacheOriginData[call_center_id]) {
      Object.assign(target, this.cacheOriginData[call_center_id]);
      target.editable = false;
      delete this.cacheOriginData[call_center_id];
    }
    this.setState({ data: newData });
    this.clickedCancel = false;
  }

  handleTableChange = (pagination, filters, sorter) => {
    const { onChange } = this.props;
    onChange(pagination, filters, sorter);
  };

  cancelFormEdit = () => {
    const { data } = this.state;
    const currentData = data.map(item => {
      item.editable = false;
      item.isNew = false;
      return item;
    });
    this.setState({ data: currentData });
  };

  render() {
    const { loading, pagination, data, call_center_server_info, selectValue } = this.state;
    const { rowKey } = this.props;

    const callCenterInfo = call_center_server_info.callSelect;

    const columns = [
      {
        title: 'CC服务器名称',
        dataIndex: 'call_center_server_id',
        key: 'call_center_server_id',
        width: 160,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Select
                size="default"
                style={{ width: '160px' }}
                value={selectValue}
                onSelect={this.onSelect}
                autoFocus
                onChange={e =>
                  this.handleFieldSelect(e, 'call_center_server_id', record.call_center_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="cc服务器名称"
              >
                {callCenterInfo
                  ? callCenterInfo.map((item, index) => {
                      return (
                        <Option key={index} value={item.call_center_server_id.toString()}>
                          {item.server_name}
                        </Option>
                      );
                    })
                  : ''}
              </Select>
            );
          }
          return record.server_name;
        },
      },

      {
        title: 'CC起始分机',
        dataIndex: 'start_extension',
        key: 'start_extension',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'start_extension', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC起始分机"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC账户信息',
        dataIndex: 'enterprise_account',
        key: 'enterprise_account',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'enterprise_account', record.call_center_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC账户信息"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC结束分机',
        dataIndex: 'end_extension',
        key: 'end_extension',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'end_extension', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC结束分机"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC分机密码',
        dataIndex: 'extension_password',
        key: 'extension_password',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'extension_password', record.call_center_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC分机密码"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC坐席数量',
        dataIndex: 'seats_number',
        key: 'seats_number',
        width: 120,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'seats_number', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC坐席数量"
                style={{ width: '120px' }}
              />
            );
          }

          return text;
        },
      },

      {
        title: 'CC管理员用户名',
        dataIndex: 'manager_name',
        key: 'manager_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'manager_name', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC管理员用户名"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },

      {
        title: 'CC管理员密码',
        dataIndex: 'manager_password',
        key: 'manager_password',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'manager_password', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC管理员密码"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC操作员用户名',
        dataIndex: 'operator_name',
        key: 'operator_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'operator_name', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC操作员用户名"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC操作员密码',
        dataIndex: 'operator_password',
        key: 'operator_password',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'operator_password', record.call_center_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC操作员密码"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC坐席用户名',
        dataIndex: 'seats_name',
        key: 'seats_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'seats_name', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="CC坐席用户名"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: 'CC坐席密码',
        dataIndex: 'seats_password',
        key: 'seats_password',
        width: 200,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'seats_password', record.call_center_id)}
                onKeyPress={e => this.handleKeyPress(e, record.call_center_id)}
                placeholder="cc坐席密码"
                style={{ width: '180px' }}
              />
            );
          }
          return text;
        },
      },
      {
        title: '操作',
        key: 'action',
        fixed: 'right',
        width: 120,
        render: (text, record) => {
          const { loading } = this.state;
          if (!!record.editable && loading) {
            return null;
          }
          if (record.editable) {
            if (record.isNew) {
              return (
                <span>
                  <a onClick={e => this.saveRow(e, record.call_center_id)}>添加</a>
                  <Divider type="vertical" />
                  <Popconfirm
                    title="是否要删除此行？"
                    onConfirm={() => this.remove(record.call_center_id)}
                  >
                    <a>删除</a>
                  </Popconfirm>
                </span>
              );
            }
            return (
              <span>
                <a onClick={e => this.saveRow(e, record.call_center_id)}>保存</a>
                <Divider type="vertical" />
                <a onClick={e => this.cancel(e, record.call_center_id)}>取消</a>
              </span>
            );
          }
          return (
            <span>
              <a onClick={e => this.toggleEditable(e, record.call_center_id)}>编辑</a>
              <Divider type="vertical" />
              <Popconfirm
                title="是否要删除此行？"
                onConfirm={() => this.remove(record.call_center_id)}
              >
                <a>删除</a>
              </Popconfirm>
            </span>
          );
        },
      },
    ];

    return (
      <Fragment>
        <Table
          rowKey={'call_center_id'}
          loading={loading}
          columns={columns}
          dataSource={data}
          // pagination={paginationProps}
          onChange={this.handleTableChange}
          rowClassName={record => {
            return record.editable ? styles.editable : '';
          }}
          bordered
          scroll={{ x: 2500 }}
        />
        <Button
          style={{ width: '100%', marginTop: 16, marginBottom: 8 }}
          type="dashed"
          onClick={this.newMember}
          icon="plus"
        >
          新增服务器信息
        </Button>
      </Fragment>
    );
  }
}
