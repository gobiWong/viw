import React, { PureComponent, Fragment } from 'react';
import {
  Table,
  Button,
  Input,
  Select,
  message,
  Popconfirm,
  Divider,
  Badge,
} from 'antd';
import { connect } from 'dva';
import styles from './Index.less';
import { regex } from '../../../utils/regex';
import {
  remind_type,
  remind_type_option,
  balance_remind,
  balance_remind_option,
  badge_status_map,
} from '../../../utils/status';

const { Option } = Select;

const remindOptions = remind_type_option.map(item => {
  return (
    <Option key={item.key} value={item.key}>
      {item.name}
    </Option>
  );
});

const isOptions = balance_remind_option.map(item => {
  return (
    <Option key={item.key} value={item.key}>
      {item.name}
    </Option>
  );
});
@connect(({ manage, operation, structure, loading }) => ({
  manage,
  operation,
  structure,
  loading: loading.models.manage,
}))
export default class TableForm extends PureComponent {
  index = 0;

  cacheOriginData = {};

  constructor(props) {
    super(props);
    this.state = {
      data: props.value,
      loading: false,
      vos_server_info: props.info,
      selectValue: '',
      balanceQuerySelectValue: '',
      balanceRemindSelectValue: '',
    };
  }

  componentDidMount() {
    // this.props.onRef(this)
  }

  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      this.setState({
        data: nextProps.value,
      });
    }
  }

  //获取当前行数据
  getRowByKey(vos_id, newData) {
    const { data } = this.state;
    return (newData || data).filter(item => item.vos_id === vos_id)[0];
  }

  //编辑
  toggleEditable = (e, vos_id) => {
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(vos_id, newData);
    if (target) {
      // 进入编辑状态时保存原始数据
      if (!target.editable) {
        this.cacheOriginData[vos_id] = { ...target };
      }
      target.editable = !target.editable;
      this.setState({ data: newData });
    }
  };

  //添加行
  newMember = () => {
    const { data, selectValue, balanceQuerySelectValue, balanceRemindSelectValue } = this.state;
    const newData = data.map(item => ({ ...item }));
    newData.push({
      vos_id: `New_vos_${this.index}`,
      vos_server_id: selectValue,
      vos_account: '',
      balance: '',
      server_name: '',
      vos_telephone_password: '',
      vos_web_password: '',
      balance_query: balanceQuerySelectValue,
      balance_remind: balanceRemindSelectValue,
      balance_warning: '',
      balance_notice_times: '',
      balance_notice_way: null,
      editable: true,
      isNew: true,
    });
    this.index += 1;
    this.setState({ data: newData });
  };

  //删除行
  remove(vos_id) {
    const { data } = this.state;
    const currentData = data.filter(item => item.vos_id == vos_id);
    if (regex.is_integer.test(vos_id)) {
      const { handleDeleteVosData } = this.props;
      handleDeleteVosData(currentData[0].vos_id);
      const { onChange } = this.props;
      const newData = data.filter(item => item.vos_id !== vos_id);
      this.setState({ data: newData });
      onChange(newData);
    } else {
      const { onChange } = this.props;
      const newData = data.filter(item => item.vos_id !== vos_id);
      this.setState({ data: newData });
      onChange(newData);
    }
  }

  //回车操作
  handleKeyPress(e, vos_id) {
    if (e.key === 'Enter') {
      this.saveRow(e, vos_id);
    }
  }

  onSelect = value => {
    this.setState({
      selectValue: value,
    });
  };

  balanceQuery = value => {
    this.setState({
      balanceQuerySelectValue: value,
    });
  };

  balanceRemind = value => {
    this.setState({
      balanceRemindSelectValue: value,
    });
  };

  //输入域改变
  handleFieldChange(e, fieldName, vos_id) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(vos_id, newData);
    if (target) {
      if (
        fieldName == 'vos_server_id' ||
        fieldName == 'balance_query' ||
        fieldName == 'balance_remind' ||
        fieldName == 'balance_notice_way'
      ) {
        target[fieldName] = e;
        // console.log( target[fieldName]);
      } else {
        target[fieldName] = e.target.value;
      }

      this.setState({ data: newData });
    }
  }

  //选择域改变
  handleFieldSelect(value, fieldName, vos_id) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(vos_id, newData);
    if (target) {
      target[fieldName] = value.toString();
      this.setState({ data: newData });
    }
  }

  //保存行信息
  saveRow(e, vos_id) {
    e.persist();
    this.setState({
      loading: true,
    });
    setTimeout(() => {
      if (this.clickedCancel) {
        this.clickedCancel = false;
        return;
      }
      const target = this.getRowByKey(vos_id) || {};

      if (!target.vos_server_id || !target.vos_account) {
        message.error('请填写完整信息。');
        e.target.focus();
        this.setState({
          loading: false,
        });
        return;
      }

      const vos = {
        vos_id: target.vos_id,
        vos_server_id: target.vos_server_id,
        vos_account: target.vos_account,
        vos_telephone_password: target.vos_telephone_password,
        vos_web_password: target.vos_web_password,
        balance: target.balance,
        balance_query: target.balance_query,
        balance_remind: target.balance_remind,
        balance_warning: target.balance_warning,
        balance_notice_times: target.balance_notice_times,
        vos_web_password: target.vos_web_password,
        balance_notice_way: target.balance_notice_way
      };

      if (!target.isNew) {
        const { dispatch } = this.props;

        dispatch({
          type: 'manage/editVos',
          payload: vos,
        });
      }
      const { data } = this.state;
      const { onChange } = this.props;
      // delete target.isNew;
      delete target.editable;
      this.toggleEditable(e, vos_id);
      onChange(data);
      this.setState({
        loading: false,
      });
    }, 500);
  }

  //取消编辑
  cancel(e, vos_id) {
    this.clickedCancel = true;
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(vos_id, newData);
    if (this.cacheOriginData[vos_id]) {
      Object.assign(target, this.cacheOriginData[vos_id]);
      target.editable = false;
      delete this.cacheOriginData[vos_id];
    }
    this.setState({ data: newData });
    this.clickedCancel = false;
  }

  handleTableChange = (pagination, filters, sorter) => {
    const { onChange } = this.props;
    onChange(pagination, filters, sorter);
  };

  cancelFormEdit = () => {
    const { data } = this.state;
    const currentData = data.map(item => {
      item.editable = false;
      item.isNew = false;
      return item;
    });
    this.setState({ data: currentData });
  };

  render() {
    const {
      loading,
      data,
      vos_server_info,
      selectValue,
      balanceQuerySelectValue,
      balanceRemindSelectValue,
    } = this.state;
    const { rowKey } = this.props;
    const vosServerNameInfo = vos_server_info.vosSelect;
    const columns = [
      {
        title: 'vos服务器',
        dataIndex: 'vos_server_id',
        key: 'vos_server_id',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Select
                size="default"
                style={{ width: '100%' }}
                defaultValue={selectValue}
                onSelect={this.onSelect}
                onChange={e => this.handleFieldSelect(e, 'vos_server_id', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="vos服务器"
              >
                {vosServerNameInfo
                  ? vosServerNameInfo.map((item, index) => {
                      return (
                        <Option key={index} value={item.vos_server_id}>
                          {item.server_name}
                        </Option>
                      );
                    })
                  : ''}
              </Select>
            );
          }
          return record.server_name;
        },
      },
      {
        title: 'vos账号',
        dataIndex: 'vos_account',
        key: 'vos_account',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'vos_account', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="vos账号"
              />
            );
          }
          return text;
        },
      },
      {
        title: '账户余额',
        dataIndex: 'balance',
        key: 'balance',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'balance', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="账户余额"
              />
            );
          }
          return text;
        },
      },
      {
        title: 'vos话机密码',
        dataIndex: 'vos_telephone_password',
        key: 'vos_telephone_password',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'vos_telephone_password', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="vos话机密码"
              />
            );
          }
          return text;
        },
      },

      {
        title: 'vos网页密码',
        dataIndex: 'vos_web_password',
        key: 'vos_web_password',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'vos_web_password', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="vos网页密码"
              />
            );
          }
          return text;
        },
      },

      {
        title: '查询余额',
        dataIndex: 'balance_query',
        key: 'balance_query',
        width: 150,
        render: (text, record, val) => {
          if (record.editable) {
            return (
              <Select
                size="default"
                style={{width: '100%'}}
                value={balanceQuerySelectValue}
                onSelect={this.balanceQuery}
                onChange={e => this.handleFieldSelect(e, 'balance_query', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="查询余额"
              >
                {isOptions}
              </Select>
            );
          }
          return <Badge status={badge_status_map[text]} text={balance_remind[text]} />;
        },
      },
      {
        title: '余额提醒',
        dataIndex: 'balance_remind',
        key: 'balance_remind',
        width: 150,
        render: (text, record, val) => {
          if (record.editable) {
            return (
              <Select
                size="default"
                style={{width: '100%'}}
                value={balanceRemindSelectValue}
                onSelect={this.balanceRemind}
                onChange={e => this.handleFieldSelect(e, 'balance_remind', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="余额提醒"
              >
                {isOptions}
              </Select>
            );
          }
          return <Badge status={badge_status_map[text]} text={balance_remind[text]} />;
        },
      },
      {
        title: '余额告警阈值',
        dataIndex: 'balance_warning',
        key: 'balance_warning',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'balance_warning', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="余额告警阈值"
              />
            );
          }
          return text;
        },
      },
      {
        title: '余额提醒次数',
        dataIndex: 'balance_notice_times',
        key: 'balance_notice_times',
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e => this.handleFieldChange(e, 'balance_notice_times', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="余额提醒次数"
              />
            );
          }
          return text;
        },
      },
      {
        title: '提醒方式',
        dataIndex: 'balance_notice_way',
        key: 'balance_notice_way',
        width: 200,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Select
                size="default"
                style={{width: '100%'}}
                value={remind_type[text]}
                onChange={e => this.handleFieldChange(e, 'balance_notice_way', record.vos_id)}
                onKeyPress={e => this.handleKeyPress(e, record.vos_id)}
                placeholder="提醒方式"
              >
                {remindOptions}
              </Select>
            );
          }
          return <Badge status={badge_status_map[text]} text={remind_type[text]} />;
        },
      },
      {
        title: '操作',
        key: 'action',
        fixed: 'right',
        width: 120,
        render: (text, record) => {
          const { loading } = this.state;
          if (!!record.editable && loading) {
            return null;
          }
          if (record.editable) {
            if (record.isNew) {
              return (
                <span>
                  <a onClick={e => this.saveRow(e, record.vos_id)}>添加</a>
                  <Divider type="vertical" />
                  <Popconfirm title="是否要删除此行？" onConfirm={() => this.remove(record.vos_id)}>
                    <a>删除</a>
                  </Popconfirm>
                </span>
              );
            }
            return (
              <span>
                <a onClick={e => this.saveRow(e, record.vos_id)}>保存</a>
                <Divider type="vertical" />
                <a onClick={e => this.cancel(e, record.vos_id)}>取消</a>
              </span>
            );
          }
          return (
            <span>
              <a onClick={e => this.toggleEditable(e, record.vos_id)}>编辑</a>
              <Divider type="vertical" />
              <Popconfirm title="是否要删除此行？" onConfirm={() => this.remove(record.vos_id)}>
                <a>删除</a>
              </Popconfirm>
            </span>
          );
        },
      },
    ];

    return (
      <Fragment>
        <Table
          rowKey={'vos_id'}
          loading={loading}
          columns={columns}
          dataSource={data}
          onChange={this.handleTableChange}
          rowClassName={record => {
            return record.editable ? styles.editable : '';
          }}
          bordered
          scroll={{ x: 1600 }}
        />
        <Button
          style={{ width: '100%', marginTop: 16, marginBottom: 8 }}
          type="dashed"
          onClick={this.newMember}
          icon="plus"
        >
          新增vos信息
        </Button>
      </Fragment>
    );
  }
}
