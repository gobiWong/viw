import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { Table, Button, Input, Select, message, Popconfirm, Divider } from 'antd';
import styles from './Index.less';
import { regex } from '../../../utils/regex';

const { Option } = Select;

@connect(({ manage, operation, structure, loading }) => ({
  manage,
  operation,
  structure,
  loading: loading.models.manage,
}))
export default class UnifiedForm extends PureComponent {
  index = 0;

  cacheOriginData = {};

  constructor(props) {
    super(props);
    this.state = {
      data: props.value,
      loading: false,
      unifiedEnterPrise: props.info,
      selectValue: '',
      // unified: {},
    };
  }

  componentDidMount() {
    this.props.onRef(this);
  }

  // 统一平台编辑状态中的增删改
  handleDeleteUnifiedPlatformData = fieldId => {
    const { dispatch } = this.props;

    dispatch({
      type: 'manage/removeUnifiedPlatform',
      payload: { unified_platform_id: fieldId },
    });
  };

  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      this.setState({
        data: nextProps.value,
      });
    }
  }

  //获取当前行数据
  getRowByKey(unified_platform_id, newData) {
    const { data } = this.state;
    return (newData || data).filter(item => item.unified_platform_id === unified_platform_id)[0];
  }

  //编辑
  toggleEditable = (e, unified_platform_id) => {
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(unified_platform_id, newData);

    if (target) {
      // 进入编辑状态时保存原始数据
      if (!target.editable) {
        this.cacheOriginData[unified_platform_id] = { ...target };
      }
      this.setState({ data: newData });
      target.editable = !target.editable;
    }
  };

  //添加行
  newMember = () => {
    const { data, selectValue, company_id } = this.state;
    const newData = data.map(item => ({ ...item }));
    newData.push({
      unified_platform_id: `NEW_TEMP_ID_${this.index}`,
      unified_platform_server_id: selectValue,
      manager_name: '',
      server_name: '',
      // company_id: company_id,
      manager_password: '',
      operator_name: '',
      operator_password: '',
      seats_start_name: '',
      seats_end_name: '',
      seats_password: '',
      editable: true,
      isNew: true,
    });
    this.index += 1;
    this.setState({ data: newData });
  };

  //删除行
  remove(unified_platform_id) {
    const { data } = this.state;
    const currentData = data.filter(item => item.unified_platform_id == unified_platform_id);
    if (regex.is_integer.test(unified_platform_id)) {
      const { handleDeleteUnifiedPlatformData } = this.props;
      handleDeleteUnifiedPlatformData(currentData[0].unified_platform_id);
      const { onChange } = this.props;
      const newData = data.filter(item => item.unified_platform_id !== unified_platform_id);
      this.setState({ data: newData });
      onChange(newData);
    } else {
      const { onChange } = this.props;
      const newData = data.filter(item => item.unified_platform_id !== unified_platform_id);
      this.setState({ data: newData });
      onChange(newData);
    }
  }

  //回车操作
  handleKeyPress(e, unified_platform_id) {
    if (e.key === 'Enter') {
      this.saveRow(e, unified_platform_id);
    }
  }

  onSelect = value => {
    this.setState({
      selectValue: value,
    });
  };

  // 输入域改变
  handleFieldChange(e, fieldName, unified_platform_id) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(unified_platform_id, newData);
    if (target) {
      if (fieldName == 'unified_platform_server_id') {
        target[fieldName] = e;
      } else {
        target[fieldName] = e.target.value;
      }
      this.setState({
        data: newData,
      });
    }
  }

  // 选择域改变
  handleFieldSelect(value, fieldName, unified_platform_id) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(unified_platform_id, newData);
    if (target) {
      target[fieldName] = value.toString();
      this.setState({ data: newData });
    }
  }

  //保存行信息
  saveRow(e, unified_platform_id) {
    e.persist();
    this.setState({
      loading: true,
      // unified,
    });
    setTimeout(() => {
      if (this.clickedCancel) {
        this.clickedCancel = false;
        return;
      }
      const target = this.getRowByKey(unified_platform_id) || {};
      const { data } = this.state;
      const { onChange } = this.props;
      //delete target.isNew;
      delete target.editable;
      this.toggleEditable(e, unified_platform_id);
      onChange(data);
      this.setState({
        loading: false,
      });
      if (!target.unified_platform_server_id || !target.manager_name) {
        message.error('请填写完整信息。');
        e.target.focus();
        this.setState({
          loading: false,
        });
        return;
      }

      const unified = {
        unified_platform_id: target.unified_platform_id,
        unified_platform_server_id: target.unified_platform_server_id,
        manager_name: target.manager_name,
        manager_password: target.manager_password,
        operator_name: target.operator_name,
        operator_password: target.operator_password,
        seats_start_name: target.seats_start_name,
        seats_end_name: target.seats_end_name,
        seats_password: target.seats_password,
      };
      if (!target.isNew) {
        const { dispatch } = this.props;

        dispatch({
          type: 'manage/editUnifiedPlatform',
          payload: unified,
        });
      }
    }, 500);
  }

  //取消编辑
  cancel(e, unified_platform_id) {
    this.clickedCancel = true;
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(unified_platform_id, newData);
    if (this.cacheOriginData[unified_platform_id]) {
      Object.assign(target, this.cacheOriginData[unified_platform_id]);
      target.editable = false;
      delete this.cacheOriginData[unified_platform_id];
    }
    this.setState({ data: newData });
    this.clickedCancel = false;
  }

  handleTableChange = (pagination, filters, sorter) => {
    const { onChange } = this.props;
    onChange(pagination, filters, sorter);
  };

  cancelFormEdit = () => {
    const { data } = this.state;
    const currentData = data.map(item => {
      item.editable = false;
      item.isNew = false;
      return item;
    });
    this.setState({ data: currentData });
  };

  render() {
    const { loading, data, unifiedEnterPrise, selectValue } = this.state;
    const { rowKey } = this.props;

    const unifiedEnterPriseInfo = unifiedEnterPrise.unifiedSelect;

    const columns = [
      {
        title: '统一平台服务器名称',
        dataIndex: 'unified_platform_server_id',
        key: 'unified_platform_server_id',
        width: 160,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Select
                size="default"
                style={{ width: 160 }}
                value={selectValue}
                onSelect={this.onSelect}
                autoFocus
                onChange={e =>
                  this.handleFieldSelect(
                    e,
                    'unified_platform_server_id',
                    record.unified_platform_id
                  )
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="服务器名称"
              >
                {unifiedEnterPriseInfo
                  ? unifiedEnterPriseInfo.map((item, index) => {
                      return (
                        <Option key={index} value={item.unified_platform_server_id}>
                          {item.server_name}
                        </Option>
                      );
                    })
                  : ''}
              </Select>
            );
          }
          return record.server_name;
        },
      },
      {
        title: '统一平台管理员用户名',
        dataIndex: 'manager_name',
        key: 'manager_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'manager_name', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="管理员用户名"
              />
            );
          }
          return text;
        },
      },
      {
        title: '统一平台管理员密码',
        dataIndex: 'manager_password',
        key: 'manager_password',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'manager_password', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="管理员密码"
              />
            );
          }
          return text;
        },
      },
      {
        title: '统一平台操作员用户名',
        dataIndex: 'operator_name',
        key: 'operator_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'operator_name', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="操作员用户名"
              />
            );
          }
          return text;
        },
      },

      {
        title: '统一平台操作员密码',
        dataIndex: 'operator_password',
        key: 'operator_password',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'operator_password', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="操作员密码"
              />
            );
          }
          return text;
        },
      },

      {
        title: '统一平台坐席起始用户名',
        dataIndex: 'seats_start_name',
        key: 'seats_start_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'seats_start_name', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="统一平台坐席起始用户名"
              />
            );
          }
          return text;
        },
      },

      {
        title: '统一平台坐席结束用户名',
        dataIndex: 'seats_end_name',
        key: 'seats_end_name',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'seats_end_name', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="坐席结束用户名"
              />
            );
          }
          return text;
        },
      },
      {
        title: '统一平台坐席密码',
        dataIndex: 'seats_password',
        key: 'seats_password',
        width: 180,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                onChange={e =>
                  this.handleFieldChange(e, 'seats_password', record.unified_platform_id)
                }
                onKeyPress={e => this.handleKeyPress(e, record.unified_platform_id)}
                placeholder="坐席密码"
              />
            );
          }
          return text;
        },
      },
      {
        title: '操作',
        key: 'action',
        fixed: 'right',
        width: 100,
        render: (text, record) => {
          const { loading } = this.state;
          if (!!record.editable && loading) {
            return null;
          }
          if (record.editable) {
            if (record.isNew) {
              return (
                <span>
                  <a onClick={e => this.saveRow(e, record.unified_platform_id)}>添加</a>
                  <Divider type="vertical" />
                  <Popconfirm
                    title="是否要删除此行？"
                    onConfirm={() => this.remove(record.unified_platform_id)}
                  >
                    <a>删除</a>
                  </Popconfirm>
                </span>
              );
            }
            return (
              <span>
                <a onClick={e => this.saveRow(e, record.unified_platform_id)}>保存</a>
                <Divider type="vertical" />
                <a onClick={e => this.cancel(e, record.unified_platform_id)}>取消</a>
              </span>
            );
          }
          return (
            <span>
              <a onClick={e => this.toggleEditable(e, record.unified_platform_id)}>编辑</a>
              <Divider type="vertical" />
              <Popconfirm
                title="是否要删除此行？"
                onConfirm={() => this.remove(record.unified_platform_id)}
              >
                <a>删除</a>
              </Popconfirm>
            </span>
          );
        },
      },
    ];

    return (
      <Fragment>
        <Table
          rowKey={'unified_platform_id'}
          loading={loading}
          columns={columns}
          dataSource={data}
          // pagination={paginationProps}
          onChange={this.handleTableChange}
          rowClassName={record => {
            return record.editable ? styles.editable : '';
          }}
          bordered
          size="small"
          scroll={{ x: 1600 }}
        />
        <Button
          style={{ width: '100%', marginTop: 16, marginBottom: 8 }}
          type="dashed"
          onClick={this.newMember}
          icon="plus"
        >
          新增平台信息
        </Button>
      </Fragment>
    );
  }
}
