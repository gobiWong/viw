import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Button,
  Tooltip,
  Badge,
  DatePicker,
  Popconfirm,
  Modal,
  Divider,
} from 'antd';
import StandardTable from '../../../components/EquipmentFollowTable';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import { record_type, record_type_option, record_type_map } from '../../../utils/status';
import { getOperateInfo } from '../../../utils/localstorage';
import styles from './Index.less';

const { RangePicker } = DatePicker;
const { TextArea } = Input;
const FormItem = Form.Item;
const { Option } = Select;

// 新增设备跟进模态框
const CreateForm = Form.create()(props => {
  const {
    modalVisible,
    form,
    handleAdd,
    handleClose,
    handleModalVisible,
    formAddValues,
    modalTitle,
    equipmentInfo,
  } = props;
  const equipmentInfoOption = equipmentInfo.map((item, index) => {
    return (
      <Option key={index} value={item.equipment_id}>
        {item.serial_number}
      </Option>
    );
  });
  const okHandle = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      if (err) return;
      handleAdd(fieldsValue, form);
    });
  };
  const cancel = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      form.resetFields();
      handleClose(fieldsValue, form);
    });
  };
  return (
    <Modal
      title={modalTitle}
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => cancel()}
    >
      <Form>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="跟进设备">
          {form.getFieldDecorator('equipment_id', {
            initialValue: formAddValues.equipment_id,
            validateFirst: true,
            rules: [{ required: true, message: '请选择设备' }],
          })(
            <Select style={{ width: '100%' }} placeholder="请选择">
              {equipmentInfoOption}
            </Select>
          )}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="原始内容">
          {form.getFieldDecorator('origin_content', {
            initialValue: formAddValues.origin_content,
            validateFirst: true,
            rules: [{ required: true, message: '请请填写原始内容' }],
          })(<TextArea rows={4} />)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="当前内容">
          {form.getFieldDecorator('current_content', {
            initialValue: formAddValues.current_content,
            validateFirst: true,
            rules: [{ required: true, message: '请请填写当前内容' }],
          })(<TextArea rows={4} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

@connect(({ equipmentFollow,equipmentList, loading }) => ({
  equipmentFollow,
  equipmentList,
  loading: loading.models.equipmentFollow,
}))
@Form.create()
export default class FollowList extends PureComponent {
  state = {
    modalVisible: false,
    modalTitle: '新增跟进记录',
    expandForm: false,
    selectedRows: [],
    formAddValues: {
      equipment_follow_id: '',
      user_id: '',
      equipment_id: '',
      current_content: '',
      origin_content: '',
      //record_from: '',
    },
    formQueryValues: {},
  };

  componentDidMount() {
    const { dispatch,
          equipmentList:{selectedEquipmentInfo},
     } = this.props;
    dispatch({
      type: 'equipmentFollow/fetchEquipmentFollow',
      payload: {
        query_equipment_id: selectedEquipmentInfo.equipment_id,
      },
    });
    dispatch({
      type: 'equipmentFollow/fetchEquipmentByCondition',
      payload: {},
    });
    dispatch({
      type: "equipmentList/setSelectedEquipmentInfo",
      payload: {},
      callback: (result) => {}
    });
  }
  handleClose = () => {
    this.setState({
      modalVisible:false,
    })
  }

  // 重置查询数据
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    this.setState({
      formQueryValues: {},
    });
    dispatch({
      type: 'equipmentFollow/fetchEquipmentFollow',
      payload: {},
    });
  };

  //单个删除
  handleDeleteData = (e, text, data) => {
    const { dispatch } = this.props;

    dispatch({
      type: 'equipmentFollow/removeequipmentFollow',
      payload: {
        equipment_follow_id: text.equipment_operate_follow_record_id,
        filters: this.state.formQueryValues,
      },
      callback: () => {
        this.setState({
          selectedRows: [],
        });
      },
    });
  };

  // 编辑
  handleEdit = (e, text, data) => {
    const formValuesArr = {
      equipment_follow_id: text.equipment_operate_follow_record_id,
      user_id: text.user_id,
      record_from: text.record_from,
      equipment_id: text.equipment_id,
      origin_content: text.origin_content,
      current_content: text.current_content,
    };
    this.setState({
      modalTitle: '编辑跟进记录',
      formAddValues: formValuesArr,
      modalVisible: true,
    });
  };

  // 选择
  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  // 查询
  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      this.setState({
        formQueryValues: values,
      });
      dispatch({
        type: 'equipmentFollow/fetchEquipmentFollow',
        payload: values,
      });
    });
  };

  // 模态框新增数据
  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
    const formValuesArr = {
      equipment_follow_id: '',
      origin_content: '',
      current_content: '',
      record_from: '',
    };
    this.setState({
      modalTitle: '新增跟进记录',
      formAddValues: formValuesArr,
    });
  };

    // 列表数据改变时
    handleStandardTableChange = (pagination, filtersArg, sorter) => {
      const { dispatch } = this.props;
      const { formQueryValues } = this.state;
  
      const filters = Object.keys(filtersArg).reduce((obj, key) => {
        const newObj = { ...obj };
        newObj[key] = getValue(filtersArg[key]);
        return newObj;
      }, {});
  
      const params = {
        page: pagination.current,
        perPageSize: pagination.pageSize,
        ...formQueryValues,
        ...filters,
      };
      if (sorter.field) {
        params.sorter = `${sorter.field}_${sorter.order}`;
      }
  
      dispatch({
        type: 'equipmentFollow/fetchEquipmentFollow',
        payload: params,
      });
    };

  // 新增数据
  handleAdd = (fields, form) => {
    const { dispatch } = this.props;
    let params = {
      equipment_follow_id: this.state.formAddValues.equipment_follow_id,
      origin_content: fields.origin_content,
      current_content: fields.current_content,
      equipment_id: fields.equipment_id,
      filters: this.state.formQueryValues,
    };
    let url = 'equipmentFollow/addequipmentFollow';
    if (this.state.formAddValues.equipment_follow_id) {
      url = 'equipmentFollow/editquipmentFollow';
    }
    dispatch({
      type: url,
      payload: params,
      callback: result => {
        if (result == 'success') {
          form.resetFields();
          this.setState({
            modalVisible: false,
          });
        }
      },
    });
  };

  //渲染高级查询
  renderSimpleForm() {
    const { form, equipmentFollow } = this.props;
    const selectData = equipmentFollow.EquipmentConditionData;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem label="设备号">
              {form.getFieldDecorator('query_equipment_id', {})(
                <Select 
                style={{ width: 200 }} 
                showSearch
                placeholder="请输入"
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
                >
                  {selectData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_id}>
                        {item.serial_number}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="添加人">
              {form.getFieldDecorator('query_user_name', {
                initialValue: this.state.formQueryValues.query_user_name,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="记录类别">
              {getFieldDecorator('query_record_from', {
                initialValue: this.state.formQueryValues.record_from,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={12} sm={24}>
            <FormItem label="添加时间">
              {getFieldDecorator('query_created_at', {
                initialValue: this.state.formQueryValues.created_at,
              })(
                <RangePicker
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['Start Time', 'End Time']}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="end">
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <span style={{ float: 'right', marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
              </span>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  //渲染查询表单
  renderForm() {
    return this.renderSimpleForm();
  }
  render() {
    const {
      equipmentFollow: { data, EquipmentConditionData },
      loading,
      location,
    } = this.props;
    const { selectedRows, modalVisible, formAddValues, modalTitle } = this.state;
    const currentOperations = JSON.parse(getOperateInfo());
    const columns = [
      {
        title: '序号',
        dataIndex: 'sort',
        key: 'sort',
      },
      {
        title: '添加人',
        dataIndex: 'user_name',
        key: 'user_name',
      },
      {
        title: '设备号',
        dataIndex: 'serial_number',
        key: 'equipment_id',
      },
      {
        title: '记录类别',
        dataIndex: 'record_from',
        key: 'record_from',
        filters: [
          {
            text: record_type_option[0]['name'],
            value: record_type_option[0]['key'],
          },
          {
            text: record_type_option[1]['name'],
            value: record_type_option[1]['key'],
          },
        ],
        onFilter: (value, record) => record.record_from.toString() === value,
        render(val) {
          return <Badge status={record_type_map[val]} text={record_type[val]} />;
        },
      },
      {
        title: '原始内容',
        dataIndex: 'origin_content',
        key: 'origin_content',
        render(text, record) {
          if (record.record_from == 1 && text != '') {
            let originValue = [];
            for (var key in text) {
              originValue.push(text[key]);
            }
            return (
              <Tooltip
                placement="top"
                title={originValue.map(item => {
                  return <li key={item}> {item} </li>;
                })}
              >
                <li className={styles.note}>
                  {originValue.map(item => {
                    return <span key={item}> {item + '/'} </span>;
                  })}
                </li>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip placement="top" title={text}>
                <span className={styles.note}> {text} </span>
              </Tooltip>
            );
          }
        },
      },
      {
        title: '当前内容',
        dataIndex: 'current_content',
        key: 'current_content',
        render(text, record) {
          if (record.record_from == 1 && text != '') {
            let currentValue = [];
            for (var key in text) {
              currentValue.push(text[key]);
            }
            return (
              <Tooltip
                placement="top"
                title={currentValue.map(item => {
                  return <li key={item}> {item} </li>;
                })}
              >
                <li className={styles.note}>
                  {currentValue.map(item => {
                    return <span key={item}> {item + '/'} </span>;
                  })}
                </li>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip placement="top" title={text}>
                <span className={styles.note}> {text} </span>
              </Tooltip>
            );
          }
        },
      },
      {
        title: '添加时间',
        dataIndex: 'created_at',
        key: 'created_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '更新时间',
        dataIndex: 'updated_at',
        key: 'updated_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 110,
        fixed: 'right',
        render: (text, record, index) =>
          record.record_from != 1 ? (
            <Fragment>
              {currentOperations &&
              currentOperations[location.pathname] &&
              currentOperations[location.pathname].ADDEQUIPMENTFOLLOW ? (
                <div>
                  <a href="javascript:;" onClick={this.handleEdit.bind(this, text, record)}>
                    编辑
                  </a>
                  <Divider type="vertical" />
                </div>
              ) : (
                ''
              )}

              {currentOperations &&
              currentOperations[location.pathname] &&
              currentOperations[location.pathname].ADDEQUIPMENTFOLLOW ? (
                <Popconfirm
                  placement="topRight"
                  title="确定删除吗？"
                  onConfirm={this.handleDeleteData.bind(this, text, record)}
                  okText="Yes"
                  cancelText="No"
                >
                  <a href="javascript:;">删除</a>
                </Popconfirm>
              ) : (
                ''
              )}
            </Fragment>
          ) : (
            ''
          ),
      },
    ];

    const parentMethods = {
      handleAdd: this.handleAdd,
      handleClose:this.handleClose,
      handleModalVisible: this.handleModalVisible,
    };
    return (
      <PageHeaderLayout>
        <div className={styles.content}>
          <Card bordered={false}>
            <div className={styles.tableList}>
              <div className={styles.tableListForm}>{this.renderForm()}</div>
              <div className={styles.tableListOperator}>
                {currentOperations &&
                currentOperations[location.pathname] &&
                currentOperations[location.pathname].ADDEQUIPMENTFOLLOW ? (
                  <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                    新建数据
                  </Button>
                ) : (
                  ''
                )}
              </div>
              <StandardTable
                selectedRows={selectedRows}
                loading={loading}
                data={data}
                columns={columns}
                onSelectRow={this.handleSelectRows}
                onChange={this.handleStandardTableChange}
              />
            </div>
          </Card>
        </div>
        <CreateForm
          {...parentMethods}
          modalVisible={modalVisible}
          formAddValues={formAddValues}
          modalTitle={modalTitle}
          equipmentInfo={EquipmentConditionData}
        />
      </PageHeaderLayout>
    );
  }
}
