import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import moment from 'moment';
import {
  Row,
  Col,
  Card,
  Icon,
  Table,
  Form,
  Input,
  Select,
  Button,
  DatePicker,
  Popconfirm,
  Modal,
  Tooltip,
  Divider,
} from 'antd';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import ExceptionNoAuth from 'components/ExceptionNoAuth';
import StandardTable from '../../../components/EquipmentListTable';
import { getOperateInfo } from '../../../utils/localstorage';
import styles from './Index.less';

const { RangePicker } = DatePicker;
const { TextArea } = Input;
const FormItem = Form.Item;
const { Option } = Select;

// 新增设备模态框
const CreateForm = Form.create()(props => {
  const {
    modalVisible,
    form,
    handleAdd,
    handleClose,
    handleModalVisible,
    formAddValues,
    modalTitle,
    locationData,
    userData,
    attributionData,
    typeData,
    companyData,
  } = props;

  const okHandle = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      if (err) return;
      handleAdd(fieldsValue, form);
    });
  };

  const cancel = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      form.resetFields();
      handleClose(fieldsValue, form);
    });
  };

  return (
    <Modal title={modalTitle} visible={modalVisible} onOk={okHandle} onCancel={() => cancel()}>
      <Row gutter={24}>
        <Col sm={12}>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="MAC地址">
            {form.getFieldDecorator('mac_address', {
              initialValue: formAddValues.mac_address,
              validateFields: true,
              rules: [{ required: true, message: '请填写MAC地址' }],
            })(<Input placeholder="请输入" />)}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="序列号">
            {form.getFieldDecorator('serial_number', {
              initialValue: formAddValues.serial_number,
              validateFields: true,
              rules: [{ required: true, message: '请填写序列号' }],
            })(<Input placeholder="请输入" />)}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="设备类型">
            {form.getFieldDecorator('equipment_type_id', {
              initialValue: formAddValues.equipment_type_id,
              validateFields: true,
              rules: [{ required: true, message: '请选择设备类型' }],
            })(
              <Select style={{ width: '100%' }} placeholder="请选择">
                {typeData.map((item, index) => {
                  return (
                    <Option key={index} value={item.equipment_type_id}>
                      {item.equipment_name}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="设备编码">
            {form.getFieldDecorator('equipment_code', {
              initialValue: formAddValues.equipment_code,
              validateFields: true,
              rules: [{ required: true, message: '请填写设备编码' }],
            })(<Input placeholder="请输入" />)}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="设备位置">
            {form.getFieldDecorator('equipment_location_id', {
              initialValue: formAddValues.equipment_location_id,
              validateFields: true,
              rules: [{ required: true, message: '请填写设备位置' }],
            })(
              <Select style={{ width: '100%' }} placeholder="请选择">
                {locationData.map((item, index) => {
                  return (
                    <Option key={index} value={item.equipment_location_id}>
                      {item.equipment_location}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="所属公司">
            {form.getFieldDecorator('company_id', {
              initialValue: formAddValues.company_id,
              validateFields: true,
              rules: [{ required: true, message: '请选择所属公司' }],
            })(
              <Select
                showSearch
                style={{ width: '100%' }}
                placeholder="请输入"
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
              >
                {companyData.map((item, index) => {
                  return (
                    <Option key={index} value={item.company_id}>
                      {item.company_name}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="设备归属">
            {form.getFieldDecorator('equipment_attribution_id', {
              initialValue: formAddValues.equipment_attribution_id,
              validateFields: true,
              rules: [{ required: true, message: '请选择设备归属' }],
            })(
              <Select style={{ width: '100%' }} placeholder="请选择">
                {attributionData.map((item, index) => {
                  return (
                    <Option key={index} value={item.equipment_attribution_id}>
                      {item.equipment_attribution}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
        </Col>
        <Col sm={12}>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="设备用途">
            {form.getFieldDecorator('equipment_use_id', {
              initialValue: formAddValues.equipment_use_id,
              validateFields: true,
              rules: [{ required: true, message: '请选择设备用途' }],
            })(
              <Select style={{ width: '100%' }} placeholder="请选择">
                {userData.map((item, index) => {
                  return (
                    <Option key={index} value={item.equipment_use_id}>
                      {item.equipment_use}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="公网IP">
            {form.getFieldDecorator('public_network_ip', {
              initialValue: formAddValues.public_network_ip,
              validateFields: true,
              // rules: [{required: true, message: "请填写公网IP"}]
            })(<Input placeholder="请输入" />)}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="IP地址">
            {form.getFieldDecorator('public_network_ip_area', {
              initialValue: formAddValues.public_network_ip_area,
              validateFields: true,
              // rules: [{required: true, message: "请填写IP地址"}]
            })(<Input placeholder="请输入" />)}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="内网IP">
            {form.getFieldDecorator('intranet_ip', {
              initialValue: formAddValues.intranet_ip,
              validateFields: true,
              // rules: [{required: true, message: "请填写内网IP"}]
            })(<Input placeholder="请输入" />)}
          </FormItem>
          <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="备注">
            {form.getFieldDecorator('note', {
              initialValue: formAddValues.note,
              validateFields: true,
            })(<TextArea rows={4} />)}
          </FormItem>
        </Col>
      </Row>
    </Modal>
  );
});

const CreateShowNoteForm = Form.create()(props => {
  const { modalShowNoteVisible, currentNote, handleShowContentModalVisible } = props;
  return (
    <Modal
      title="备注信息"
      visible={modalShowNoteVisible}
      onCancel={() => handleShowContentModalVisible()}
      centered={true}
      footer={null}
      width={200}
    >
      <textarea
        value={currentNote}
        readOnly
        style={{ border: 'none', width: '100%', minHeight: 200, overflow: 'hidden' }}
      />
    </Modal>
  );
});

@connect(
  ({
    equipmentList,
    follow,
    equipmentOwen,
    equipmentPosition,
    equipmentType,
    equipmentUse,
    manage,
    loading,
    equipmentFollow,
  }) => ({
    equipmentList,
    follow,
    equipmentOwen,
    equipmentPosition,
    equipmentType,
    equipmentUse,
    equipmentFollow,
    manage,
    loading: loading.models.equipmentList,
  })
)
@Form.create()
export default class EquipmentList extends PureComponent {
  state = {
    modalVisible: false,
    modalTitle: '新增设备',
    expandForm: false,
    selectedRows: [],
    selectedRowKeys: [],
    modalShowNoteVisible: false,
    currentNote: '',
    formAddValues: {
      equipment_id: '',
      mac_address: '',
      serial_number: '',
      equipment_type_id: '',
      equipment_code: '',
      equipment_location_id: '',
      company_id: '',
      equipment_attribution_id: '',
      equipment_use_id: '',
      public_network_ip: '',
      public_network_ip_area: '',
      intranet_ip: '',
      note: '',
      created_at: '',
      updated_at: '',
    },
    formQueryValues: {},
  };

  componentDidMount() {
    const {
      dispatch,
      manage: { selectedCompanyInfo },
      equipmentList: { selectedEquipmentInfo },
    } = this.props;

    //获取设备跟进信息

    dispatch({
      type: 'equipmentFollow/fetchEquipmentByCondition',
      payload: {},
    });

    // 获取设备位置数据
    dispatch({
      type: 'equipmentPosition/fetchEqLocationByCondition',
      payload: {},
    });
    // 获取设备归属数据
    dispatch({
      type: 'equipmentOwen/fetchOwenByCondition',
      payload: {},
    });
    //灬获取设备用途数据
    dispatch({
      type: 'equipmentUse/fetchEqUseByCondition',
      payload: {},
    });
    // 获取设备类型数据
    dispatch({
      type: 'equipmentType/fetchEqTypeByCondition',
      payload: {},
    });
    // 获取公司数据
    dispatch({
      type: 'follow/fetchCompany',
      payload: {},
    });

    // 获取列表数据
    dispatch({
      type: 'equipmentList/fetchEquipment',
      payload: {
        query_company_id: selectedCompanyInfo.company_id,
      },
    });
  }

  // 重置查询数据
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    this.setState({
      formQueryValues: {},
    });
    dispatch({
      type: 'equipmentList/fetchEquipment',
      payload: {},
    });
  };

  // 单个删除
  handleDeleteData = (e, text, data) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'equipmentList/removeEquipment',
      payload: {
        equipment_id: text.equipment_id,
        filters: this.state.formQueryValues,
      },
      callback: () => {
        this.setState({
          selectedRows: [],
        });
      },
    });
  };

  handleClickRow(record) {
    const { dispatch } = this.props;
    dispatch({
      type: 'equipmentList/setSelectedEquipmentInfo',
      payload: record,
    });
    this.setState({
      selectedRowKeys: [record.sort - 1],
      activeIndex: record.sort - 1,
      // companyId: record.company_id,
      // smsInfo:record.vos_has_many,
    });
  }
  onSelectChange = (selectedRowKeys, record) => {
    this.setState({
      activeIndex: record.sort - 1,
      selectedRowKeys: selectedRowKeys,
    });
  };
  setClassName = (record, index) => {
    //    //record代表表格行的内容，index代表行索引
    //    //判断索引相等时添加行的高亮样式
    return index === this.state.activeIndex ? styles.blue : '';
  };

  // 编辑
  handleEdit = (e, text, data) => {
    const formValuesArr = {
      equipment_id: text.equipment_id,
      mac_address: text.mac_address,
      serial_number: text.serial_number,
      equipment_type_id: text.equipment_type_id,
      equipment_code: text.equipment_code,
      equipment_location_id: text.equipment_location_id,
      company_id: text.company_id,
      equipment_attribution_id: text.equipment_attribution_id,
      equipment_use_id: text.equipment_use_id,
      public_network_ip: text.public_network_ip,
      public_network_ip_area: text.public_network_ip_area,
      intranet_ip: text.intranet_ip,
      note: text.note,
    };
    this.setState({
      modalTitle: '编辑设备信息',
      formAddValues: formValuesArr,
      modalVisible: true,
    });
  };

  // 选择
  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  //切换查询
  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  // 查询
  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      this.setState({
        formQueryValues: values,
      });
      dispatch({
        type: 'equipmentList/fetchEquipment',
        payload: values,
      });
    });
  };

  // 模态框新增数据
  handleModalVisible = flag => {
    const { form } = this.props;

    const formValuesArr = {
      equipment_id: '',
      mac_address: '',
      serial_number: '',
      equipment_type_id: '',
      equipment_code: '',
      equipment_location_id: '',
      company_id: '',
      equipment_attribution_id: '',
      equipment_use_id: '',
      public_network_ip: '',
      public_network_ip_area: '',
      intranet_ip: '',
      note: '',
    };
    this.setState({
      modalVisible: !!flag,
      modalTitle: '新增设备',
      formAddValues: formValuesArr,
    });
  };

  // 列表数据改变时
  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formQueryValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      page: pagination.current,
      perPageSize: pagination.pageSize,
      ...formQueryValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'equipmentList/fetchEquipmentList',
      payload: params,
    });
  };

  handleClose = () => {
    this.setState({
      modalVisible: false,
    });
  };

  // 新增数据
  handleAdd = (fields, form) => {
    const { dispatch } = this.props;
    let params = {
      equipment_id: this.state.formAddValues.equipment_id,
      mac_address: fields.mac_address,
      serial_number: fields.serial_number,
      equipment_type_id: fields.equipment_type_id,
      equipment_code: fields.equipment_code,
      equipment_location_id: fields.equipment_location_id,
      company_id: fields.company_id,
      equipment_attribution_id: fields.equipment_attribution_id,
      equipment_use_id: fields.equipment_use_id,
      public_network_ip: fields.public_network_ip,
      public_network_ip_area: fields.public_network_ip_area,
      intranet_ip: fields.intranet_ip,
      note: fields.note,
      filters: this.state.formQueryValues,
    };
    let url = 'equipmentList/addNewequipment';
    if (this.state.formAddValues.equipment_id) {
      url = 'equipmentList/editEquipment';
    }
    dispatch({
      type: url,
      payload: params,
      callback: result => {
        if (result == 'success') {
          form.resetFields();
          this.setState({
            modalVisible: false,
          });
        }
      },
    });
  };

  goPage = () => {
    this.props.history.push('./equipment-follow');
  };

  handleShowNote = (text, data, event) => {
    console.log(text);
    this.setState({
      modalShowNoteVisible: true,
      currentNote: text,
    });
    // this.forceUpdate();
  };

  handleShowContentModalVisible = () => {
    this.setState({
      modalShowNoteVisible: false,
      currentNote: '',
    });
    // this.forceUpdate();
  };

  // 渲染简易查询
  renderSimpleForm() {
    const {
      form,
      equipmentFollow,
      equipmentType: { equipmentTypeData },
    } = this.props;
    const { getFieldDecorator } = form;
    const selectData = equipmentFollow.EquipmentConditionData;
    let typeData = equipmentTypeData;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem label="MAC地址">
              {getFieldDecorator('query_mac_address', {
                initialValue: this.state.formQueryValues.query_mac_address,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="设备序列号">
              {form.getFieldDecorator('query_serial_number', {})(
                <Select
                  style={{ width: 180 }}
                  showSearch
                  placeholder="请输入"
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {selectData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_id}>
                        {item.serial_number}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="设备类型">
              {form.getFieldDecorator('query_equipment_type_id', {
                initialValue: this.state.formQueryValues.query_equipment_type_id,
                validateFields: true,
              })(
                <Select style={{ width: 200 }} placeholder="请选择">
                  {typeData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_type_id}>
                        {item.equipment_name}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="end">
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <span style={{ float: 'right', marginBottom: 24, marginTop: 20 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
                <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                  展开 <Icon type="down" />
                </a>
              </span>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  //渲染高级查询
  renderAdvancedForm() {
    const {
      form,
      equipmentFollow,
      equipmentOwen: { equipmentAttributionData },
      equipmentPosition: { equipmentLocationData },
      equipmentType: { equipmentTypeData },
    } = this.props;
    const { getFieldDecorator } = form;
    const selectData = equipmentFollow.EquipmentConditionData;
    let attributionData = equipmentAttributionData;
    let locationData = equipmentLocationData;
    let typeData = equipmentTypeData;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem label="MAC地址">
              {getFieldDecorator('query_mac_address', {
                initialValue: this.state.formQueryValues.query_mac_address,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="设备号">
              {form.getFieldDecorator('query_serial_number', {})(
                <Select
                  style={{ width: 200 }}
                  showSearch
                  placeholder="请输入"
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {selectData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_id}>
                        {item.serial_number}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="设备类型">
              {form.getFieldDecorator('query_equipment_type_id', {
                initialValue: this.state.formQueryValues.query_equipment_type_id,
                validateFields: true,
              })(
                <Select style={{ width: 200 }} placeholder="请选择">
                  {typeData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_type_id}>
                        {item.equipment_name}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem label="设备位置">
              {form.getFieldDecorator('query_equipment_location_id', {
                initialValue: this.state.formQueryValues.query_equipment_location_id,
                validateFields: true,
              })(
                <Select style={{ width: 200 }} placeholder="请选择">
                  {locationData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_location_id}>
                        {item.equipment_location}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="设备归属">
              {form.getFieldDecorator('query_equipment_attribution_id', {
                initialValue: this.state.formQueryValues.query_equipment_attribution_id,
                validateFields: true,
              })(
                <Select style={{ width: 200 }} placeholder="请选择">
                  {attributionData.map((item, index) => {
                    return (
                      <Option key={index} value={item.equipment_attribution_id}>
                        {item.equipment_attribution}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="添加人">
              {getFieldDecorator('query_user_name', {
                initialValue: this.state.formQueryValues.query_user_name,
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={12} sm={24}>
            <FormItem label="创建时间">
              {getFieldDecorator('query_created_at', {
                initialValue: this.state.formQueryValues.query_created_at,
              })(
                <RangePicker
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['Start Time', 'End Time']}
                />
              )}
            </FormItem>
          </Col>
        </Row>

        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="end">
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <span style={{ float: 'right', marginBottom: 24, marginTop: 20 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
                <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                  收起 <Icon type="up" />
                </a>
              </span>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  // 渲染查询表单
  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  render() {
    const {
      equipmentList: { data },
      equipmentPosition: { equipmentLocationData },
      equipmentOwen: { equipmentAttributionData },
      equipmentType: { equipmentTypeData },
      equipmentUse: { equipmentUseData },
      follow: { companyInfo },
      loading,
      location,
    } = this.props;
    const { selectedRows, modalVisible,modalShowNoteVisible,  currentNote, formAddValues, modalTitle, selectedRowKeys } = this.state;
    const currentOperations = JSON.parse(getOperateInfo());
    const hasSelected = selectedRowKeys.length > 0;
    const pagination = data ? data.pagination : '';

    const paginationProps = {
      showSizeChanger: true,
      // showQuickJumper: true,
      showTotal: total => {
        return `共 ${total} 条`;
      },
      ...pagination,
    };
    const columns = [
      {
        title: '添加人',
        dataIndex: 'user_name',
        key: 'user_name',
      },
      {
        title: 'MAC地址',
        dataIndex: 'mac_address',
        key: 'mac_address',
      },
      {
        title: '设备序列号',
        dataIndex: 'serial_number',
        key: 'serial_number',
      },
      {
        title: '设备类型',
        dataIndex: 'equipment_name',
        key: 'equipment_type_id',
      },
      {
        title: '设备编码',
        dataIndex: 'equipment_code',
        key: 'equipment_code',
      },
      {
        title: '设备位置',
        dataIndex: 'equipment_location',
        key: 'equipment_location_id',
      },
      {
        title: '所属公司',
        dataIndex: 'company_name',
        key: 'company_id',
      },
      {
        title: '设备归属',
        dataIndex: 'equipment_attribution',
        key: 'equipment_attribution_id',
      },
      {
        title: '设备用途',
        dataIndex: 'equipment_use',
        key: 'equipment_use_id',
      },
      {
        title: '公网IP',
        dataIndex: 'public_network_ip',
        key: 'public_network_ip',
      },
      {
        title: 'IP地址',
        dataIndex: 'public_network_ip_area',
        key: 'public_network_ip_area',
      },
      {
        title: '内网IP',
        dataIndex: 'intranet_ip',
        key: 'intranet_ip',
      },
      {
        title: '备注信息',
        dataIndex: 'note',
        key: 'note',
        render: (text, record) => (
          <Fragment>
            {
              <p
                href="javascript:;"
                className={styles.note}
                onClick={this.handleShowNote.bind(this, text, record)}
              >
                {text}
              </p>
            }
          </Fragment>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'created_at',
        key: 'created_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '更新时间',
        dataIndex: 'updated_at',
        key: 'updated_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 110,
        fixed: 'right',
        render: (text, record, index) => (
          <Fragment>
            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].EDITEQUIPMENT ? (
              <div>
                <a href="javascript:;" onClick={this.handleEdit.bind(this, text, record)}>
                  编辑
                </a>
                <Divider type="vertical" />
              </div>
            ) : (
              ''
            )}

            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].DELETEEQUIPMENT ? (
              <Popconfirm
                placement="topRight"
                title="确定删除吗？"
                onConfirm={this.handleDeleteData.bind(this, text, record)}
                okText="Yes"
                cancelText="No"
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
            ) : (
              ''
            )}
          </Fragment>
        ),
      },
    ];

    const parentMethods = {
      handleAdd: this.handleAdd,
      handleClose: this.handleClose,
      handleModalVisible: this.handleModalVisible,
    };

    const parentShowNoteMethods = {
      handleShowContentModalVisible: this.handleShowContentModalVisible,
    };

    return (
      <PageHeaderLayout>
        <div className={styles.content}>
          <Card bordered={false}>
            <div className={styles.tableList}>
              <div className={styles.tableListForm}>{this.renderForm()}</div>
              {/* 新增设备区域开始 */}
              <div className={styles.tableListOperator}>
                {currentOperations &&
                currentOperations[location.pathname] &&
                currentOperations[location.pathname].ADDEQUIPMENT ? (
                  <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                    新建数据
                  </Button>
                ) : (
                  ''
                )}
                <Button
                  type="primary"
                  onClick={() => this.goPage()}
                  disabled={!hasSelected}
                  className={styles.boton}
                >
                  跟进记录
                </Button>
              </div>
              {/* 新增设备区域结束 */}
              <Table
                bordered
                rowKey={'equipment_id'}
                scroll={{ x: 2000 }}
                selectedRows={selectedRows}
                loading={loading}
                pagination={paginationProps}
                dataSource={data.list}
                columns={columns}
                rowClassName={this.setClassName}
                onSelectRow={this.handleSelectRows}
                onChange={this.handleStandardTableChange}
                onRow={record => {
                  //表格行点击事件
                  return {
                    onClick: this.handleClickRow.bind(this, record),
                  };
                }}
              />
            </div>
          </Card>
        </div>
        <CreateForm
          {...parentMethods}
          modalVisible={modalVisible}
          formAddValues={formAddValues}
          modalTitle={modalTitle}
          packageTypes={data.packageTypes}
          jobNumbers={data.jobNumbers}
          locationData={equipmentLocationData}
          attributionData={equipmentAttributionData}
          typeData={equipmentTypeData}
          userData={equipmentUseData}
          companyData={companyInfo}
        />
        <CreateShowNoteForm
          {...parentShowNoteMethods}
          modalShowNoteVisible={modalShowNoteVisible}
          currentNote={currentNote}
        />
      </PageHeaderLayout>
    );
  }
}
