import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Icon,
  Button,
  Dropdown,
  Menu,
  DatePicker,
  Popconfirm,
  Modal,
  Divider,
  Tooltip,
} from 'antd';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import StandardTable from '../../../components/EquipmentOwenTable';
import { getOperateInfo } from '../../../utils/localstorage';
import styles from './Index.less';

const { RangePicker } = DatePicker;
const { TextArea } = Input;
const FormItem = Form.Item;

// 新增设备归属模态框
const CreateForm = Form.create()(props => {
  const { modalVisible, form, handleAdd,handleClose, handleModalVisible, formAddValues, modalTitle } = props;

  const okHandle = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      if (err) return;
      handleAdd(fieldsValue, form);
    });
  };
  const cancel = () => {
    form.validateFields({ first: false }, (err, fieldsValue) => {
      form.resetFields();
      handleClose(fieldsValue, form);
    });
  };

  return (
    <Modal
      title={modalTitle}
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => cancel()}
    >
      <Form>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="设备归属">
          {form.getFieldDecorator('equipment_attribution', {
            initialValue: formAddValues.equipment_attribution,
            validateFirst: true,
            rules: [{ required: true, whitespace: true, message: '请输入设备归属' }],
          })(<Input style={{ width: '100%' }} />)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="备注">
          {form.getFieldDecorator('note', {
            initialValue: formAddValues.note,
            validateFirst: true,
          })(<TextArea rows={4} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

@connect(({ equipmentOwen, loading }) => ({
  equipmentOwen,
  loading: loading.models.equipmentOwen,
}))
@Form.create()
export default class OwenList extends PureComponent {
  state = {
    modalVisible: false,
    modalTitle: '新增归属',
    expandForm: false,
    selectedRows: [],
    formAddValues: {
      equipment_attribution_id: '',
      equipment_attribution: '',
      note: '',
      created_at: '',
      updated_at: '',
    },
    formQueryValues: {},
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'equipmentOwen/fetchOwen',
      payload: {},
    });
  }
  handleClose = () => {
    this.setState({
      modalVisible:false,
    })
  }

  // 重置查询数据
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    this.setState({
      formQueryValues: {},
    });
    dispatch({
      type: 'equipmentOwen/fetchOwen',
      payload: {},
    });
  };

  // 单个删除
  handleDeleteData = (e, text, data) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'equipmentOwen/removeOwen',
      payload: {
        equipment_attribution_id: text.equipment_attribution_id,
        filters: this.state.formQueryValues,
      },
      callback: () => {
        this.setState({
          selectedRows: [],
        });
      },
    });
  };

  // 编辑
  handleEdit = (e, text, data) => {
    const formValuesArr = {
      equipment_attribution_id: text.equipment_attribution_id,
      equipment_attribution: text.equipment_attribution,
      note: text.note,
      created_at: text.created_at,
      updated_at: text.updated_at,
    };
    this.setState({
      modalTitle: '编辑归属',
    });
    this.setState({
      formAddValues: formValuesArr,
    });
    this.setState({
      modalVisible: true,
    });
  };

  // 选择
  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };
  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formQueryValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      page: pagination.current,
      perPageSize: pagination.pageSize,
      ...formQueryValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'equipmentOwen/fetchOwen',
      payload: params,
    });
  };

  // 查询
  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      this.setState({
        formQueryValues: values,
      });
      dispatch({
        type: 'equipmentOwen/fetchOwen',
        payload: values,
      });
    });
  };

  // 模态框新增数据
  handleModalVisible = flag => {
    const formValuesArr = {
      equipment_attribution_id: '',
      equipment_attribution: '',
      note: '',
    };
    this.setState({
      modalVisible: !!flag,
      modalTitle: '新增归属',
      formAddValues: formValuesArr,
    });
  };

  // 新增数据
  handleAdd = (fields, form) => {
    const { dispatch } = this.props;
    let params = {
      equipment_attribution_id: this.state.formAddValues.equipment_attribution_id,
      equipment_attribution: fields.equipment_attribution,
      note: fields.note,
      filters: this.state.formQueryValues,
    };
    let url = 'equipmentOwen/addOwen';

    if (this.state.formAddValues.equipment_attribution_id) {
      url = 'equipmentOwen/editOwen';
    }
    dispatch({
      type: url,
      payload: params,
      callback: result => {
        if (result == 'success') {
          form.resetFields();
          this.setState({
            modalVisible: false,
          });
        }
      },
    });
  };

  // 渲染高级查询
  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="start">
          <Col md={8} sm={24}>
            <FormItem label="设备归属">
              {form.getFieldDecorator('query_equipment_attribution', {
                initialValue: this.state.formQueryValues.query_equipment_attribution,
              })(<Input style={{ width: '100%' }} placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={12} sm={24}>
            <FormItem label="创建时间">
              {getFieldDecorator('query_created_at', {
                initialValue: this.state.formQueryValues.query_created_at,
              })(
                <RangePicker
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['Start Time', 'End Time']}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" justify="end">
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <span style={{ float: 'right', marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
              </span>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  //渲染查询表单
  renderForm() {
    return this.renderSimpleForm();
  }

  render() {
    const {
      equipmentOwen: { data },
      loading,
      location,
    } = this.props;
    const { selectedRows, modalVisible, formAddValues, modalTitle } = this.state;

    const currentOperations = JSON.parse(getOperateInfo());
    const columns = [
      {
        title: '序号',
        dataIndex: 'sort',
        key: 'sort',
      },
      {
        title: '设备归属',
        dataIndex: 'equipment_attribution',
        key: 'equipment_attribution',
      },
      {
        title: '备注',
        dataIndex: 'note',
        key: 'note',
        render(text, record) {
          return (
            <Tooltip placement="top" title={text}>
              <span className={styles.note}>{text}</span>
            </Tooltip>
          );
        },
      },
      {
        title: '创建时间',
        dataIndex: 'created_at',
        key: 'created_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '更新时间',
        dataIndex: 'updated_at',
        key: 'updated_at',
        sorter: true,
        render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 110,
        fixed: 'right',
        render: (text, record, index) => (
          <Fragment>
            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].EDITEQUIPMENTATTRIBUTION ? (
              <div>
                <a href="javascript:;" onClick={this.handleEdit.bind(this, text, record)}>
                  编辑
                </a>
                <Divider type="vertical" />
              </div>
            ) : (
              ''
            )}

            {currentOperations &&
            currentOperations[location.pathname] &&
            currentOperations[location.pathname].DELETEEQUIPMENTATTRIBUTION ? (
              <Popconfirm
                placement="topRight"
                title="确定删除吗？"
                onConfirm={this.handleDeleteData.bind(this, text, record)}
                okText="Yes"
                cancelText="No"
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
            ) : (
              ''
            )}
          </Fragment>
        ),
      },
    ];

    const parentMethods = {
      handleAdd: this.handleAdd,
      handleClose:this.handleClose,
      handleModalVisible: this.handleModalVisible,
    };

    return (
      <PageHeaderLayout>
        <div className={styles.content}>
          <Card bordered={false}>
            <div className={styles.tableList}>
              <div className={styles.tableListForm}>{this.renderForm()}</div>
              <div className={styles.tableListOperator}>
                {currentOperations &&
                currentOperations[location.pathname] &&
                currentOperations[location.pathname].ADDEQUIPMENTATTRIBUTION ? (
                  <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                    新建数据
                  </Button>
                ) : (
                  ''
                )}
              </div>
              <StandardTable
                selectedRows={selectedRows}
                loading={loading}
                data={data}
                columns={columns}
                onSelectRow={this.handleSelectRows}
                onChange={this.handleStandardTableChange}
              />
            </div>
          </Card>
        </div>
        <CreateForm
          {...parentMethods}
          modalVisible={modalVisible}
          formAddValues={formAddValues}
          modalTitle={modalTitle}
          packageTypes={data.packageTypes}
          jobNumbers={data.jobNumbers}
        />
      </PageHeaderLayout>
    );
  }
}
