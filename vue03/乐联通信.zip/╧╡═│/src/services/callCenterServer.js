import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取呼叫中心服务信息
export async function fetchCallCenterServer(params) {
  return request(api_domain + 'callcenterserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchCallCenterServer',
    },
  });
}

// 添加呼叫中心服务信息
export async function addCallCenterServer(params) {
  return request(api_domain + 'callcenterserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addCallCenterServer',
    },
  });
}

// 编辑呼叫中心服务信息
export async function editCallCenterServer(params) {
  return request(api_domain + 'callcenterserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editCallCenterServer',
    },
  });
}

// 删除呼叫中心服务信息
export async function removeCallCenterServer(params) {
  return request(api_domain + 'callcenterserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteCallCenterServer',
    },
  });
}
