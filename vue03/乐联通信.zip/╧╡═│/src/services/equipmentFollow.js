import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 新增设备跟进记录
export async function addEqFollow(params) {
  return request(api_domain + 'equipmentfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addEquipmentFollow',
    },
  });
}

// 获取设备跟进记录
export async function fetchEqFollow(params) {
  return request(api_domain + 'equipmentfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentFollow',
    },
  });
}

// 根据条件获取设备跟进记录
export async function fetchEquipmentByCondition(params) {
  return request(api_domain + 'equipment', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentByCondition',
    },
  });
}

// 编辑设备跟进记录
export async function editEqFollow(params) {
  return request(api_domain + 'equipmentfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editEquipmentFollow',
    },
  });
}

//删除设备跟进记录
export async function removeEqFollow(params) {
  return request(api_domain + 'equipmentfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteEquipmentFollow',
    },
  });
}
