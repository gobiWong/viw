import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 新增设备信息
export async function addNewequipment(params) {
  return request(api_domain + 'equipment', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addEquipment',
    },
  });
}

// 查询设备信息
export async function fetchEquipment(params) {
  return request(api_domain + 'equipment', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipment',
    },
  });
}

// 编辑设备信息
export async function editEquipment(params) {
  console.log(params,99999);
  return request(api_domain + 'equipment', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editEquipment',
    },
  });
}

// 删除设备信息
export async function removeEquipment(params) {
  return request(api_domain + 'equipment', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteEquipment',
    },
  });
}
