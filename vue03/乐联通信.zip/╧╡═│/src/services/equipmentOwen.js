import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 新增设备归属信息
export async function addEqAttribution(params) {
  return request(api_domain + 'equipmentattribution', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addEquipmentAttribution',
    },
  });
}

// 根据条件获取设备归属信息
export async function fetchEqAttributionByCondition(params) {
  return request(api_domain + 'equipmentattribution', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentAttributionByCondition',
    },
  });
}

// 获取设备归属信息
export async function fetchEqAttribution(params) {
  return request(api_domain + 'equipmentattribution', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentAttribution',
    },
  });
}

// 编辑取设备归属信息
export async function editEqAttribution(params) {
  return request(api_domain + 'equipmentattribution', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editEquipmentAttribution',
    },
  });
}

// 删除设备归属信息
export async function removeEqAttribution(params) {
  return request(api_domain + 'equipmentattribution', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteEquipmentAttribution',
    },
  });
}
