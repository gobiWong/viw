import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 添加设备位置信息
export async function addEqLocation(params) {
  return request(api_domain + 'equipmentlocation', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addEquipmentLocation',
    },
  });
}

// 获取设备位置信息
export async function fetchEqLocation(params) {
  return request(api_domain + 'equipmentlocation', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentLocation',
    },
  });
}

// 根据条件获取设备位置信息
export async function fetchEqLocationByCondition(params) {
  return request(api_domain + 'equipmentlocation', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentLocationByCondition',
    },
  });
}

// 编辑设备位置信息
export async function editEqLocation(params) {
  return request(api_domain + 'equipmentlocation', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editEquipmentLocation',
    },
  });
}

// 删除设备位置信息
export async function removeEqLocation(params) {
  return request(api_domain + 'equipmentlocation', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteEquipmentLocation',
    },
  });
}
