import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 新增设备类型信息
export async function addEqType(params) {
  return request(api_domain + 'equipmenttype', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addEquipmentType',
    },
  });
}

// 获取设备类型信息
export async function fetchEqType(params) {
  return request(api_domain + 'equipmenttype', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentType',
    },
  });
}

// 根据条件获取设备类型信息
export async function fetchEqTypeByCondition(params) {
  return request(api_domain + 'equipmenttype', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentTypeByCondition',
    },
  });
}

// 编辑设备类型信息
export async function editEqType(params) {
  return request(api_domain + 'equipmenttype', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editEquipmentType',
    },
  });
}

// 删除设备类型信息
export async function removeEqType(params) {
  return request(api_domain + 'equipmenttype', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteEquipmentType',
    },
  });
}
