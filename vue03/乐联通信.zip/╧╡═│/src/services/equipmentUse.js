import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 新增设备用途信息
export async function addEqUse(params) {
  return request(api_domain + 'equipmentuse', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addEquipmentUse',
    },
  });
}

// 获取设备用途信息
export async function fetchEqUse(params) {
  return request(api_domain + 'equipmentuse', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentUse',
    },
  });
}

// 根据条件获取设备用途信息
export async function fetchEqUseByCondition(params) {
  return request(api_domain + 'equipmentuse', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchEquipmentUseByCondition',
    },
  });
}

// 编辑设备用途信息
export async function editEqUse(params) {
  return request(api_domain + 'equipmentuse', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editEquipmentUse',
    },
  });
}

// 删除设备用途信息
export async function removeEqUse(params) {
  return request(api_domain + 'equipmentuse', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteEquipmentUse',
    },
  });
}
