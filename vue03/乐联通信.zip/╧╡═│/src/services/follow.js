import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取客户跟进信息
export async function fetchCompanyFollow(params) {
  return request(api_domain + 'companyfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchCompanyFollow',
    },
  });
}

// 新增客户跟进信息
export async function addCompanyFollow(params) {
  return request(api_domain + 'companyfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addCompanyFollow',
    },
  });
}

// 编辑客户跟进信息
export async function editCompanyFollow(params) {
  return request(api_domain + 'companyfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editCompanyFollow',
    },
  });
}

// 删除客户跟进信息
export async function removeCompanyFollow(params) {
  return request(api_domain + 'companyfollow', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteCompanyFollow',
    },
  });
}

// 获取客户信息
export async function fetchCompany(params) {
  return request(api_domain + 'company', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'getCompanySelectList',
    },
  });
}
