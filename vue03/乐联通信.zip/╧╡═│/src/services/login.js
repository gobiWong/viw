import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import {api_domain } from '../utils/common';


// 账号登录
export async function accountLogin(params) {
  return request(api_domain+ 'open', {
    method: 'POST',
    body: {
      params:{...params},
      method: 'login'
    }
  });
}

// 退出登录
export async function accountLogout(params) {
  return request(api_domain+ 'index', {
    method: 'POST',
    body: {
      params:{...params},
      method: 'logout',
      accessToken: getAccessToken(),
    }
  });
}

// 图片验证码
export async function getImgCaptcha(params) {
  return request(api_domain+ 'open', {
    method: 'POST',
    body: {
      params:{...params},
      method: 'getImageCaptcha',
    }
  });
}

