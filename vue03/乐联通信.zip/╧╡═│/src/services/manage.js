import request from '../utils/request';
// import { ServerResponse } from 'http';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

//客户资料
    export async function fetchCompany(params) {
      return request(api_domain+ 'company', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'fetchCompany',
        },
      });
    }
    
    export async function addCompany(params) {
      return request(api_domain+ 'company', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'addCompany',
        },
      });
    }
  
    export async function editCompany(params) {
      return request(api_domain+ 'company', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'editCompany',
        },
      });
    }
    
    export async function removeCompany(params) {
      return request(api_domain + 'company', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'deleteCompany',
        },
      });
    }

    export async function fetchInfo(params) {
      return request(api_domain + 'company', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'getCompanyNeedSelectList',
        },
      });
    }

    //客户资料中查看
  export async function seeCompanyInfo(params) {
    return request(api_domain+ 'company', {
      method: 'POST',
      body: {
        params: {...params},
        accessToken: getAccessToken(),
        method: 'seeCompanyInfo',
      },
    });
  }



    //编辑统一平台
    export async function addUnifiedPlatform(params) {
      return request(api_domain+ 'unifiedplatform', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'addUnifiedPlatform',
        },
      });
    }
  
    export async function editUnifiedPlatform(params) {
      return request(api_domain+ 'unifiedplatform', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'editUnifiedPlatform',
        },
      });
    }
    
    export async function removeUnifiedPlatform(params) {
      return request(api_domain + 'unifiedplatform', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'deleteUnifiedPlatform',
        },
      });
    }

     //编辑VOS平台

     export async function addVos(params) {
      return request(api_domain+ 'vos', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'addVos',
        },
      });
     }
  
    export async function editVos(params) {
      return request(api_domain+ 'vos', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'editVos',
        },
      });
    }
    
    export async function removeVos(params) {
      return request(api_domain + 'vos', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'deleteVos',
        },
      });
    }


    //编辑呼叫中心平台

    export async function addCallCenter(params) {
    return request(api_domain+ 'callcenter', {
      method: 'POST',
      body: {
        params: {...params},
        accessToken: getAccessToken(),
        method: 'addCallCenter',
      },
    });
    }

    export async function editCallCenter(params) {
    return request(api_domain+ 'callcenter', {
      method: 'POST',
      body: {
        params: {...params},
        accessToken: getAccessToken(),
        method: 'editCallCenter',
      },
    });
    }
  
    export async function removeCallCenter(params) {
    return request(api_domain + 'callcenter', {
      method: 'POST',
      body: {
        params: {...params},
        accessToken: getAccessToken(),
        method: 'deleteCallCenter',
      },
    });
    }