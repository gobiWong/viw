import { stringify } from 'qs';
import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

//查询管理员
export async function fetchUser(params) {
  return request(api_domain + 'user', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchUser',
    },
  });
}

//添加管理员
export async function addManager(params) {
  return request(api_domain + 'user', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addUser',
    },
  });
}

//编辑管理员
export async function editManager(params) {
  return request(api_domain + 'user', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editUser',
    },
  });
}

//删除管理员
export async function removeManager(params) {
  return request(api_domain + 'user', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteUser',
    },
  });
}

//添加用户角色
export async function addUserRole(params) {
  return request(api_domain + 'user', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addUserRole',
    },
  });
}
