import { stringify } from 'qs';
import request from '../utils/request';
// import { ServerResponse } from 'http';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取菜单信息
export async function fetchMenu(params) {
  return request(api_domain + 'menu', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchMenu',
    },
  });
}

// 根据条件获取菜单信息
export async function fetchMenuByCondition(params) {
  return request(api_domain + 'menu', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchMenuByCondition',
    },
  });
}

// 添加菜单信息
export async function addMenu(params) {
  return request(api_domain + 'menu', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addMenu',
    },
  });
}

// 编辑菜单信息
export async function editMenu(params) {
  return request(api_domain + 'menu', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editMenu',
    },
  });
}

// 删除菜单信息
export async function removeMenu(params) {
  return request(api_domain + 'menu', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteMenu',
    },
  });
}
