import { stringify } from 'qs';
import request from '../utils/request';
// import { ServerResponse } from 'http';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

  // 根据条件获取操作信息
  export async function fetchOperateByCondition(params) {
      return request(api_domain + 'operate', {
        method: 'POST',
        body: {
          params: {...params},
          accessToken: getAccessToken(),
          method: 'fetchOperateByCondition',
        },
      });
  }
  
  // 添加操作信息
  export async function addOperate(params) {
    return request(api_domain + 'operate', {
      method: 'POST',
      body: {
        params: {...params},
        accessToken: getAccessToken(),
        method: 'addOperate',
      },
    });
  }
