import { stringify } from 'qs';
import request from '../utils/request';
// import { ServerResponse } from 'http';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取角色信息
export async function fetchRole(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchRole',
    },
  });
}

// 根据条件获取角色信息
export async function fetchRoleByCondition(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchRoleByCondition',
    },
  });
}

// 添加角色
export async function addRole(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addRole',
    },
  });
}

// 编辑角色
export async function editRole(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editRole',
    },
  });
}

// 删除角色
export async function removeRole(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteRole',
    },
  });
}

//获取权限信息
export async function fetchPermission(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchPermission',
    },
  });
}

// 提交权限信息
export async function addPermission(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addPermission',
    },
  });
}

//根据角色获取权限信息
export async function fetchPermissionByRole(params) {
  return request(api_domain + 'role', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchPermissionByRole',
    },
  });
}
