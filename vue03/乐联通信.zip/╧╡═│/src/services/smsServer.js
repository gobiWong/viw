import { stringify } from 'qs';
import request from '../utils/request';
// import { ServerResponse } from 'http';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取短信服务信息
export async function fetchSmsServer(params) {
  return request(api_domain + 'smsserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchSmsServer',
    },
  });
}

// 添加短信服务信息
export async function addSmsServer(params) {
  return request(api_domain + 'smsserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addSmsServer',
    },
  });
}

// 编辑短信服务信息
export async function editSmsServer(params) {
  return request(api_domain + 'smsserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editSmsServer',
    },
  });
}

// 删除短信服务信息
export async function removeSmsServer(params) {
  return request(api_domain + 'smsserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteSmsServer',
    },
  });
}
