import request from '../utils/request';
// import { ServerResponse } from 'http';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

//获取组织架构
export async function fetchStructureInfo(params) {
  return request(api_domain + 'structure', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchStructureInfo',
    },
  });
}

//新增组织架构
export async function addStructure(params) {
  return request(api_domain + 'structure', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addStructure',
    },
  });
}

//编辑组织架构
export async function editStructure(params) {
  return request(api_domain + 'structure', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editStructure',
    },
  });
}

//删除组织架构
export async function deleteStructure(params) {
  return request(api_domain + 'structure', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteStructure',
    },
  });
}
