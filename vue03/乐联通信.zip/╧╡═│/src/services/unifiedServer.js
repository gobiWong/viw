import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取统一平台服务信息
export async function fetchUnifiedServer(params) {
  return request(api_domain + 'unifiedserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchUnifiedServer',
    },
  });
}

// 添加统一平台服务信息
export async function addUnifiedServer(params) {
  return request(api_domain + 'unifiedserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addUnifiedServer',
    },
  });
}

// 编辑统一平台服务信息
export async function editUnifiedServer(params) {
  return request(api_domain + 'unifiedserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editUnifiedServer',
    },
  });
}

// 删除统一平台服务信息
export async function removeUnifiedServer(params) {
  return request(api_domain + 'unifiedserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteUnifiedServer',
    },
  });
}
