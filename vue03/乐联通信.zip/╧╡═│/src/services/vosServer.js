import request from '../utils/request';
import { getAccessToken } from '../utils/localstorage';
import { api_domain } from '../utils/common';

// 获取VOS服务信息
export async function fetchVosServer(params) {
  return request(api_domain + 'vosserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'fetchVosServer',
    },
  });
}

// 添加VOS服务信息
export async function addVosServer(params) {
  return request(api_domain + 'vosserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'addVosServer',
    },
  });
}

// 编辑VOS服务信息
export async function editVosServer(params) {
  return request(api_domain + 'vosserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'editVosServer',
    },
  });
}

// 删除VOS服务信息
export async function removeVosServer(params) {
  return request(api_domain + 'vosserver', {
    method: 'POST',
    body: {
      params: { ...params },
      accessToken: getAccessToken(),
      method: 'deleteVosServer',
    },
  });
}
