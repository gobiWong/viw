// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less
module.exports = {
  'primary-color': '#34404c',
  'btn-primary-color': '#fff',
  'btn-primary-bg': '#34404c',
  'card-actions-background': '#f5f8fa',
};
