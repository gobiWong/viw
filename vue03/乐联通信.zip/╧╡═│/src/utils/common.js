export const http_method_option = [
    { 'key': 'POST', 'name': 'POST' },
    { 'key': 'GET', 'name': 'GET' },
];

export const common_pathname = {
    '/result/success': true,
    '/result/fail': true,
    '/exception/403': true,
    '/exception/404': true,
    '/exception/500': true,
    '/exception/trigger': true,
};

export const iconSelectData = [
    'plus',
    'cloud',
    'folder',
    'setting',
];

export const api_success = 'success';
export const unauth_code = '001x1000x1000';


// const domain = 'http://192.168.88.21:8089/'; // 本地
// const domain = 'http://192.168.88.90:6111/'; // 局域网
// const domain = 'http://www.lelink_internal_management_server.com/'; // 测试服务器
// const domain = 'http://lelink.me/'; // wyl
const domain = 'http://vip.illcc.cc:9099/'; // 线上



export const host = domain;
export const api_domain = domain + 'api/';
export const down_data_template = domain + "resource/DataTemplate.xlsx";
export const avatar = domain + "images/avatar.png";