export function setAccessToken(token) {
  return localStorage.setItem('token', token);
}

export function getAccessToken() {
  return localStorage.getItem('token');
}

export function setUserInfo(username) {
  return localStorage.setItem('username', username);
}

export function getUserInfo() {
  return localStorage.getItem('username');
}

export function setUserId(userid) {
  return localStorage.setItem('userid', userid);
}

export function getUserId() {
  return localStorage.getItem('userid');
}
export function setMenuInfo(menuInfo) {
  return localStorage.setItem('menuInfo', menuInfo);
}
export function getMenuInfo() {
  return localStorage.getItem('menuInfo');
}

export function setOperateInfo(operateInfo) {
  return localStorage.setItem('operateInfo',operateInfo);
}

export function getOperateInfo() {
  return localStorage.getItem('operateInfo');
}

export function setEquseInfo(EquseInfo) {
  return localStorage.setItem('EquseInfo',EquseInfo);
}

export function getEquseInfo() {
  return localStorage.getItem('EquseInfo');
}

export function setEqattributionInfo(EqattributionInfo) {
  return localStorage.setItem('EqattributionInfo',EqattributionInfo);
}

export function getEqattributionInfo() {
  return localStorage.getItem('EqattributionInfo');
}

export function setEqtypeInfo(EqtypeInfo) {
  return localStorage.setItem('EqtypeInfo',EqtypeInfo);
}

export function getEqtypeInfo() {
  return localStorage.getItem('EqtypeInfo');
}

export function setEqlocationInfo(EqlocationInfo) {
  return localStorage.setItem('EqlocationInfo',EqlocationInfo);
}

export function getEqlocationInfo() {
  return localStorage.getItem('EqlocationInfo');
}

export function setCompanyNeedInfo(CompanyNeedInfo) {
  return localStorage.setItem('CompanyNeedInfo',CompanyNeedInfo);
}

export function getCompanyNeedInfo() {
  return localStorage.getItem('CompanyNeedInfo');
}

