export const common_status = { 1: '启用', 2: '禁用' };
export const common_status_map = { yes: 1, no: 2 };
export const common_status_option = [
    { 'key': 1, 'name': '启用' },
    { 'key': 2, 'name': '禁用' }
];
export const badge_status_map = { 1: 'success', 2: 'error' };

export const record_type_map = { 1: 'success', 2: 'error' };
export const record_type = { 1: '系统', 2: '人工' };
export const record_type_option = [
    { 'key': 1, 'name': '系统' },
    { 'key': 2, 'name': '人工' }
];

export const remind_type_map = { 1: 'success', 2: 'error' };
export const remind_type = { 1: '短信', 2: '微信' };
export const remind_type_option = [
    { 'key': 1, 'name': '短信' },
    { 'key': 2, 'name': '微信' }
];

export const log_status = { 'open': '发送成功', 'close': '发送失败' };
export const  log_status_option = [
    { 'key': 'open', 'name': '发送成功' },
    { 'key': 'close', 'name': '发送失败'}
];
export const log_status_map = { 'open': 'success', 'close': 'error' };

export const variable_type = { 'text': '文字', 'numberic': '数字', 'amount': '金额', 'date': '日期', 'time': '时间' };
export const variable_type_option = [
    { 'key': 'text', 'name': '文字' },
    { 'key': 'numberic', 'name': '数值' },
    { 'key': 'amount', 'name': '金额' },
    { 'key': 'date', 'name': '日期' },
    { 'key': 'time', 'name': '时间' },
];

export const sms_status = {'open' :'success', 'default': 'noSend' , 'close': 'error'};
export const sms_type = {'0':'成功','1' :'不通知' , '2' : '失败'};


export const wechat_status = {'open' :'success', 'default': 'noSend' , 'close': 'error'};
export const wechat_type = {'0':'成功','1' :'不通知' , '2' : '失败'};

export const call_center_servers_status = {'open' :'success' , 'close' : 'error'};
export const call_center_servers_option =  [
    { 'key': 'open', 'name': '正常' },
    { 'key': 'close', 'name': '关闭' }
];

export const companys_status = { 1: '正常', 2: '锁定' };
export const companys_status_map = { yes: 1, no: 2 };
export const companys_status_option = [
    { 'key': 1, 'name': '正常' },
    { 'key': 2, 'name': '锁定' }
];

export const send_msg_status = { 1: '开启', 2: '关闭' };
export const send_msg_map = { yes: 1, no: 2 };
export const send_msg_status_option = [
    { 'key': 1, 'name': '开启' },
    { 'key': 2, 'name': '关闭' }
];

export const notice_status = { 'open': '发送成功', 'close': '发送失败' };
export const  notice_status_option = [
    { 'key': 'open', 'name': '发送成功' },
    { 'key': 'close', 'name': '发送失败'}
];

// export const notice_way_option = [
//     { 'key': 1, 'name': '短信' },
//     { 'key': 2, 'name': '微信' }
// ];

export const balance_notice_way_map = { 1: 'success', 2: 'error' };
export const balance_notice_way_type = { 1: '短信', 2: '微信' };
export const balance_notice_waye_option = [
    { 'key': 1, 'name': '短信' },
    { 'key': 2, 'name': '微信' }
];

export const balance_remind = { 1: '是', 2: '否' };
export const balance_remind_option = [
    { 'key': 1, 'name': '是' },
    { 'key': 2, 'name': '否' }
];

export const vos_servers_status = { 1: '可用',2: '不可用' };
export const vos_servers_status_option = [
    { 'key':1, 'name': '可用' },
    { 'key': 2, 'name': '不可用' }
];


export const message_type_status = { 1: '语音通知',2: '短信' };
export const message_type_status_option = [
    { 'key':1, 'name': '语音通知' },
    { 'key': 2, 'name': '短信' }
];


export const isApi_status = { 1: '是', 2: '否' };
export const isApi_status_option = [
    { 'key':1, 'name': '是' },
    { 'key': 2, 'name': '否' }
];

export const menu_type = { 1: '是', 2: '否' };
export const menu_type_option = [
    { 'key': 1, 'name': '是' },
    { 'key': 2, 'name': '否' },
];





